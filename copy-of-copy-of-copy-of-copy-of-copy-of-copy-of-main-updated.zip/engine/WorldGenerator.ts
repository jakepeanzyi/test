
import { Entity, EntityType, Vector2, InventoryItem, ItemType } from '../types';
import { WORLD_SIZE, CHUNK_SIZE, CONTAINER_SLOTS, LOOT_TABLES, LootTableType, LOOT_CONTAINER_DATA, MAP_CHUNK_RADIUS, WORLD_EDGE_RADIUS } from '../constants';

// Current World Seed
let WORLD_SEED = 12345;

export const setWorldSeed = (seed: number) => {
    WORLD_SEED = seed;
};

const hashCoords = (x: number, y: number) => {
  // Integrate seed into hash
  let h1 = (Math.floor(x) * 12741) ^ (Math.floor(y) * 45193) ^ WORLD_SEED;
  h1 = (h1 ^ (h1 >>> 16)) * 0x85ebca6b;
  h1 = (h1 ^ (h1 >>> 13)) * 0xc2b2ae35;
  h1 = (h1 ^ (h1 >>> 16));
  return (h1 >>> 0) / 4294967296;
};

const seededRandom = (seed: number) => {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
};

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const fade = (t: number) => t * t * t * (t * (t * 6 - 15) + 10);

const noise2D = (x: number, y: number) => {
  const X = Math.floor(x);
  const Y = Math.floor(y);
  const xf = x - X;
  const yf = y - Y;
  
  const n00 = hashCoords(X, Y);
  const n10 = hashCoords(X + 1, Y);
  const n01 = hashCoords(X, Y + 1);
  const n11 = hashCoords(X + 1, Y + 1);

  const u = fade(xf);
  const v = fade(yf);

  return lerp(lerp(n00, n10, u), lerp(n01, n11, u), v);
};

export const getBiomeValueAt = (pos: Vector2) => {
  // FORCE OCEAN AT EDGES (Circular Map)
  const dist = Math.sqrt(pos.x*pos.x + pos.y*pos.y);
  if (dist > WORLD_EDGE_RADIUS) {
      // Smooth fade to ocean
      return 0.0; 
  }

  const scale = 5000;
  const qx = noise2D(pos.x / scale, pos.y / scale);
  const qy = noise2D(pos.x / scale + 5.2, pos.y / scale + 1.3);
  const rx = noise2D(pos.x / scale + 4.0 * qx + 1.7, pos.y / scale + 4.0 * qy + 9.2);
  const ry = noise2D(pos.x / scale + 4.0 * qx + 8.3, pos.y / scale + 4.0 * qy + 2.8);
  const sx = noise2D(pos.x / scale + 2.0 * rx + 4.5, pos.y / scale + 2.0 * ry + 1.1);
  const sy = noise2D(pos.x / scale + 2.0 * rx + 7.8, pos.y / scale + 2.0 * ry + 3.4);
  const nx = pos.x + sx * 2500;
  const ny = pos.y + sy * 2500;
  const n1 = noise2D(nx / 7000, ny / 7000);
  const n2 = noise2D(nx / 3500, ny / 3500) * 0.45;
  const n3 = noise2D(nx / 1200, ny / 1200) * 0.2;
  
  let val = Math.max(0, Math.min(1, (n1 + n2 + n3) / 1.6));

  // Soft edge falloff
  if (dist > WORLD_EDGE_RADIUS * 0.8) {
      const falloff = (WORLD_EDGE_RADIUS - dist) / (WORLD_EDGE_RADIUS * 0.2);
      val *= Math.max(0, falloff); 
  }

  return val;
};

export const getBiomeAt = (pos: Vector2) => {
  // Hard check for deep ocean
  const dist = Math.sqrt(pos.x*pos.x + pos.y*pos.y);
  if (dist > WORLD_EDGE_RADIUS) return 'OCEAN';

  const noise = getBiomeValueAt(pos);
  if (noise < 0.15) return 'LAKE'; 
  if (noise > 0.72) return 'SNOW';
  if (noise > 0.5) return 'FOREST';
  if (noise < 0.28) return 'DESERT';
  return 'GRASSLANDS';
};

export const findSpawnPosition = (): Vector2 => {
    let attempts = 0;
    while (attempts < 100) {
        // Search strictly inside the island radius
        const angle = Math.random() * Math.PI * 2;
        const radius = Math.random() * (WORLD_EDGE_RADIUS * 0.6); // Inner 60% safe zone
        const x = Math.cos(angle) * radius;
        const y = Math.sin(angle) * radius;
        
        const biome = getBiomeAt({ x, y });
        if (biome !== 'LAKE' && biome !== 'OCEAN') {
            return { x, y };
        }
        attempts++;
    }
    return { x: 0, y: 0 }; // Center fallback
};

const hexToRgb = (hex: string) => {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return { r, g, b };
};

export const getGroundColorRGBAt = (pos: Vector2) => {
  const val = getBiomeValueAt(pos);
  // Color palette
  const colors = [
    { threshold: 0.0, color: '#0c4a6e' }, // Deep water
    { threshold: 0.10, color: '#0284c7' }, // Water body
    { threshold: 0.15, color: '#38bdf8' }, // Shallow water
    { threshold: 0.155, color: '#fde047' }, // Wet Sand (sharp transition)
    { threshold: 0.20, color: '#d4a373' }, // Dry Sand
    { threshold: 0.28, color: '#a8a29e' }, // Desert/Dirt
    { threshold: 0.35, color: '#4d7c0f' }, // Grass Start
    { threshold: 0.48, color: '#15803d' }, // Forest Green
    { threshold: 0.58, color: '#064e3b' }, // Deep Forest
    { threshold: 0.7, color: '#3f3f46' },  // Mountain Grey
    { threshold: 0.84, color: '#cbd5e1' }, // Snow
    { threshold: 1.0, color: '#ffffff' }   // Deep Snow
  ];
  let start = colors[0];
  let end = colors[colors.length - 1];
  for (let i = 0; i < colors.length - 1; i++) {
    if (val >= colors[i].threshold && val <= colors[i + 1].threshold) {
      start = colors[i];
      end = colors[i + 1];
      break;
    }
  }
  const range = end.threshold - start.threshold || 1;
  const t = (val - start.threshold) / range;
  const c1 = hexToRgb(start.color);
  const c2 = hexToRgb(end.color);
  return { r: Math.round(lerp(c1.r, c2.r, t)), g: Math.round(lerp(c1.g, c2.g, t)), b: Math.round(lerp(c1.b, c2.b, t)) };
};

// Generates a cached image for a specific chunk to avoid per-pixel logic in main loop
export const renderChunkTerrain = (cx: number, cy: number): Promise<ImageBitmap | HTMLCanvasElement> => {
    return new Promise((resolve) => {
        const size = CHUNK_SIZE;
        const TILE_SIZE = 32; // Blocky Minecraft look
        
        // Use OffscreenCanvas if available, otherwise fallback
        const useOffscreen = typeof OffscreenCanvas !== 'undefined';
        const canvas = useOffscreen ? new OffscreenCanvas(size, size) : document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        
        const ctx = canvas.getContext('2d') as CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D;
        
        // Draw tiles
        const startX = cx * CHUNK_SIZE;
        const startY = cy * CHUNK_SIZE;
        
        for (let y = 0; y < size; y += TILE_SIZE) {
            for (let x = 0; x < size; x += TILE_SIZE) {
                // Sample center of the tile
                const worldX = startX + x + TILE_SIZE/2;
                const worldY = startY + y + TILE_SIZE/2;
                const rgb = getGroundColorRGBAt({ x: worldX, y: worldY });
                
                ctx.fillStyle = `rgb(${rgb.r}, ${rgb.g}, ${rgb.b})`;
                ctx.fillRect(x, y, TILE_SIZE + 1, TILE_SIZE + 1); // +1 to fix subpixel gaps
            }
        }
        
        if (useOffscreen) {
            resolve((canvas as OffscreenCanvas).transferToImageBitmap());
        } else {
            resolve(canvas as HTMLCanvasElement);
        }
    });
};

const getWeightedTypeForBiome = (biome: string, rand: number): EntityType | null => {
  if (biome === 'OCEAN') return null; // No entities in deep ocean
  if (biome === 'LAKE') {
      // Underwater items only
      if (rand < 0.2) return EntityType.SUNKEN_CRATE;
      if (rand < 0.3) return EntityType.SUNKEN_CHEST;
      if (rand < 0.4) return EntityType.UNDERWATER_LAB_TECH_CRATE;
      if (rand < 0.5) return EntityType.WILD_POTATO_PLANT; 
      return null; 
  }
  if (biome === 'FOREST') {
    if (rand < 0.60) return EntityType.TREE; // High density trees
    if (rand < 0.65) return EntityType.STUMP;
    if (rand < 0.70) return EntityType.MUSHROOM;
    if (rand < 0.75) return EntityType.ROCK;
    if (rand < 0.80) return EntityType.BUSH;
    if (rand < 0.85) return EntityType.HEMP_FIBERS;
    if (rand < 0.90) return EntityType.PRIMITIVE_CRATE;
    if (rand < 0.92) return EntityType.NATURAL_BEEHIVE;
    if (rand < 0.94) return EntityType.WILD_CORN_PLANT;
    if (rand < 0.96) return EntityType.WILD_PUMPKIN_PLANT;
    if (rand < 0.98) return EntityType.BLUE_BERRY_BUSH; 
    return EntityType.RED_BERRY_BUSH;
  }
  if (biome === 'SNOW') {
    if (rand < 0.20) return EntityType.TREE; // Sparse Pine trees
    if (rand < 0.30) return EntityType.STUMP;
    if (rand < 0.55) return EntityType.ROCK; // Stone
    if (rand < 0.70) return EntityType.SCATTERED_METAL_ROCK; // More metal in snow
    if (rand < 0.80) return EntityType.SCRAP;
    if (rand < 0.85) return EntityType.MEDICAL_CRATE;
    if (rand < 0.90) return EntityType.RATION_BOX;
    if (rand < 0.95) return EntityType.VEHICLE_PARTS_CRATE;
    if (rand < 0.98) return EntityType.WHITE_BERRY_BUSH; // Only white berries
    return EntityType.DIESEL_BARREL;
  }
  if (biome === 'DESERT') {
    // No Trees in Desert
    if (rand < 0.40) return EntityType.ROCK; // Lots of rocks
    if (rand < 0.55) return EntityType.SCATTERED_SULFUR_ROCK; // Sulfur
    if (rand < 0.65) return EntityType.SCATTERED_STONE_ROCK;
    if (rand < 0.75) return EntityType.SCRAP;
    if (rand < 0.85) return EntityType.BUSH; // Dead bushes
    if (rand < 0.90) return EntityType.OIL_BARREL;
    if (rand < 0.95) return EntityType.TOOL_BOX;
    return EntityType.MINE_CRATE;
  }
  // GRASSLANDS
  if (rand < 0.20) return EntityType.TREE;
  if (rand < 0.30) return EntityType.ROCK;
  if (rand < 0.40) return EntityType.BUSH;
  if (rand < 0.45) return EntityType.SCATTERED_STONE_ROCK;
  if (rand < 0.55) return EntityType.HEMP_FIBERS;
  if (rand < 0.65) return EntityType.BARREL;
  if (rand < 0.70) return EntityType.ROAD_SIGN;
  if (rand < 0.75) return EntityType.CRATE;
  if (rand < 0.80) return EntityType.WILD_WHEAT;
  if (rand < 0.85) return EntityType.YELLOW_BERRY_BUSH;
  if (rand < 0.90) return EntityType.GREEN_BERRY_BUSH;
  if (rand < 0.94) return EntityType.WILD_SUNFLOWER;
  if (rand < 0.97) return EntityType.WILD_ROSE;
  return EntityType.WILD_ORCHID;
};

const getBaseHealth = (type: EntityType): number => {
  if (LOOT_CONTAINER_DATA[type]) return LOOT_CONTAINER_DATA[type].health;
  switch (type) {
    case EntityType.TREE: return 100;
    case EntityType.ROCK: 
    case EntityType.STONE_ORE_NODE: return 200;
    case EntityType.METAL_ORE_NODE: return 300;
    case EntityType.SULFUR_ORE_NODE: return 150;
    case EntityType.BUSH: return 30;
    case EntityType.SCRAP: return 60;
    case EntityType.HEMP_FIBERS: return 20;
    // Collectibles usually 1-hit
    case EntityType.MUSHROOM:
    case EntityType.SCATTERED_METAL_ROCK:
    case EntityType.SCATTERED_STONE_ROCK:
    case EntityType.SCATTERED_SULFUR_ROCK:
    case EntityType.STUMP:
    case EntityType.DIESEL_BARREL:
    case EntityType.BLUE_BERRY_BUSH:
    case EntityType.GREEN_BERRY_BUSH:
    case EntityType.RED_BERRY_BUSH:
    case EntityType.WHITE_BERRY_BUSH:
    case EntityType.YELLOW_BERRY_BUSH:
    case EntityType.WILD_CORN_PLANT:
    case EntityType.WILD_ORCHID:
    case EntityType.WILD_POTATO_PLANT:
    case EntityType.WILD_PUMPKIN_PLANT:
    case EntityType.WILD_ROSE:
    case EntityType.WILD_SUNFLOWER:
    case EntityType.WILD_WHEAT:
        return 10;
    default: return 50;
  }
};

const getBaseColor = (type: EntityType, biome: string): string => {
  if (LOOT_CONTAINER_DATA[type]) return LOOT_CONTAINER_DATA[type].color;
  if (type === EntityType.TREE) {
    if (biome === 'SNOW') return '#e2e8f0';
    if (biome === 'FOREST') return '#064e3b';
    return '#14532d';
  }
  if (type === EntityType.BUSH) {
    if (biome === 'DESERT') return '#78350f'; // Dead bush color
    return '#365314';
  }
  if (type === EntityType.STONE_ORE_NODE) return '#a8a29e';
  if (type === EntityType.METAL_ORE_NODE) return '#573024';
  if (type === EntityType.SULFUR_ORE_NODE) return '#ca8a04';
  
  return '#a1a1aa';
};

export const generateLootFromTable = (tableType: LootTableType): (InventoryItem | null)[] => {
    const table = LOOT_TABLES[tableType];
    if (!table) return new Array(CONTAINER_SLOTS).fill(null);

    const items: (InventoryItem | null)[] = new Array(CONTAINER_SLOTS).fill(null);
    let slot = 0;

    const totalWeight = table.items.reduce((acc, item) => acc + item.weight, 0);

    for (let i = 0; i < table.rolls; i++) {
        if (slot >= CONTAINER_SLOTS) break;

        let random = Math.random() * totalWeight;
        for (const item of table.items) {
            if (random < item.weight) {
                const count = Math.floor(Math.random() * (item.max - item.min + 1)) + item.min;
                items[slot++] = {
                    id: `loot-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
                    type: item.type,
                    count
                };
                break;
            }
            random -= item.weight;
        }
    }
    return items;
};

const spawnMonument = (cx: number, cy: number): Entity[] => {
    const ents: Entity[] = [];
    const baseX = cx * CHUNK_SIZE;
    const baseY = cy * CHUNK_SIZE;
    
    // Monument Center Loot
    ents.push({
        id: `monument-${cx}-${cy}-crate1`, type: EntityType.ELITE_TIER_CRATE,
        pos: { x: baseX, y: baseY }, size: 35, health: 400, maxHealth: 400,
        rotation: 0, velocity: {x:0, y:0}, color: '#1e293b',
        containerItems: generateLootFromTable('ELITE')
    });

    // Guards (Wolf/Panther replacements for now, as NPCs are complex)
    for(let i=0; i<3; i++) {
        const angle = (i / 3) * Math.PI * 2;
        ents.push({
            id: `monument-${cx}-${cy}-guard-${i}`, type: EntityType.WOLF,
            pos: { x: baseX + Math.cos(angle)*80, y: baseY + Math.sin(angle)*80 },
            size: 25, health: 150, maxHealth: 150, rotation: angle, velocity: {x:0,y:0},
            color: '#ef4444', aiState: 'PATROL', aiTimer: 0
        });
    }

    // Walls
    for(let i=0; i<4; i++) {
         const angle = (i / 4) * Math.PI * 2 + Math.PI/4;
         ents.push({
             id: `monument-${cx}-${cy}-wall-${i}`, type: EntityType.STONE_WALL,
             pos: { x: baseX + Math.cos(angle)*120, y: baseY + Math.sin(angle)*120 },
             size: 100, health: 500, maxHealth: 500, rotation: angle + Math.PI/2,
             velocity: {x:0, y:0}, color: '#57534e', isBuilding: true
         });
    }
    
    // Extra Scattered Loot
    for(let i=0; i<2; i++) {
        ents.push({
            id: `monument-${cx}-${cy}-extra-${i}`, type: EntityType.MILITARY_CRATE,
            pos: { x: baseX + (Math.random()-0.5)*150, y: baseY + (Math.random()-0.5)*150 },
            size: 30, health: 200, maxHealth: 200, rotation: Math.random()*6, velocity: {x:0,y:0}, color: '#166534',
            containerItems: generateLootFromTable('MILITARY')
        });
    }

    return ents;
};

export const generateEntitiesForChunk = (cx: number, cy: number): Entity[] => {
  const seed = hashCoords(cx, cy);

  // Check map bounds first - no generation outside
  const centerX = cx * CHUNK_SIZE;
  const centerY = cy * CHUNK_SIZE;
  const dist = Math.sqrt(centerX*centerX + centerY*centerY);
  if (dist > WORLD_EDGE_RADIUS + CHUNK_SIZE) return []; // Empty chunk

  if (seededRandom(seed + 123) > 0.98) {
      return spawnMonument(cx, cy);
  }

  const entities: Entity[] = [];
  const density = 350; // Increased density for larger chunks
  
  for (let i = 0; i < density; i++) {
    const r1 = seededRandom(seed + i * 0.1);
    const r2 = seededRandom(seed + i * 0.2);
    const r3 = seededRandom(seed + i * 0.3);
    const r4 = seededRandom(seed + i * 0.4); 
    const posX = cx * CHUNK_SIZE + r1 * CHUNK_SIZE;
    const posY = cy * CHUNK_SIZE + r2 * CHUNK_SIZE;
    const pos = { x: posX, y: posY };
    
    const biome = getBiomeAt(pos);
    if (biome === 'OCEAN') continue; // Skip deep ocean entities
    if (biome === 'LAKE' && r3 > 0.4) continue; 

    let type = getWeightedTypeForBiome(biome, r3);
    
    if (!type) continue; 

    let variant = Math.floor(r4 * 3);
    
    // Convert generic ROCK to specific ores based on biome probability
    if (type === EntityType.ROCK) {
        if (biome === 'DESERT') {
             if (r4 < 0.3) type = EntityType.SULFUR_ORE_NODE;
             else if (r4 < 0.6) type = EntityType.METAL_ORE_NODE;
             else type = EntityType.STONE_ORE_NODE;
        } else if (biome === 'SNOW') {
             if (r4 < 0.1) type = EntityType.SULFUR_ORE_NODE;
             else if (r4 < 0.5) type = EntityType.METAL_ORE_NODE;
             else type = EntityType.STONE_ORE_NODE;
        } else {
             if (r4 < 0.15) type = EntityType.SULFUR_ORE_NODE;
             else if (r4 < 0.4) type = EntityType.METAL_ORE_NODE;
             else type = EntityType.STONE_ORE_NODE;
        }
    }

    // Rare chance to override with special loot
    if (!type.includes('TREE') && !type.includes('NODE')) {
        if (r4 > 0.98) type = EntityType.MILITARY_CRATE;
        else if (r4 > 0.95) type = EntityType.TOOL_BOX;
    }
    
    let size = 30;
    if (LOOT_CONTAINER_DATA[type]) size = LOOT_CONTAINER_DATA[type].size;
    let health = getBaseHealth(type);
    let maxHealth = health;

    if (type === EntityType.TREE) {
        size = 40 + r4 * 30;
        health = 100 + r4 * 50;
    } else if (type === EntityType.STONE_ORE_NODE || type === EntityType.METAL_ORE_NODE || type === EntityType.SULFUR_ORE_NODE) {
        if (r4 > 0.7) { size = 20; health = 50; } else { size = 35 + r4 * 20; }
    } else if (type === EntityType.BUSH) {
        size = 25 + r4 * 10;
    } else if (type === EntityType.HEMP_FIBERS) {
        size = 20;
    } else if (type === EntityType.MUSHROOM) {
        size = 10;
    } else if (type.includes('BERRY_BUSH')) {
        size = 22;
    } else if (type.includes('SCATTERED')) {
        size = 15;
    } else if (type === EntityType.STUMP) {
        size = 18;
    }

    let overlaps = false;
    for (const existing of entities) {
        const dx = existing.pos.x - pos.x;
        const dy = existing.pos.y - pos.y;
        if (dx*dx + dy*dy < ((existing.size + size) * 0.8) ** 2) {
            overlaps = true;
            break;
        }
    }
    if (overlaps) continue;
    
    const ent: Entity = {
      id: `chunk-${cx}-${cy}-ent-${i}`, type, pos, size,
      health, maxHealth,
      rotation: r3 * Math.PI * 2, velocity: { x: 0, y: 0 }, color: getBaseColor(type, biome),
      variant
    };

    if (LOOT_CONTAINER_DATA[type]) {
        ent.containerItems = generateLootFromTable(LOOT_CONTAINER_DATA[type].table);
    } else if (type === EntityType.LOOT_CRATE) {
        ent.containerItems = generateLootFromTable('CRATE');
    }

    entities.push(ent);
  }

  // Wildlife Spawning
  const wildlifeChance = 0.35; 
  if (seededRandom(seed + 999) < wildlifeChance) {
    const rx = seededRandom(seed + 888), ry = seededRandom(seed + 777), rt = seededRandom(seed + 666);
    const pos = { x: cx * CHUNK_SIZE + rx * CHUNK_SIZE, y: cy * CHUNK_SIZE + ry * CHUNK_SIZE };
    const biome = getBiomeAt(pos);
    
    if (biome !== 'OCEAN') {
        let animalType: EntityType | null = null;
        let size = 25;
        let hp = 100;

        if (biome === 'LAKE') {
            animalType = rt > 0.5 ? EntityType.SHARK : EntityType.CROCODILE;
            size = animalType === EntityType.SHARK ? 40 : 35;
            hp = 200;
        } else if (biome === 'SNOW') {
            animalType = rt > 0.6 ? EntityType.POLAR_BEAR : EntityType.WOLF;
            size = animalType === EntityType.POLAR_BEAR ? 45 : 25;
            hp = animalType === EntityType.POLAR_BEAR ? 400 : 100;
        } else if (biome === 'DESERT') {
            animalType = rt > 0.5 ? EntityType.SNAKE : EntityType.HORSE;
            size = animalType === EntityType.HORSE ? 35 : 15;
            hp = animalType === EntityType.HORSE ? 150 : 50;
        } else if (biome === 'FOREST') {
            const r = rt * 10;
            if (r < 2) animalType = EntityType.BEAR;
            else if (r < 4) animalType = EntityType.WOLF;
            else if (r < 6) animalType = EntityType.STAG;
            else if (r < 8) animalType = EntityType.BOAR;
            else animalType = EntityType.PANTHER;
            
            size = animalType === EntityType.BEAR ? 45 : (animalType === EntityType.STAG ? 35 : 25);
            hp = animalType === EntityType.BEAR ? 300 : 100;
        } else { // GRASSLANDS
            const r = rt * 10;
            if (r < 3) animalType = EntityType.HORSE;
            else if (r < 5) animalType = EntityType.BOAR;
            else if (r < 7) animalType = EntityType.STAG;
            else animalType = EntityType.CHICKEN;
            
            size = animalType === EntityType.HORSE ? 35 : (animalType === EntityType.CHICKEN ? 15 : 25);
            hp = animalType === EntityType.HORSE ? 150 : (animalType === EntityType.CHICKEN ? 30 : 100);
        }

        if (animalType) {
            entities.push({
                id: `chunk-${cx}-${cy}-wildlife-${Date.now()}`, type: animalType, pos,
                size,
                health: hp,
                maxHealth: hp,
                rotation: rt * Math.PI * 2, velocity: { x: 0, y: 0 }, color: '#000',
                aiState: 'WANDER', aiTimer: Math.random() * 100
            });
        }
    }
  }
  return entities;
};

export const generateWorld = (): Entity[] => {
    return []; // Deprecated, using generateEntitiesForChunk
};
export const LAKES = [];
