
import { ItemType, EntityType, Recipe, ItemCategory } from './types';

export const WORLD_SIZE = 1000000; 
export const CHUNK_SIZE = 2048; 
export const MAP_CHUNK_RADIUS = 6; // Creates a 13x13 chunk world (approx 26k x 26k pixels)
export const WORLD_EDGE_RADIUS = MAP_CHUNK_RADIUS * CHUNK_SIZE;
export const VIEW_RADIUS = 1; 
export const PLAYER_SPEED = 2.5; 
export const STAMINA_REGEN = 0.5;
export const HUNGER_DECAY = 0.005;
export const THIRST_DECAY = 0.008;
export const BASE_INVENTORY_SLOTS = 24; 
export const BACKPACK_SLOT_BONUS = 0; 
export const CONTAINER_SLOTS = 12;

export interface ItemStaticData {
  name: string;
  color: string;
  description: string;
  stackSize: number;
  category: ItemCategory;
  maxDurability?: number;
  damage?: number;
  throwable?: boolean;
  restore?: { health?: number; hunger?: number; thirst?: number };
}

const DEFAULT_WEAPON = (name: string): ItemStaticData => ({ name, color: '#333', description: 'A weapon.', stackSize: 1, category: ItemCategory.WEAPON, maxDurability: 150, damage: 30 });
const DEFAULT_ATTACHMENT = (name: string): ItemStaticData => ({ name, color: '#111', description: 'Weapon attachment.', stackSize: 1, category: ItemCategory.ATTACHMENT });
const DEFAULT_AMMO = (name: string): ItemStaticData => ({ name, color: '#333', description: 'Ammunition.', stackSize: 128, category: ItemCategory.AMMO });

export const ITEM_DATA: Record<ItemType, ItemStaticData> = {
  [ItemType.WOOD]: { name: 'Wood', color: '#78350f', description: 'Basic branches from trees.', stackSize: 1000, category: ItemCategory.RESOURCE },
  [ItemType.STONE]: { name: 'Stone', color: '#57534e', description: 'Hard rocks found on the ground.', stackSize: 1000, category: ItemCategory.RESOURCE },
  [ItemType.METAL_ORE]: { name: 'Iron Ore', color: '#404040', description: 'Heavy rocks with metal inside.', stackSize: 1000, category: ItemCategory.RESOURCE },
  [ItemType.SULFUR_ORE]: { name: 'Sulfur Ore', color: '#ca8a04', description: 'Yellow rocks that smell bad.', stackSize: 1000, category: ItemCategory.RESOURCE },
  [ItemType.IRON_BAR]: { name: 'Iron Bar', color: '#cbd5e1', description: 'Refined pieces of metal.', stackSize: 100, category: ItemCategory.RESOURCE },
  [ItemType.STEEL_BAR]: { name: 'Steel Bar', color: '#475569', description: 'Strong hardened metal.', stackSize: 100, category: ItemCategory.RESOURCE },
  [ItemType.SULFUR]: { name: 'Sulfur', color: '#eab308', description: 'Processed yellow powder.', stackSize: 1000, category: ItemCategory.RESOURCE },
  [ItemType.FOOD_CAN]: { name: 'Food Bag', color: '#a3e635', description: 'A small bag of dried fruit and meat.', stackSize: 64, category: ItemCategory.CONSUMABLE, restore: { hunger: 40, health: 5 } },
  [ItemType.WATER_BOTTLE]: { name: 'Water Bottle', color: '#38bdf8', description: 'A bottle of clean river water.', stackSize: 64, category: ItemCategory.CONSUMABLE, restore: { thirst: 60 } },
  [ItemType.AXE]: { name: 'Wooden Axe', color: '#71717a', description: 'Helps you get wood faster.', stackSize: 1, maxDurability: 60, category: ItemCategory.TOOL, damage: 15 },
  [ItemType.PICKAXE]: { name: 'Wooden Pickaxe', color: '#71717a', description: 'Helps you break big rocks.', stackSize: 1, maxDurability: 60, category: ItemCategory.TOOL, damage: 12 },
  [ItemType.IRON_AXE]: { name: 'Iron Axe', color: '#94a3b8', description: 'A sharp metal tool for wood.', stackSize: 1, maxDurability: 200, category: ItemCategory.TOOL, damage: 25 },
  [ItemType.IRON_PICKAXE]: { name: 'Iron Pickaxe', color: '#94a3b8', description: 'A strong metal tool for stone.', stackSize: 1, maxDurability: 200, category: ItemCategory.TOOL, damage: 20 },
  [ItemType.SPEAR]: { name: 'Wooden Spear', color: '#d4d4d8', description: 'A sharp stick for hunting.', stackSize: 1, maxDurability: 80, category: ItemCategory.TOOL, damage: 20 },
  [ItemType.IRON_SPEAR]: { name: 'Iron Spear', color: '#94a3b8', description: 'A metal tip on a strong stick.', stackSize: 1, maxDurability: 300, category: ItemCategory.TOOL, damage: 35 },
  [ItemType.SCRAP_METAL]: { name: 'Metal Bits', color: '#a1a1aa', description: 'Broken pieces of old things.', stackSize: 1000, category: ItemCategory.RESOURCE },
  [ItemType.FIBER]: { name: 'Plant String', color: '#4d7c0f', description: 'Tough grass used to make rope.', stackSize: 1000, category: ItemCategory.RESOURCE },
  [ItemType.ROPE]: { name: 'Rope', color: '#a16207', description: 'Strong string tied together.', stackSize: 100, category: ItemCategory.RESOURCE },
  [ItemType.CLOTH]: { name: 'Cloth', color: '#f8fafc', description: 'Pieces of soft fabric.', stackSize: 1000, category: ItemCategory.RESOURCE },
  [ItemType.LEATHER]: { name: 'Animal Skin', color: '#451a03', description: 'Dried skin from a hunt.', stackSize: 1000, category: ItemCategory.RESOURCE },
  [ItemType.PLASTIC]: { name: 'Plastic Bits', color: '#94a3b8', description: 'Small pieces of old plastic.', stackSize: 1000, category: ItemCategory.RESOURCE },
  [ItemType.BUILDING_PLAN]: { name: 'Building Plan', color: '#3b82f6', description: 'A drawing of how to build a house.', stackSize: 1, category: ItemCategory.TOOL },
  [ItemType.HAMMER]: { name: 'Hammer', color: '#4b5563', description: 'Used to fix or upgrade your walls.', stackSize: 1, maxDurability: 100, category: ItemCategory.TOOL, damage: 5 },
  [ItemType.BANDAGE]: { name: 'Bandage', color: '#fef2f2', description: 'Helps you heal wounds.', stackSize: 64, category: ItemCategory.CONSUMABLE, restore: { health: 15 } },
  [ItemType.MEDKIT]: { name: 'Medicine Box', color: '#ef4444', description: 'Better healing for bad hurts.', stackSize: 64, category: ItemCategory.CONSUMABLE, restore: { health: 50 } },
  [ItemType.COOKED_MEAT]: { name: 'Cooked Meat', color: '#991b1b', description: 'A good warm meal.', stackSize: 64, category: ItemCategory.CONSUMABLE, restore: { hunger: 30, health: 10 } },
  [ItemType.COMPASS]: { name: 'North Finder', color: '#1e293b', description: 'Helps you see which way is North.', stackSize: 1, category: ItemCategory.EQUIPMENT },
  [ItemType.MAP]: { name: 'Paper Map', color: '#f5f5f4', description: 'A drawing of the land.', stackSize: 1, category: ItemCategory.EQUIPMENT },
  [ItemType.ROCK_TOOL]: { name: 'Small Rock Tool', color: '#57534e', description: 'A simple rock used as a tool.', stackSize: 1, maxDurability: 40, category: ItemCategory.TOOL, damage: 10 },
  [ItemType.TORCH]: { name: 'Torch', color: '#ea580c', description: 'A stick that is on fire to see at night.', stackSize: 1, maxDurability: 60, category: ItemCategory.TOOL, damage: 8 },
  [ItemType.BERRY]: { name: 'Wild Berries', color: '#be123c', description: 'Small fruit found on bushes.', stackSize: 64, category: ItemCategory.CONSUMABLE, restore: { hunger: 5, thirst: 3 } },
  [ItemType.HERB]: { name: 'Green Leaves', color: '#166534', description: 'Plants that can help you heal.', stackSize: 64, category: ItemCategory.RESOURCE, restore: { health: 2 } },
  [ItemType.BACKPACK]: { name: 'Leather Bag', color: '#78350f', description: 'A bag to carry more things.', stackSize: 1, category: ItemCategory.EQUIPMENT },
  [ItemType.FISHING_ROD]: { name: 'Fishing Stick', color: '#a16207', description: 'Used to catch fish in water.', stackSize: 1, maxDurability: 30, category: ItemCategory.TOOL },
  [ItemType.FISH]: { name: 'Raw Fish', color: '#0ea5e9', description: 'A fish caught from the water.', stackSize: 64, category: ItemCategory.CONSUMABLE, restore: { hunger: 15, health: 3 } },
  [ItemType.SLEEPING_BAG_ITEM]: { name: 'Sleeping Bag', color: '#b91c1c', description: 'A soft place to rest.', stackSize: 1, category: ItemCategory.CONSTRUCTION },
  [ItemType.BOW]: { name: 'Hunting Bow', color: '#78350f', description: 'Shoot arrows at distant targets.', stackSize: 1, maxDurability: 100, category: ItemCategory.TOOL },
  [ItemType.ARROW]: { name: 'Wooden Arrow', color: '#d6d3d1', description: 'Ammo for the bow.', stackSize: 64, category: ItemCategory.AMMO },
  [ItemType.HEMP_SEED]: { name: 'Hemp Seeds', color: '#3f6212', description: 'Plant in ground to grow fiber.', stackSize: 20, category: ItemCategory.RESOURCE },
  [ItemType.BERRY_SEED]: { name: 'Berry Seeds', color: '#9f1239', description: 'Plant to grow a berry bush.', stackSize: 20, category: ItemCategory.RESOURCE },
  [ItemType.PUMPKIN_SEED]: { name: 'Pumpkin Seeds', color: '#ca8a04', description: 'Grow big orange pumpkins.', stackSize: 20, category: ItemCategory.RESOURCE },
  [ItemType.PUMPKIN]: { name: 'Pumpkin', color: '#ea580c', description: 'A large nutritious vegetable.', stackSize: 20, category: ItemCategory.CONSUMABLE, restore: { hunger: 20, thirst: 5 } },
  [ItemType.WOLF_FUR_COAT]: { name: 'Wolf Fur Coat', color: '#451a03', description: 'Warm coat for cold nights.', stackSize: 1, category: ItemCategory.EQUIPMENT },
  [ItemType.GRENADE]: { name: 'Bean Can Grenade', color: '#166534', description: 'Explosive device. Throw to use.', stackSize: 5, category: ItemCategory.WEAPON, throwable: true, damage: 80 },
  [ItemType.BLUEPRINT]: { name: 'Blueprint', color: '#3b82f6', description: 'Study to learn new crafting recipes.', stackSize: 100, category: ItemCategory.COMPONENT },
  [ItemType.TOOL_CUPBOARD_ITEM]: { name: 'Tool Cupboard', color: '#713f12', description: 'Prevents your base from decaying.', stackSize: 1, category: ItemCategory.CONSTRUCTION },
  
  [ItemType.BLUE_BERRY]: { name: 'Blue Berry', color: '#2563eb', description: 'Sweet wild berry.', stackSize: 64, category: ItemCategory.CONSUMABLE, restore: { hunger: 5, thirst: 5, health: 1 } },
  [ItemType.GREEN_BERRY]: { name: 'Green Berry', color: '#65a30d', description: 'Sour but edible.', stackSize: 64, category: ItemCategory.CONSUMABLE, restore: { hunger: 2, thirst: 2, health: 1 } },
  [ItemType.RED_BERRY]: { name: 'Red Berry', color: '#dc2626', description: 'Common red berry.', stackSize: 64, category: ItemCategory.CONSUMABLE, restore: { hunger: 5, thirst: 3, health: 2 } },
  [ItemType.WHITE_BERRY]: { name: 'White Berry', color: '#e2e8f0', description: 'Rare mountain berry.', stackSize: 64, category: ItemCategory.CONSUMABLE, restore: { hunger: 5, thirst: 5, health: 3 } },
  [ItemType.YELLOW_BERRY]: { name: 'Yellow Berry', color: '#facc15', description: 'Bright yellow berry.', stackSize: 64, category: ItemCategory.CONSUMABLE, restore: { hunger: 5, thirst: 2, health: 1 } },
  [ItemType.DIESEL_FUEL]: { name: 'Diesel Fuel', color: '#b91c1c', description: 'High grade fuel for machines.', stackSize: 64, category: ItemCategory.RESOURCE },
  [ItemType.MUSHROOM]: { name: 'Mushroom', color: '#78350f', description: 'Forest fungus. Good eating.', stackSize: 64, category: ItemCategory.CONSUMABLE, restore: { hunger: 10, health: 3 } },
  [ItemType.CORN]: { name: 'Corn', color: '#facc15', description: 'Fresh ear of corn.', stackSize: 64, category: ItemCategory.CONSUMABLE, restore: { hunger: 20, thirst: 5, health: 5 } },
  [ItemType.POTATO]: { name: 'Potato', color: '#a16207', description: 'Hardy vegetable.', stackSize: 64, category: ItemCategory.CONSUMABLE, restore: { hunger: 25, health: 2 } },
  [ItemType.WHEAT_SEED]: { name: 'Wheat Seeds', color: '#fef08a', description: 'Seeds from wild wheat.', stackSize: 64, category: ItemCategory.RESOURCE },

  // --- CONSTRUCTION ITEMS ---
  [ItemType.ARMORED_DOOR]: { name: 'Armored Door', color: '#1f2937', description: 'Heavy protection.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 800 },
  [ItemType.ARMORED_DOUBLE_DOOR]: { name: 'Armored Double Door', color: '#1f2937', description: 'Double wide heavy protection.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 800 },
  [ItemType.BARBED_WOODEN_BARRICADE]: { name: 'Barbed Wooden Barricade', color: '#78350f', description: 'Hurts to touch.', stackSize: 10, category: ItemCategory.CONSTRUCTION, maxDurability: 150 },
  [ItemType.BEEHIVE]: { name: 'Beehive', color: '#facc15', description: 'Honey production.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 100 },
  [ItemType.CHAINLINK_FENCE]: { name: 'Chainlink Fence', color: '#9ca3af', description: 'See through protection.', stackSize: 10, category: ItemCategory.CONSTRUCTION, maxDurability: 100 },
  [ItemType.CHAINLINK_FENCE_GATE]: { name: 'Chainlink Fence Gate', color: '#9ca3af', description: 'Gate for fence.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 100 },
  [ItemType.CODE_LOCK]: { name: 'Code Lock', color: '#ef4444', description: 'Secure with a PIN.', stackSize: 10, category: ItemCategory.COMPONENT },
  [ItemType.CONCRETE_BARRICADE]: { name: 'Concrete Barricade', color: '#9ca3af', description: 'Solid cover.', stackSize: 10, category: ItemCategory.CONSTRUCTION, maxDurability: 500 },
  [ItemType.DOOR_CLOSER]: { name: 'Door Closer', color: '#4b5563', description: 'Closes doors automatically.', stackSize: 5, category: ItemCategory.COMPONENT },
  [ItemType.FLOOR_GRILL]: { name: 'Floor Grill', color: '#4b5563', description: 'See through floor.', stackSize: 10, category: ItemCategory.CONSTRUCTION, maxDurability: 150 },
  [ItemType.FLOOR_TRIANGLE_GRILL]: { name: 'Triangle Floor Grill', color: '#4b5563', description: 'Triangular grill.', stackSize: 10, category: ItemCategory.CONSTRUCTION, maxDurability: 150 },
  [ItemType.GARAGE_DOOR]: { name: 'Garage Door', color: '#f97316', description: 'Roll up door.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 300 },
  [ItemType.HIGH_EXTERNAL_STONE_GATE]: { name: 'High External Stone Gate', color: '#57534e', description: 'Large stone gate.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 1000 },
  [ItemType.HIGH_EXTERNAL_STONE_WALL]: { name: 'High External Stone Wall', color: '#57534e', description: 'Large defensive wall.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 1000 },
  [ItemType.HIGH_EXTERNAL_WOODEN_GATE]: { name: 'High External Wooden Gate', color: '#78350f', description: 'Large wooden gate.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 600 },
  [ItemType.HIGH_EXTERNAL_WOODEN_WALL]: { name: 'High External Wooden Wall', color: '#78350f', description: 'Large defensive wood wall.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 600 },
  [ItemType.HIGH_ICE_WALL]: { name: 'High Ice Wall', color: '#e0f2fe', description: 'Wall made of ice.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 400 },
  [ItemType.KEY_LOCK]: { name: 'Key Lock', color: '#a16207', description: 'Lock with a physical key.', stackSize: 10, category: ItemCategory.COMPONENT },
  [ItemType.LADDER_HATCH]: { name: 'Ladder Hatch', color: '#4b5563', description: 'Vertical access.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 250 },
  [ItemType.LARGE_WATER_CATCHER]: { name: 'Large Water Catcher', color: '#3b82f6', description: 'Collects rain water.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 200 },
  [ItemType.LEGACY_WOOD_SHELTER]: { name: 'Wood Shelter', color: '#78350f', description: 'Simple 1x1 shelter.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 200 },
  [ItemType.MEDIEVAL_BARRICADE]: { name: 'Medieval Barricade', color: '#78350f', description: 'Old style defense.', stackSize: 5, category: ItemCategory.CONSTRUCTION, maxDurability: 100 },
  [ItemType.METAL_BARRICADE]: { name: 'Metal Barricade', color: '#4b5563', description: 'Sharp metal spikes.', stackSize: 10, category: ItemCategory.CONSTRUCTION, maxDurability: 300 },
  [ItemType.METAL_SHOP_FRONT]: { name: 'Metal Shop Front', color: '#4b5563', description: 'Secure trading window.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 400 },
  [ItemType.METAL_VERTICAL_EMBRASURE]: { name: 'Metal Vertical Embrasure', color: '#4b5563', description: 'Window slit.', stackSize: 10, category: ItemCategory.CONSTRUCTION, maxDurability: 300 },
  [ItemType.METAL_WINDOW_BARS]: { name: 'Metal Window Bars', color: '#4b5563', description: 'Protects windows.', stackSize: 10, category: ItemCategory.CONSTRUCTION, maxDurability: 300 },
  [ItemType.METAL_HORIZONTAL_EMBRASURE]: { name: 'Metal Horizontal Embrasure', color: '#4b5563', description: 'Window slit.', stackSize: 10, category: ItemCategory.CONSTRUCTION, maxDurability: 300 },
  [ItemType.MINING_QUARRY]: { name: 'Mining Quarry', color: '#57534e', description: 'Auto mine resources.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 1000 },
  [ItemType.NETTING]: { name: 'Netting', color: '#a16207', description: 'Climbable net.', stackSize: 5, category: ItemCategory.CONSTRUCTION, maxDurability: 50 },
  [ItemType.PRISON_CELL_GATE]: { name: 'Prison Cell Gate', color: '#374151', description: 'Jail door.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 250 },
  [ItemType.PRISON_CELL_WALL]: { name: 'Prison Cell Wall', color: '#374151', description: 'Jail bars.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 250 },
  [ItemType.PUMP_JACK]: { name: 'Pump Jack', color: '#b91c1c', description: 'Extracts oil.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 1000 },
  [ItemType.REINFORCED_GLASS_WINDOW]: { name: 'Reinforced Glass Window', color: '#bae6fd', description: 'Strong glass.', stackSize: 10, category: ItemCategory.CONSTRUCTION, maxDurability: 150 },
  [ItemType.SANDBAG_BARRICADE]: { name: 'Sandbag Barricade', color: '#a16207', description: 'Sandbag cover.', stackSize: 10, category: ItemCategory.CONSTRUCTION, maxDurability: 150 },
  [ItemType.SHEET_METAL_DOOR]: { name: 'Sheet Metal Door', color: '#64748b', description: 'Better than wood.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 250 },
  [ItemType.SHEET_METAL_DOUBLE_DOOR]: { name: 'Sheet Metal Double Door', color: '#64748b', description: 'Double wide metal door.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 250 },
  [ItemType.SHOP_FRONT]: { name: 'Shop Front', color: '#78350f', description: 'Wooden trading window.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 200 },
  [ItemType.SHORT_ICE_WALL]: { name: 'Short Ice Wall', color: '#e0f2fe', description: 'Low wall of ice.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 200 },
  [ItemType.SMALL_WATER_CATCHER]: { name: 'Small Water Catcher', color: '#3b82f6', description: 'Collects rain water.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 100 },
  [ItemType.STONE_BARRICADE]: { name: 'Stone Barricade', color: '#57534e', description: 'Pile of rocks.', stackSize: 10, category: ItemCategory.CONSTRUCTION, maxDurability: 200 },
  [ItemType.STRENGTHENED_GLASS_WINDOW]: { name: 'Strengthened Glass Window', color: '#bae6fd', description: 'Medium strength glass.', stackSize: 10, category: ItemCategory.CONSTRUCTION, maxDurability: 100 },
  [ItemType.TRIANGLE_LADDER_HATCH]: { name: 'Triangle Ladder Hatch', color: '#4b5563', description: 'Triangular hatch.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 250 },
  [ItemType.WALL_DIVIDER]: { name: 'Wall Divider', color: '#78350f', description: 'Splits rooms.', stackSize: 5, category: ItemCategory.CONSTRUCTION, maxDurability: 100 },
  [ItemType.WATCH_TOWER]: { name: 'Watch Tower', color: '#78350f', description: 'Tall wooden tower.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 300 },
  [ItemType.WOOD_DOUBLE_DOOR]: { name: 'Wood Double Door', color: '#78350f', description: 'Double wide wood door.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 200 },
  [ItemType.WOOD_SHUTTERS]: { name: 'Wood Shutters', color: '#78350f', description: 'Covers windows.', stackSize: 10, category: ItemCategory.CONSTRUCTION, maxDurability: 100 },
  [ItemType.WOODEN_BARRICADE]: { name: 'Wooden Barricade', color: '#78350f', description: 'Simple cover.', stackSize: 10, category: ItemCategory.CONSTRUCTION, maxDurability: 100 },
  [ItemType.WOODEN_BARRICADE_COVER]: { name: 'Wooden Barricade Cover', color: '#78350f', description: 'Reinforced cover.', stackSize: 10, category: ItemCategory.CONSTRUCTION, maxDurability: 120 },
  [ItemType.WOODEN_DOOR]: { name: 'Wooden Door', color: '#78350f', description: 'Basic entry protection.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 200 },
  [ItemType.WOODEN_FRONTIER_BAR_DOORS]: { name: 'Saloon Doors', color: '#78350f', description: 'Stylish swinging doors.', stackSize: 1, category: ItemCategory.CONSTRUCTION, maxDurability: 100 },
  [ItemType.WOODEN_LADDER]: { name: 'Wooden Ladder', color: '#78350f', description: 'Climb walls.', stackSize: 5, category: ItemCategory.CONSTRUCTION, maxDurability: 50 },
  [ItemType.WOODEN_WINDOW_BARS]: { name: 'Wooden Window Bars', color: '#78350f', description: 'Window protection.', stackSize: 10, category: ItemCategory.CONSTRUCTION, maxDurability: 100 },

  // --- WEAPONS ---
  [ItemType.ASSAULT_RIFLE]: { name: 'Assault Rifle', color: '#1c1917', description: 'Automatic rifle. Reliable and deadly.', stackSize: 1, category: ItemCategory.WEAPON, maxDurability: 300, damage: 50 },
  [ItemType.BOLT_ACTION_RIFLE]: { name: 'Bolt Action Rifle', color: '#3f3f46', description: 'High damage, slow fire rate. Good for sniping.', stackSize: 1, category: ItemCategory.WEAPON, maxDurability: 300, damage: 80 },
  [ItemType.L96_RIFLE]: { name: 'L96 Rifle', color: '#166534', description: 'Military grade sniper rifle.', stackSize: 1, category: ItemCategory.WEAPON, maxDurability: 400, damage: 90 },
  [ItemType.M249]: { name: 'M249', color: '#1c1917', description: 'High capacity machine gun.', stackSize: 1, category: ItemCategory.WEAPON, maxDurability: 500, damage: 60 },
  [ItemType.REVOLVER]: { name: 'Revolver', color: '#78716c', description: 'Simple 8-shot revolver.', stackSize: 1, category: ItemCategory.WEAPON, maxDurability: 150, damage: 35 },
  [ItemType.WATERPIPE_SHOTGUN]: { name: 'Waterpipe Shotgun', color: '#57534e', description: 'Single shot primitive shotgun.', stackSize: 1, category: ItemCategory.WEAPON, maxDurability: 100, damage: 160 },

  // MISSING ITEMS FILLED BELOW
  [ItemType.SCOPE_8X]: DEFAULT_ATTACHMENT('8x Scope'),
  [ItemType.BALLISTA]: DEFAULT_WEAPON('Ballista'),
  [ItemType.BATTERING_RAM]: DEFAULT_WEAPON('Battering Ram'),
  [ItemType.BEE_GRENADE]: DEFAULT_WEAPON('Bee Grenade'),
  [ItemType.BLOW_PIPE]: DEFAULT_WEAPON('Blow Pipe'),
  [ItemType.BONE_CLUB]: DEFAULT_WEAPON('Bone Club'),
  [ItemType.BONE_KNIFE]: DEFAULT_WEAPON('Bone Knife'),
  [ItemType.BOOMERANG]: DEFAULT_WEAPON('Boomerang'),
  [ItemType.BUTCHER_KNIFE]: DEFAULT_WEAPON('Butcher Knife'),
  [ItemType.CANDY_CANE_CLUB]: DEFAULT_WEAPON('Candy Cane Club'),
  [ItemType.CATAPULT]: DEFAULT_WEAPON('Catapult'),
  [ItemType.COMBAT_KNIFE]: DEFAULT_WEAPON('Combat Knife'),
  [ItemType.COMPOUND_BOW]: DEFAULT_WEAPON('Compound Bow'),
  [ItemType.CROSSBOW]: DEFAULT_WEAPON('Crossbow'),
  [ItemType.CUSTOM_SMG]: DEFAULT_WEAPON('Custom SMG'),
  [ItemType.DOUBLE_BARREL_SHOTGUN]: DEFAULT_WEAPON('Double Barrel Shotgun'),
  [ItemType.EOKA_PISTOL]: DEFAULT_WEAPON('Eoka Pistol'),
  [ItemType.EXTENDED_MAGAZINE]: DEFAULT_ATTACHMENT('Extended Magazine'),
  [ItemType.F1_GRENADE]: DEFAULT_WEAPON('F1 Grenade'),
  [ItemType.FLAME_THROWER]: DEFAULT_WEAPON('Flame Thrower'),
  [ItemType.FLASHBANG]: DEFAULT_WEAPON('Flashbang'),
  [ItemType.GAS_COMPRESSION_OVERDRIVE]: DEFAULT_ATTACHMENT('Gas Compression'),
  [ItemType.HMLMG]: DEFAULT_WEAPON('HMLMG'),
  [ItemType.HANDMADE_SMG]: DEFAULT_WEAPON('Handmade SMG'),
  [ItemType.HIGH_CALIBER_REVOLVER]: DEFAULT_WEAPON('High Caliber Revolver'),
  [ItemType.HOLOSIGHT]: DEFAULT_ATTACHMENT('Holosight'),
  [ItemType.HOMING_MISSILE_LAUNCHER]: DEFAULT_WEAPON('Homing Launcher'),
  [ItemType.LR300_ASSAULT_RIFLE]: DEFAULT_WEAPON('LR-300 Assault Rifle'),
  [ItemType.LONGSWORD]: DEFAULT_WEAPON('Longsword'),
  [ItemType.M39_RIFLE]: DEFAULT_WEAPON('M39 Rifle'),
  [ItemType.M4_SHOTGUN]: DEFAULT_WEAPON('M4 Shotgun'),
  [ItemType.M92_PISTOL]: DEFAULT_WEAPON('M92 Pistol'),
  [ItemType.MP5A4]: DEFAULT_WEAPON('MP5A4'),
  [ItemType.MACE]: DEFAULT_WEAPON('Mace'),
  [ItemType.MACHETE]: DEFAULT_WEAPON('Machete'),
  [ItemType.MILITARY_FLAME_THROWER]: DEFAULT_WEAPON('Military Flamethrower'),
  [ItemType.MILITARY_SILENCER]: DEFAULT_ATTACHMENT('Military Silencer'),
  [ItemType.MINI_CROSSBOW]: DEFAULT_WEAPON('Mini Crossbow'),
  [ItemType.MINIGUN]: DEFAULT_WEAPON('Minigun'),
  [ItemType.MOLOTOV_COCKTAIL]: DEFAULT_WEAPON('Molotov Cocktail'),
  [ItemType.MOUNTED_BALLISTA]: DEFAULT_WEAPON('Mounted Ballista'),
  [ItemType.MULTIPLE_GRENADE_LAUNCHER]: DEFAULT_WEAPON('Grenade Launcher'),
  [ItemType.MUZZLE_BOOST]: DEFAULT_ATTACHMENT('Muzzle Boost'),
  [ItemType.MUZZLE_BRAKE]: DEFAULT_ATTACHMENT('Muzzle Brake'),
  [ItemType.NAILGUN]: DEFAULT_WEAPON('Nailgun'),
  [ItemType.OIL_FILTER_SILENCER]: DEFAULT_ATTACHMENT('Oil Filter Silencer'),
  [ItemType.PADDLE]: DEFAULT_WEAPON('Paddle'),
  [ItemType.PITCHFORK]: DEFAULT_WEAPON('Pitchfork'),
  [ItemType.PROTOTYPE_17]: DEFAULT_WEAPON('Prototype 17'),
  [ItemType.PUMP_SHOTGUN]: DEFAULT_WEAPON('Pump Shotgun'),
  [ItemType.PYTHON_REVOLVER]: DEFAULT_WEAPON('Python Revolver'),
  [ItemType.RPG_LAUNCHER]: DEFAULT_WEAPON('RPG Launcher'),
  [ItemType.ROCKET_LAUNCHER]: DEFAULT_WEAPON('Rocket Launcher'),
  [ItemType.SKS]: DEFAULT_WEAPON('SKS'),
  [ItemType.SALVAGED_CLEAVER]: DEFAULT_WEAPON('Salvaged Cleaver'),
  [ItemType.SALVAGED_SWORD]: DEFAULT_WEAPON('Salvaged Sword'),
  [ItemType.SEMI_AUTOMATIC_PISTOL]: DEFAULT_WEAPON('Semi-Auto Pistol'),
  [ItemType.SEMI_AUTOMATIC_RIFLE]: DEFAULT_WEAPON('Semi-Auto Rifle'),
  [ItemType.SIEGE_TOWER]: DEFAULT_WEAPON('Siege Tower'),
  [ItemType.SIMPLE_HANDMADE_SIGHT]: DEFAULT_ATTACHMENT('Simple Sight'),
  [ItemType.SKINNING_KNIFE]: DEFAULT_WEAPON('Skinning Knife'),
  [ItemType.SNOWBALL]: DEFAULT_WEAPON('Snowball'),
  [ItemType.SNOWBALL_GUN]: DEFAULT_WEAPON('Snowball Gun'),
  [ItemType.SODA_CAN_SILENCER]: DEFAULT_ATTACHMENT('Soda Can Silencer'),
  [ItemType.SPAS12_SHOTGUN]: DEFAULT_WEAPON('Spas-12 Shotgun'),
  [ItemType.SPEARGUN]: DEFAULT_WEAPON('Speargun'),
  [ItemType.STONE_SPEAR]: DEFAULT_WEAPON('Stone Spear'),
  [ItemType.TARGETING_ATTACHMENT]: DEFAULT_ATTACHMENT('Targeting Computer'),
  [ItemType.THOMPSON]: DEFAULT_WEAPON('Thompson'),
  [ItemType.VAMPIRE_STAKE]: DEFAULT_WEAPON('Vampire Stake'),
  [ItemType.VARIABLE_ZOOM_SCOPE]: DEFAULT_ATTACHMENT('Variable Zoom Scope'),
  [ItemType.WATER_GUN]: DEFAULT_WEAPON('Water Gun'),
  [ItemType.WATER_PISTOL]: DEFAULT_WEAPON('Water Pistol'),
  [ItemType.WEAPON_LASERSIGHT]: DEFAULT_ATTACHMENT('Laser Sight'),
  [ItemType.WEAPON_FLASHLIGHT]: DEFAULT_ATTACHMENT('Flashlight'),
};

export const COLLECTIBLE_DATA: Record<string, { item: ItemType; count: number }> = {
  [EntityType.HEMP_FIBERS]: { item: ItemType.FIBER, count: 10 },
  [EntityType.MUSHROOM]: { item: ItemType.MUSHROOM, count: 1 },
  [EntityType.SCATTERED_STONE_ROCK]: { item: ItemType.STONE, count: 50 },
  [EntityType.SCATTERED_METAL_ROCK]: { item: ItemType.METAL_ORE, count: 20 },
  [EntityType.SCATTERED_SULFUR_ROCK]: { item: ItemType.SULFUR_ORE, count: 20 },
  [EntityType.STUMP]: { item: ItemType.WOOD, count: 50 },
  [EntityType.BLUE_BERRY_BUSH]: { item: ItemType.BLUE_BERRY, count: 3 },
  [EntityType.GREEN_BERRY_BUSH]: { item: ItemType.GREEN_BERRY, count: 3 },
  [EntityType.RED_BERRY_BUSH]: { item: ItemType.RED_BERRY, count: 3 },
  [EntityType.WHITE_BERRY_BUSH]: { item: ItemType.WHITE_BERRY, count: 3 },
  [EntityType.YELLOW_BERRY_BUSH]: { item: ItemType.YELLOW_BERRY, count: 3 },
  [EntityType.DIESEL_BARREL]: { item: ItemType.DIESEL_FUEL, count: 1 },
  [EntityType.WILD_CORN_PLANT]: { item: ItemType.CORN, count: 1 },
  [EntityType.WILD_POTATO_PLANT]: { item: ItemType.POTATO, count: 1 },
  [EntityType.WILD_PUMPKIN_PLANT]: { item: ItemType.PUMPKIN, count: 1 },
  [EntityType.WILD_WHEAT]: { item: ItemType.WHEAT_SEED, count: 1 },
};

export const RECIPES: Recipe[] = [
  { id: 'wood_spear', name: 'Wooden Spear', category: 'Weapons', requirements: [{ type: ItemType.WOOD, count: 300 }], output: ItemType.SPEAR, description: 'Basic melee weapon.' },
  { id: 'stone_axe', name: 'Stone Hatchet', category: 'Tools', requirements: [{ type: ItemType.WOOD, count: 200 }, { type: ItemType.STONE, count: 100 }], output: ItemType.AXE, description: 'Harvests wood.' },
  { id: 'stone_pickaxe', name: 'Stone Pickaxe', category: 'Tools', requirements: [{ type: ItemType.WOOD, count: 200 }, { type: ItemType.STONE, count: 100 }], output: ItemType.PICKAXE, description: 'Harvests stone and ore.' },
  { id: 'bow', name: 'Hunting Bow', category: 'Weapons', requirements: [{ type: ItemType.WOOD, count: 200 }, { type: ItemType.CLOTH, count: 50 }], output: ItemType.BOW, description: 'Ranged weapon.' },
  { id: 'arrow', name: 'Wooden Arrow x2', category: 'Ammo', requirements: [{ type: ItemType.WOOD, count: 25 }, { type: ItemType.STONE, count: 10 }], output: ItemType.ARROW, description: 'Ammo for bow.' },
  { id: 'bandage', name: 'Bandage', category: 'Medical', requirements: [{ type: ItemType.CLOTH, count: 4 }], output: ItemType.BANDAGE, description: 'Stops bleeding and heals.' },
  { id: 'sleeping_bag', name: 'Sleeping Bag', category: 'Construction', requirements: [{ type: ItemType.CLOTH, count: 30 }], output: ItemType.SLEEPING_BAG_ITEM, description: 'Respawn point.' },
  { id: 'tool_cupboard', name: 'Tool Cupboard', category: 'Construction', requirements: [{ type: ItemType.WOOD, count: 1000 }], output: ItemType.TOOL_CUPBOARD_ITEM, description: 'Base upkeep and protection.' },
  { id: 'building_plan', name: 'Building Plan', category: 'Construction', requirements: [{ type: ItemType.WOOD, count: 20 }], output: ItemType.BUILDING_PLAN, description: 'Allows building structures.' },
  { id: 'hammer', name: 'Hammer', category: 'Tools', requirements: [{ type: ItemType.WOOD, count: 100 }], output: ItemType.HAMMER, description: 'Repair and upgrade structures.' },
  { id: 'furnace', name: 'Furnace', category: 'Construction', requirements: [{ type: ItemType.STONE, count: 200 }, { type: ItemType.WOOD, count: 100 }, { type: ItemType.DIESEL_FUEL, count: 10 }], output: EntityType.FURNACE, description: 'Smelt ores.' },
  { id: 'box', name: 'Wooden Box', category: 'Construction', requirements: [{ type: ItemType.WOOD, count: 150 }], output: EntityType.STORAGE_BOX, description: 'Storage.' },
  { id: 'lock', name: 'Key Lock', category: 'Construction', requirements: [{ type: ItemType.WOOD, count: 75 }], output: ItemType.KEY_LOCK, description: 'Lock your doors.' },
  { id: 'door', name: 'Wooden Door', category: 'Construction', requirements: [{ type: ItemType.WOOD, count: 300 }], output: ItemType.WOODEN_DOOR, description: 'Basic door.' },
];

export const BLUEPRINT_COSTS: Record<string, number> = {
  'revolver': 75,
  'double_barrel': 125,
  'waterpipe': 75,
  'satchel': 125,
  'semi_rifle': 125,
  'garage_door': 75,
};

export const BUILDING_RECIPES: Record<string, { name: string; type: EntityType; requirements: { type: ItemType; count: number }[] }> = {
  'foundation': { name: 'Foundation', type: EntityType.FOUNDATION, requirements: [{ type: ItemType.WOOD, count: 50 }] },
  'triangle_foundation': { name: 'Triangle Foundation', type: EntityType.TRIANGLE_FOUNDATION, requirements: [{ type: ItemType.WOOD, count: 25 }] },
  'floor': { name: 'Floor', type: EntityType.WOOD_FLOOR, requirements: [{ type: ItemType.WOOD, count: 25 }] },
  'triangle_floor': { name: 'Triangle Floor', type: EntityType.TRIANGLE_FLOOR, requirements: [{ type: ItemType.WOOD, count: 13 }] },
  'wall': { name: 'Wall', type: EntityType.WALL, requirements: [{ type: ItemType.WOOD, count: 50 }] },
  'doorway': { name: 'Doorway', type: EntityType.DOORWAY, requirements: [{ type: ItemType.WOOD, count: 35 }] },
  'window': { name: 'Window', type: EntityType.WINDOW_WALL, requirements: [{ type: ItemType.WOOD, count: 35 }] },
  'roof': { name: 'Roof', type: EntityType.WALL, requirements: [{ type: ItemType.WOOD, count: 50 }] }, // Using Wall visual for now as placeholder
  'stairs': { name: 'Stairs', type: EntityType.STEPS, requirements: [{ type: ItemType.WOOD, count: 50 }] },
};

export const UPGRADE_DATA: Partial<Record<EntityType, EntityType>> = {
  [EntityType.WALL]: EntityType.STONE_WALL,
  [EntityType.STONE_WALL]: EntityType.METAL_WALL,
  [EntityType.METAL_WALL]: EntityType.HQ_WALL,
  [EntityType.WOOD_FLOOR]: EntityType.STONE_FLOOR,
  [EntityType.STONE_FLOOR]: EntityType.METAL_FLOOR,
  [EntityType.METAL_FLOOR]: EntityType.HQ_FLOOR,
  [EntityType.FOUNDATION]: EntityType.STONE_FOUNDATION,
  [EntityType.STONE_FOUNDATION]: EntityType.METAL_FOUNDATION,
  [EntityType.METAL_FOUNDATION]: EntityType.HQ_FOUNDATION,
  [EntityType.DOORWAY]: EntityType.STONE_WALL, // Placeholder mapping
  [EntityType.WINDOW_WALL]: EntityType.STONE_WALL, // Placeholder mapping
};

export type LootTableType = 
  'BARREL' | 'CRATE' | 'MILITARY' | 'FOOD' | 'TOOL' | 'SURVIVOR' | 'MEDICAL' | 'AMMO' | 'TECH' | 'ELITE' | 'PRIMITIVE';

export interface LootEntry {
  type: ItemType;
  weight: number; 
  min: number;
  max: number;
}

// OPTIMIZED LOOT TABLES: Rarer high-tier items
export const LOOT_TABLES: Record<LootTableType, { rolls: number, items: LootEntry[] }> = {
  BARREL: {
    rolls: 1,
    items: [
      { type: ItemType.SCRAP_METAL, weight: 100, min: 2, max: 5 }, // Guaranteed scrap + chance for others
      { type: ItemType.ROPE, weight: 30, min: 1, max: 2 },
      { type: ItemType.CLOTH, weight: 30, min: 2, max: 5 },
      { type: ItemType.FIBER, weight: 40, min: 5, max: 10 },
      { type: ItemType.METAL_ORE, weight: 20, min: 5, max: 15 },
      { type: ItemType.BLUEPRINT, weight: 2, min: 1, max: 1 } // Very Rare
    ]
  },
  CRATE: {
    rolls: 2,
    items: [
      { type: ItemType.SCRAP_METAL, weight: 80, min: 5, max: 15 },
      { type: ItemType.METAL_ORE, weight: 50, min: 20, max: 50 },
      { type: ItemType.SULFUR_ORE, weight: 50, min: 20, max: 50 },
      { type: ItemType.ROPE, weight: 40, min: 1, max: 3 },
      { type: ItemType.CLOTH, weight: 40, min: 5, max: 15 },
      { type: ItemType.IRON_BAR, weight: 20, min: 1, max: 3 },
      { type: ItemType.PICKAXE, weight: 10, min: 1, max: 1 },
      { type: ItemType.AXE, weight: 10, min: 1, max: 1 },
      { type: ItemType.REVOLVER, weight: 2, min: 1, max: 1 }, // Rare
      { type: ItemType.WATERPIPE_SHOTGUN, weight: 2, min: 1, max: 1 }, // Rare
      { type: ItemType.CROSSBOW, weight: 3, min: 1, max: 1 },
    ]
  },
  MILITARY: {
    rolls: 3,
    items: [
      { type: ItemType.SCRAP_METAL, weight: 100, min: 15, max: 30 },
      { type: ItemType.IRON_BAR, weight: 60, min: 3, max: 8 },
      { type: ItemType.STEEL_BAR, weight: 20, min: 1, max: 3 },
      { type: ItemType.GRENADE, weight: 20, min: 1, max: 2 },
      { type: ItemType.MEDKIT, weight: 30, min: 1, max: 2 },
      { type: ItemType.BLUEPRINT, weight: 15, min: 1, max: 1 },
      { type: ItemType.SEMI_AUTOMATIC_RIFLE, weight: 5, min: 1, max: 1 }, // Rare
      { type: ItemType.CUSTOM_SMG, weight: 5, min: 1, max: 1 }, // Rare
      { type: ItemType.PYTHON_REVOLVER, weight: 8, min: 1, max: 1 },
      { type: ItemType.THOMPSON, weight: 3, min: 1, max: 1 }, // Very Rare
      { type: ItemType.WOLF_FUR_COAT, weight: 5, min: 1, max: 1 }
    ]
  },
  ELITE: {
    rolls: 4,
    items: [
      { type: ItemType.STEEL_BAR, weight: 60, min: 3, max: 8 },
      { type: ItemType.IRON_BAR, weight: 50, min: 10, max: 20 },
      { type: ItemType.GRENADE, weight: 30, min: 2, max: 4 },
      { type: ItemType.IRON_SPEAR, weight: 20, min: 1, max: 1 },
      { type: ItemType.BLUEPRINT, weight: 25, min: 1, max: 1 },
      { type: ItemType.ASSAULT_RIFLE, weight: 2, min: 1, max: 1 }, // Extremely Rare
      { type: ItemType.BOLT_ACTION_RIFLE, weight: 2, min: 1, max: 1 }, // Extremely Rare
      { type: ItemType.LR300_ASSAULT_RIFLE, weight: 1, min: 1, max: 1 }, // Legendary
      { type: ItemType.M249, weight: 0.5, min: 1, max: 1 }, // Mythic
      { type: ItemType.ROCKET_LAUNCHER, weight: 1, min: 1, max: 1 }, // Legendary
    ]
  },
  FOOD: {
    rolls: 2,
    items: [
      { type: ItemType.FOOD_CAN, weight: 80, min: 1, max: 3 },
      { type: ItemType.WATER_BOTTLE, weight: 80, min: 1, max: 3 },
      { type: ItemType.PUMPKIN_SEED, weight: 30, min: 2, max: 5 },
      { type: ItemType.BERRY_SEED, weight: 30, min: 2, max: 5 },
      { type: ItemType.BERRY, weight: 50, min: 5, max: 10 },
      { type: ItemType.PUMPKIN, weight: 20, min: 1, max: 2 }
    ]
  },
  TOOL: {
    rolls: 2,
    items: [
      { type: ItemType.HAMMER, weight: 40, min: 1, max: 1 },
      { type: ItemType.AXE, weight: 40, min: 1, max: 1 },
      { type: ItemType.PICKAXE, weight: 40, min: 1, max: 1 },
      { type: ItemType.BUILDING_PLAN, weight: 30, min: 1, max: 1 },
      { type: ItemType.TORCH, weight: 30, min: 1, max: 1 },
      { type: ItemType.FISHING_ROD, weight: 20, min: 1, max: 1 },
      { type: ItemType.SCRAP_METAL, weight: 60, min: 5, max: 10 }
    ]
  },
  MEDICAL: {
    rolls: 2,
    items: [
      { type: ItemType.BANDAGE, weight: 80, min: 2, max: 5 },
      { type: ItemType.MEDKIT, weight: 20, min: 1, max: 2 },
      { type: ItemType.CLOTH, weight: 60, min: 5, max: 10 },
      { type: ItemType.HERB, weight: 40, min: 3, max: 6 }
    ]
  },
  AMMO: {
    rolls: 2,
    items: [
      { type: ItemType.ARROW, weight: 100, min: 5, max: 15 },
      { type: ItemType.GRENADE, weight: 5, min: 1, max: 1 }, // Rare in ammo crate
      { type: ItemType.SULFUR, weight: 50, min: 10, max: 20 }
    ]
  },
  TECH: {
    rolls: 1,
    items: [
      { type: ItemType.SCRAP_METAL, weight: 80, min: 10, max: 20 },
      { type: ItemType.BLUEPRINT, weight: 20, min: 1, max: 1 },
      { type: ItemType.PLASTIC, weight: 60, min: 5, max: 15 },
      { type: ItemType.SCOPE_8X, weight: 5, min: 1, max: 1 },
      { type: ItemType.HOLOSIGHT, weight: 5, min: 1, max: 1 },
      { type: ItemType.WEAPON_FLASHLIGHT, weight: 10, min: 1, max: 1 },
    ]
  },
  PRIMITIVE: {
    rolls: 2,
    items: [
      { type: ItemType.WOOD, weight: 80, min: 20, max: 60 },
      { type: ItemType.STONE, weight: 80, min: 10, max: 30 },
      { type: ItemType.ROPE, weight: 40, min: 1, max: 2 },
      { type: ItemType.ROCK_TOOL, weight: 30, min: 1, max: 1 },
      { type: ItemType.SPEAR, weight: 20, min: 1, max: 1 },
      { type: ItemType.EOKA_PISTOL, weight: 5, min: 1, max: 1 },
      { type: ItemType.BONE_CLUB, weight: 10, min: 1, max: 1 },
    ]
  },
  SURVIVOR: {
    rolls: 2,
    items: [
      { type: ItemType.ROCK_TOOL, weight: 60, min: 1, max: 1 },
      { type: ItemType.TORCH, weight: 50, min: 1, max: 1 },
      { type: ItemType.BANDAGE, weight: 40, min: 1, max: 3 },
      { type: ItemType.WOOD, weight: 70, min: 50, max: 200 },
      { type: ItemType.STONE, weight: 70, min: 20, max: 100 },
      { type: ItemType.BOW, weight: 15, min: 1, max: 1 },
      { type: ItemType.ARROW, weight: 30, min: 5, max: 15 }
    ]
  }
};

export const LOOT_CONTAINER_DATA: Record<string, { table: LootTableType, color: string, health: number, size: number }> = {
    [EntityType.APC_CRATE]: { table: 'MILITARY', color: '#14532d', health: 300, size: 35 },
    [EntityType.CRATE]: { table: 'CRATE', color: '#854d0e', health: 100, size: 25 },
    [EntityType.LOOT_CRATE]: { table: 'CRATE', color: '#854d0e', health: 100, size: 25 },
    [EntityType.ELITE_TIER_CRATE]: { table: 'ELITE', color: '#1e293b', health: 400, size: 35 },
    [EntityType.FISHERMAN_TACKLE_BOX]: { table: 'TOOL', color: '#3b82f6', health: 50, size: 20 },
    [EntityType.FOOD_CACHE]: { table: 'FOOD', color: '#a3e635', health: 50, size: 20 },
    [EntityType.FOOD_CRATE]: { table: 'FOOD', color: '#a3e635', health: 80, size: 25 },
    [EntityType.GIFT_BOX]: { table: 'SURVIVOR', color: '#ef4444', health: 30, size: 20 },
    [EntityType.GIFT_DROP]: { table: 'ELITE', color: '#ef4444', health: 100, size: 30 },
    [EntityType.GINGERBREAD_DUNGEON_CRATE]: { table: 'FOOD', color: '#78350f', health: 80, size: 25 },
    [EntityType.HELICOPTER_CRATE]: { table: 'ELITE', color: '#3f3f46', health: 500, size: 40 },
    [EntityType.LOCKED_CRATE]: { table: 'ELITE', color: '#111827', health: 600, size: 35 },
    [EntityType.LUMBERJACK_STASH]: { table: 'TOOL', color: '#92400e', health: 80, size: 25 },
    [EntityType.MEDICAL_CRATE]: { table: 'MEDICAL', color: '#fecaca', health: 80, size: 25 },
    [EntityType.MILITARY_CRATE]: { table: 'MILITARY', color: '#166534', health: 200, size: 30 },
    [EntityType.MINE_CRATE]: { table: 'TOOL', color: '#57534e', health: 100, size: 25 },
    [EntityType.MINECART]: { table: 'CRATE', color: '#44403c', health: 150, size: 35 },
    [EntityType.NATURAL_BEEHIVE]: { table: 'FOOD', color: '#facc15', health: 40, size: 20 },
    [EntityType.OIL_BARREL]: { table: 'BARREL', color: '#000000', health: 100, size: 25 },
    [EntityType.PRIMITIVE_CRATE]: { table: 'PRIMITIVE', color: '#78350f', health: 50, size: 22 },
    [EntityType.PRIMITIVE_JUNGLE_CRATE]: { table: 'PRIMITIVE', color: '#3f6212', health: 50, size: 22 },
    [EntityType.RATION_BOX]: { table: 'FOOD', color: '#713f12', health: 60, size: 20 },
    [EntityType.ROAD_SIGN]: { table: 'BARREL', color: '#facc15', health: 50, size: 20 },
    [EntityType.SHORE_CRATE]: { table: 'PRIMITIVE', color: '#d6d3d1', health: 50, size: 22 },
    [EntityType.SUNKEN_CHEST]: { table: 'ELITE', color: '#0c4a6e', health: 200, size: 30 },
    [EntityType.SUNKEN_CRATE]: { table: 'CRATE', color: '#0891b2', health: 100, size: 25 },
    [EntityType.SUPPLY_DROP]: { table: 'MILITARY', color: '#1e40af', health: 500, size: 40 },
    [EntityType.TOOL_BOX]: { table: 'TOOL', color: '#dc2626', health: 100, size: 25 },
    [EntityType.TREASURE_BOX]: { table: 'ELITE', color: '#eab308', health: 100, size: 25 },
    [EntityType.UNDERWATER_LAB_AMMO_CRATE]: { table: 'AMMO', color: '#3f3f46', health: 150, size: 25 },
    [EntityType.UNDERWATER_LAB_BLUE_CRATE]: { table: 'TECH', color: '#3b82f6', health: 150, size: 25 },
    [EntityType.UNDERWATER_LAB_COMPONENT_CRATE]: { table: 'CRATE', color: '#94a3b8', health: 150, size: 25 },
    [EntityType.UNDERWATER_LAB_ELITE_CRATE]: { table: 'ELITE', color: '#1e293b', health: 300, size: 30 },
    [EntityType.UNDERWATER_LAB_FOOD_CRATE]: { table: 'FOOD', color: '#84cc16', health: 150, size: 25 },
    [EntityType.UNDERWATER_LAB_FUEL_CRATE]: { table: 'BARREL', color: '#ef4444', health: 150, size: 25 },
    [EntityType.UNDERWATER_LAB_MEDICAL_CRATE]: { table: 'MEDICAL', color: '#fca5a5', health: 150, size: 25 },
    [EntityType.UNDERWATER_LAB_RATION_BOX]: { table: 'FOOD', color: '#a16207', health: 100, size: 20 },
    [EntityType.UNDERWATER_LAB_TECH_CRATE]: { table: 'TECH', color: '#0ea5e9', health: 150, size: 25 },
    [EntityType.UNDERWATER_LAB_TOOL_BOX]: { table: 'TOOL', color: '#f59e0b', health: 150, size: 25 },
    [EntityType.UNDERWATER_LAB_VEHICLE_PARTS_CRATE]: { table: 'TECH', color: '#64748b', health: 150, size: 25 },
    [EntityType.UNDERWATER_LAB_YELLOW_CRATE]: { table: 'CRATE', color: '#fbbf24', health: 150, size: 25 },
    [EntityType.VEHICLE_PARTS_CRATE]: { table: 'TECH', color: '#475569', health: 100, size: 25 },
    [EntityType.WAGON_CRATE]: { table: 'CRATE', color: '#57534e', health: 100, size: 30 },
    [EntityType.WAGON_FOOD_CRATE]: { table: 'FOOD', color: '#65a30d', health: 100, size: 30 },
    [EntityType.WAGON_MEDICAL_CRATE]: { table: 'MEDICAL', color: '#f87171', health: 100, size: 30 },
    [EntityType.WAGON_MILITARY_CRATE]: { table: 'MILITARY', color: '#15803d', health: 200, size: 30 }
};
