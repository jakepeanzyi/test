
import { Entity, GameSettings } from '../types';

export const drawTree = (ctx: CanvasRenderingContext2D, tree: Entity, settings: GameSettings, time: number, isShadow: boolean = false) => {
  ctx.save();
  const variant = tree.variant || 0;
  
  if (tree.hitReaction && tree.hitReaction > 0 && !isShadow) {
    const intensity = tree.hitReaction * 0.8;
    ctx.translate((Math.random() - 0.5) * intensity, (Math.random() - 0.5) * intensity);
  }

  if (isShadow) {
      ctx.fillStyle = 'rgba(0,0,0,0.2)';
      // Simplified shadow for tree
      ctx.beginPath(); ctx.arc(0, -20, tree.size * 0.5, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
      return;
  }

  // Sway - SKIP ON LOW PERF
  if (!settings.lowPerformance) {
      const sway = Math.sin(time / 2000 + tree.pos.x) * 2;
      ctx.translate(sway, 0);
  }

  // Trunk (Simple rectangle with rounded bottom)
  ctx.fillStyle = '#78350f'; // Wood color
  ctx.beginPath();
  ctx.moveTo(-6, -10); 
  ctx.lineTo(-6, 10); 
  ctx.quadraticCurveTo(0, 15, 6, 10); 
  ctx.lineTo(6, -10);
  ctx.fill();

  // Foliage (Three stacked circles/clumps for vector look)
  ctx.fillStyle = tree.color; // Base green
  
  // Bottom Clumps
  ctx.beginPath(); ctx.arc(-15, -20, 18, 0, Math.PI*2); ctx.fill();
  ctx.beginPath(); ctx.arc(15, -20, 18, 0, Math.PI*2); ctx.fill();
  
  // Top Clump
  ctx.beginPath(); ctx.arc(0, -35, 22, 0, Math.PI*2); ctx.fill();

  // Highlights - SKIP ON LOW PERF
  if (!settings.lowPerformance) {
      ctx.fillStyle = 'rgba(255,255,255,0.1)';
      ctx.beginPath(); ctx.arc(-5, -40, 8, 0, Math.PI*2); ctx.fill();
  }

  ctx.restore();
};
