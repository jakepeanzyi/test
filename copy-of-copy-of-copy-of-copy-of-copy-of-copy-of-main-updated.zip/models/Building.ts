
import { Entity, EntityType, GameSettings } from '../types';

export const drawBuilding = (ctx: CanvasRenderingContext2D, building: Entity, settings: GameSettings, time: number, isGhost: boolean = false, isShadow: boolean = false) => {
  ctx.save();
  ctx.rotate(building.rotation);
  
  const size = building.size;

  if (isShadow) {
      ctx.fillStyle = 'rgba(0,0,0,0.2)';
      // Shadow shapes for tall structures
      if ([EntityType.WALL, EntityType.STONE_WALL, EntityType.METAL_WALL, EntityType.HQ_WALL, EntityType.DOORWAY, EntityType.WINDOW_WALL, EntityType.SINGLE_DOOR].includes(building.type)) {
          ctx.fillRect(-size/2, -10, size, 20);
      } else if (building.type === EntityType.TOOL_CUPBOARD) {
          ctx.fillRect(-15, -22, 30, 45);
      }
      ctx.restore();
      return;
  }

  if (isGhost) {
    const pulse = Math.sin(time / 150) * 0.1 + 0.6;
    ctx.globalAlpha = pulse;
  }

  const drawSoftSide = () => {
      if (isGhost || settings.lowPerformance) return;
      ctx.strokeStyle = 'rgba(0,0,0,0.15)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-size/2 + 5, 0); ctx.lineTo(size/2 - 5, 10);
      ctx.moveTo(size/2 - 5, 0); ctx.lineTo(-size/2 + 5, 10);
      ctx.stroke();
  };

  const drawWoodTexture = (w: number, h: number) => {
    if (settings.lowPerformance) return;
    ctx.strokeStyle = isGhost ? 'rgba(56, 189, 248, 0.4)' : 'rgba(0,0,0,0.1)';
    ctx.lineWidth = 1;
    for (let i = -w/2 + 10; i < w/2; i += 12) {
      ctx.beginPath(); ctx.moveTo(i, -h/2); ctx.lineTo(i, h/2); ctx.stroke();
    }
  };

  const drawStoneTexture = (w: number, h: number) => {
    if (settings.lowPerformance) return;
    ctx.strokeStyle = isGhost ? 'rgba(56, 189, 248, 0.3)' : 'rgba(0,0,0,0.1)';
    ctx.lineWidth = 1;
    for (let i = 0; i < 8; i++) {
       const rx = (Math.random() - 0.5) * w;
       const ry = (Math.random() - 0.5) * h;
       ctx.beginPath(); ctx.moveTo(rx, ry); ctx.lineTo(rx + 8, ry + 8); ctx.stroke();
    }
  };

  const drawMetalTexture = (w: number, h: number) => {
    if (settings.lowPerformance) return;
    ctx.fillStyle = isGhost ? 'rgba(56, 189, 248, 0.2)' : 'rgba(255,255,255,0.1)';
    const rSize = 3;
    ctx.fillRect(-w/2 + 5, -h/2 + 5, rSize, rSize);
    ctx.fillRect(w/2 - 8, -h/2 + 5, rSize, rSize);
    ctx.fillRect(-w/2 + 5, h/2 - 8, rSize, rSize);
    ctx.fillRect(w/2 - 8, h/2 - 8, rSize, rSize);
  };

  const drawDoor = (color: string, frameColor: string, isOpen: boolean) => {
    // Only draw frame lines, no outline
    if (isOpen) {
      ctx.fillStyle = color;
      ctx.save();
      ctx.translate(-size/2 + 4, 0);
      ctx.rotate(-Math.PI / 1.5);
      ctx.fillRect(0, -3, size - 20, 6);
      ctx.restore();
    } else {
      ctx.fillStyle = color;
      ctx.fillRect(-size/2 + 10, -3, size - 20, 6);
    }
  };

  switch(building.type) {
    case EntityType.WOOD_DOOR:
    case EntityType.STONE_DOOR:
    case EntityType.METAL_DOOR: {
        const type = building.type;
        const color = isGhost ? '#0c4a6e' : (type === EntityType.WOOD_DOOR ? '#78350f' : (type === EntityType.STONE_DOOR ? '#57534e' : '#334155'));
        const frameColor = isGhost ? '#0ea5e9' : 'rgba(0,0,0,0.5)';
        drawDoor(color, frameColor, !!building.isOpen);
        break;
    }

    case EntityType.SINGLE_DOOR: {
        const type = building.type;
        const color = isGhost ? '#0c4a6e' : '#78350f';
        const frameColor = isGhost ? '#0ea5e9' : '#3f2e18';
        drawDoor(color, frameColor, !!building.isOpen);
        
        ctx.fillStyle = frameColor;
        ctx.fillRect(-size/2, -14, size, 6);
        break;
    }

    case EntityType.DOORWAY: {
        const width = size;
        const thickness = 10;
        const color = isGhost ? '#0c4a6e' : '#574c41'; 
        ctx.fillStyle = color;
        ctx.fillRect(-width/2, -thickness, 15, thickness*2);
        ctx.fillRect(width/2 - 15, -thickness, 15, thickness*2);
        ctx.fillStyle = isGhost ? '#0ea5e9' : '#4a4036';
        ctx.fillRect(-width/2, -thickness-2, width, 4); 
        drawSoftSide();
        break;
    }

    case EntityType.TOOL_CUPBOARD: {
        const w = 30; 
        const h = 45;
        ctx.fillStyle = isGhost ? '#0c4a6e' : '#2d5a27';
        ctx.fillRect(-w/2, -h/2, w, h);
        
        if (!isGhost) {
            ctx.fillStyle = '#71717a';
            ctx.fillRect(-w/2, -h/2 + 5, w, 4);
            ctx.fillRect(-w/2, h/2 - 9, w, 4);

            ctx.fillStyle = '#3f3f46';
            for(let i=0; i<3; i++) {
                ctx.fillRect(-w/2 + 4 + i*10, -h/2 + 6, 2, 2);
                ctx.fillRect(-w/2 + 4 + i*10, h/2 - 8, 2, 2);
            }

            ctx.fillStyle = '#18181b';
            ctx.fillRect(w/8, -h/6, 8, 12);
            
            const hasUpkeep = building.containerItems && building.containerItems.some(item => item !== null);
            ctx.fillStyle = hasUpkeep ? '#22c55e' : '#ef4444';
            ctx.beginPath();
            ctx.arc(w/4 + 2, -h/6 + 3, 1.5, 0, Math.PI * 2);
            ctx.fill();
        }
        break;
    }

    case EntityType.SLEEPING_BAG: {
        const w = 30;
        const h = 60;
        const baseColor = isGhost ? '#0c4a6e' : '#c2b280';
        const pillowColor = isGhost ? '#0ea5e9' : '#d2b48c';

        ctx.fillStyle = baseColor; 
        ctx.beginPath();
        ctx.roundRect(-w/2, -h/2, w, h, 8);
        ctx.fill();
        
        ctx.fillStyle = pillowColor;
        ctx.beginPath();
        ctx.roundRect(-w/2 + 4, -h/2 + 4, w - 8, 14, 4);
        ctx.fill();
        
        break;
    }

    case EntityType.TRIANGLE_FLOOR:
    case EntityType.TRIANGLE_STONE_FLOOR:
    case EntityType.TRIANGLE_METAL_FLOOR:
    case EntityType.TRIANGLE_HQ_FLOOR: {
      const type = building.type;
      const color = isGhost ? '#0c4a6e' : (type === EntityType.TRIANGLE_FLOOR ? '#78350f' : (type === EntityType.TRIANGLE_STONE_FLOOR ? '#57534e' : (type === EntityType.TRIANGLE_METAL_FLOOR ? '#334155' : '#1e293b')));
      ctx.fillStyle = color;
      const h = size * 0.866;
      ctx.beginPath();
      ctx.moveTo(0, -h/2); 
      ctx.lineTo(-size/2, h/2); 
      ctx.lineTo(size/2, h/2); 
      ctx.closePath();
      ctx.fill();
      if (type === EntityType.TRIANGLE_FLOOR) drawWoodTexture(size, size);
      if (type === EntityType.TRIANGLE_STONE_FLOOR) drawStoneTexture(size, size);
      if (type === EntityType.TRIANGLE_METAL_FLOOR || type === EntityType.TRIANGLE_HQ_FLOOR) drawMetalTexture(size, size);
      break;
    }

    case EntityType.WALL:
    case EntityType.STONE_WALL:
    case EntityType.METAL_WALL:
    case EntityType.HQ_WALL: {
      const type = building.type;
      const color = isGhost ? '#0c4a6e' : (type === EntityType.WALL ? '#78350f' : (type === EntityType.STONE_WALL ? '#57534e' : (type === EntityType.METAL_WALL ? '#334155' : '#1e293b')));
      ctx.fillStyle = color;
      ctx.fillRect(-size/2, -10, size, 20);
      if (type === EntityType.WALL) drawWoodTexture(size, 20);
      if (type === EntityType.STONE_WALL) drawStoneTexture(size, 20);
      if (type === EntityType.METAL_WALL || type === EntityType.HQ_WALL) drawMetalTexture(size, 20);
      
      drawSoftSide();
      break;
    }

    case EntityType.WOOD_FLOOR:
    case EntityType.STONE_FLOOR:
    case EntityType.METAL_FLOOR:
    case EntityType.HQ_FLOOR: {
      const type = building.type;
      const color = isGhost ? '#0c4a6e' : (type === EntityType.WOOD_FLOOR ? '#78350f' : (type === EntityType.STONE_FLOOR ? '#57534e' : (type === EntityType.METAL_FLOOR ? '#334155' : '#1e293b')));
      ctx.fillStyle = color;
      ctx.fillRect(-size/2, -size/2, size, size);
      if (type === EntityType.WOOD_FLOOR) drawWoodTexture(size, size);
      if (type === EntityType.STONE_FLOOR) drawStoneTexture(size, size);
      if (type === EntityType.METAL_FLOOR || type === EntityType.HQ_FLOOR) drawMetalTexture(size, size);
      break;
    }

    default:
      ctx.fillStyle = building.color || '#666';
      ctx.fillRect(-size / 2, -size / 2, size, size);
  }

  if (!isGhost && building.maxHealth && building.health < building.maxHealth && !settings.lowPerformance) {
      const damagePct = 1 - (building.health / building.maxHealth);
      if (damagePct > 0.1) {
          ctx.strokeStyle = 'rgba(0,0,0,0.3)';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(-10, -10); ctx.lineTo(5, 5); ctx.lineTo(-2, 12);
          ctx.stroke();
      }
      if (damagePct > 0.5) {
          ctx.beginPath();
          ctx.moveTo(15, -5); ctx.lineTo(0, 0); ctx.lineTo(10, 15);
          ctx.stroke();
      }
  }

  ctx.restore();
};
