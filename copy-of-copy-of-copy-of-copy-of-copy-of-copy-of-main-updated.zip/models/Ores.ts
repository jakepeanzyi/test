
import { Entity, EntityType, GameSettings } from '../types';

export const drawOreNode = (ctx: CanvasRenderingContext2D, node: Entity, settings: GameSettings, isShadow: boolean = false) => {
  ctx.save();
  ctx.rotate(node.rotation);

  if (isShadow) {
      ctx.fillStyle = 'rgba(0,0,0,0.2)';
      ctx.beginPath();
      // Irregular shape for shadow
      ctx.moveTo(-10, -5); ctx.lineTo(10, -8); ctx.lineTo(8, 10); ctx.lineTo(-12, 8);
      ctx.fill();
      ctx.restore();
      return;
  }

  // Hit reaction
  if (node.hitReaction && node.hitReaction > 0) {
    const intensity = node.hitReaction * 0.5;
    ctx.translate((Math.random() - 0.5) * intensity, (Math.random() - 0.5) * intensity);
  }

  let baseColor = '#a8a29e'; // Stone
  let highlightColor = '#d6d3d1';
  
  if (node.type === EntityType.METAL_ORE_NODE) {
      baseColor = '#573024'; // Rust/Brown
      highlightColor = '#a16207'; // Gold/Copper tint
  } else if (node.type === EntityType.SULFUR_ORE_NODE) {
      baseColor = '#ca8a04'; // Dark Yellow
      highlightColor = '#facc15'; // Bright Yellow
  }

  // Draw main rock shape
  ctx.fillStyle = baseColor;
  
  ctx.beginPath();
  ctx.moveTo(-15, -10);
  ctx.lineTo(5, -18);
  ctx.lineTo(18, -5);
  ctx.lineTo(12, 15);
  ctx.lineTo(-10, 12);
  ctx.lineTo(-18, 5);
  ctx.closePath();
  ctx.fill();

  // Highlights / Veins - SKIP ON LOW PERF
  if (!settings.lowPerformance) {
      ctx.fillStyle = highlightColor;
      
      if (node.type === EntityType.SULFUR_ORE_NODE) {
          // Sulfur veins (streaks)
          ctx.beginPath(); ctx.moveTo(-5, -5); ctx.lineTo(5, -10); ctx.lineTo(8, -2); ctx.lineTo(0, 5); ctx.fill();
      } else if (node.type === EntityType.METAL_ORE_NODE) {
          // Metal chunks (shiny spots)
          ctx.beginPath(); ctx.arc(-5, -5, 4, 0, Math.PI*2); ctx.fill();
          ctx.beginPath(); ctx.arc(5, 5, 3, 0, Math.PI*2); ctx.fill();
          ctx.fillStyle = 'rgba(255,255,255,0.2)'; // Shine
          ctx.beginPath(); ctx.arc(-6, -6, 2, 0, Math.PI*2); ctx.fill();
      } else {
          // Stone facets
          ctx.beginPath(); ctx.moveTo(-10, 0); ctx.lineTo(0, -10); ctx.lineTo(5, 0); ctx.fill();
      }
  }

  ctx.restore();
};
