
import { Entity, GameSettings } from '../types';

export const drawBear = (ctx: CanvasRenderingContext2D, bear: Entity, settings: GameSettings, time: number) => {
  ctx.save();
  ctx.rotate(bear.rotation);
  
  // Breathing animation
  const breathe = 1 + (Math.sin(time / 1000) * 0.03);
  ctx.scale(breathe, breathe);

  // Body
  ctx.fillStyle = '#451a03'; 
  ctx.beginPath(); 
  ctx.ellipse(0, 0, 25, 18, 0, 0, Math.PI * 2); 
  ctx.fill();

  // Shadow/Mass
  if (!settings.lowPerformance) {
    ctx.fillStyle = 'rgba(0,0,0,0.1)';
    ctx.beginPath();
    ctx.ellipse(0, 5, 20, 10, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // Head
  ctx.fillStyle = '#27272a'; 
  ctx.beginPath(); 
  ctx.arc(18, 0, 12, 0, Math.PI * 2); 
  ctx.fill(); 

  // Angry Eyes
  ctx.fillStyle = '#ef4444'; 
  ctx.fillRect(24, -3, 2, 2); 
  ctx.fillRect(24, 3, 2, 2); 
  
  ctx.restore();
};
