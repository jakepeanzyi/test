
import { Entity, EntityType, GameSettings } from '../types';

export const drawPlant = (ctx: CanvasRenderingContext2D, plant: Entity, settings: GameSettings, time: number) => {
  ctx.save();
  
  const growth = plant.growthStage !== undefined ? plant.growthStage / 100 : 1;
  const scale = 0.6 + (growth * 0.4); 
  ctx.scale(scale, scale);

  const sway = Math.sin(time / 1000 + plant.pos.x) * 0.1;
  ctx.rotate(sway);

  if (plant.type.includes('BERRY_BUSH') || plant.type === EntityType.PLANT_BERRY) {
      // Bush base
      ctx.fillStyle = '#166534';
      ctx.beginPath(); ctx.arc(0, -10, 12, 0, Math.PI * 2); ctx.fill();
      
      // Berry color
      let berryColor = '#be123c'; // Default Red
      if (plant.type === EntityType.BLUE_BERRY_BUSH) berryColor = '#2563eb';
      else if (plant.type === EntityType.GREEN_BERRY_BUSH) berryColor = '#65a30d';
      else if (plant.type === EntityType.RED_BERRY_BUSH) berryColor = '#dc2626';
      else if (plant.type === EntityType.WHITE_BERRY_BUSH) berryColor = '#e2e8f0';
      else if (plant.type === EntityType.YELLOW_BERRY_BUSH) berryColor = '#facc15';

      if (growth > 0.8) {
         ctx.fillStyle = berryColor;
         ctx.beginPath(); ctx.arc(-4, -12, 3, 0, Math.PI*2); ctx.fill();
         ctx.beginPath(); ctx.arc(4, -8, 3, 0, Math.PI*2); ctx.fill();
         ctx.beginPath(); ctx.arc(0, -16, 3, 0, Math.PI*2); ctx.fill();
      }
  } else if (plant.type === EntityType.HEMP_FIBERS || plant.type === EntityType.PLANT_HEMP) {
    ctx.fillStyle = 'rgba(0,0,0,0.6)';
    ctx.beginPath(); ctx.ellipse(0, 5, 12, 6, 0, 0, Math.PI*2); ctx.fill();

    ctx.fillStyle = '#84cc16'; 
    
    ctx.beginPath();
    ctx.moveTo(0, 0); ctx.lineTo(-5, -25); ctx.lineTo(0, -32); ctx.lineTo(5, -25);
    ctx.closePath(); ctx.fill();

    ctx.fillStyle = '#4d7c0f';
    ctx.beginPath(); ctx.ellipse(0, -20, 10, 5, Math.PI/4, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(0, -20, 10, 5, -Math.PI/4, 0, Math.PI*2); ctx.fill();

    ctx.fillStyle = '#bef264';
    ctx.beginPath(); ctx.arc(0, -32, 3, 0, Math.PI*2); ctx.fill();
  } else if (plant.type === EntityType.WILD_CORN_PLANT) {
      ctx.strokeStyle = '#eab308'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(0,-30); ctx.stroke();
      ctx.fillStyle = '#ca8a04';
      ctx.beginPath(); ctx.ellipse(0, -25, 4, 8, 0, 0, Math.PI*2); ctx.fill();
      ctx.strokeStyle = '#166534'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(0,-10); ctx.lineTo(-10,-20); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0,-10); ctx.lineTo(10,-20); ctx.stroke();
  } else if (plant.type === EntityType.WILD_POTATO_PLANT) {
      ctx.fillStyle = '#166534';
      ctx.beginPath(); ctx.arc(0, 0, 10, 0, Math.PI*2); ctx.fill();
      ctx.fillStyle = '#a16207';
      ctx.beginPath(); ctx.arc(-3, -3, 3, 0, Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.arc(3, 3, 2, 0, Math.PI*2); ctx.fill();
  } else if (plant.type === EntityType.WILD_PUMPKIN_PLANT || plant.type === EntityType.PLANT_PUMPKIN) {
    ctx.strokeStyle = '#3f6212';
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(0,0); ctx.quadraticCurveTo(10, -5, 15, 0); ctx.stroke();
    if (growth > 0.6) {
        ctx.fillStyle = '#ea580c';
        ctx.beginPath(); ctx.ellipse(15, -2, 10, 8, 0, 0, Math.PI*2); ctx.fill();
        ctx.strokeStyle = '#9a3412'; ctx.lineWidth = 1; ctx.stroke();
    }
  } else if (plant.type === EntityType.WILD_WHEAT) {
      ctx.strokeStyle = '#fef08a'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(-2,0); ctx.lineTo(-4,-20); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(2,0); ctx.lineTo(4,-25); ctx.stroke();
      ctx.fillStyle = '#fde047';
      ctx.beginPath(); ctx.ellipse(-4, -20, 2, 5, 0, 0, Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.ellipse(4, -25, 2, 5, 0, 0, Math.PI*2); ctx.fill();
  } else if (plant.type === EntityType.WILD_ROSE) {
      ctx.strokeStyle = '#166534'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(0,-15); ctx.stroke();
      ctx.fillStyle = '#e11d48';
      ctx.beginPath(); ctx.arc(0,-15, 4, 0, Math.PI*2); ctx.fill();
  } else if (plant.type === EntityType.WILD_SUNFLOWER) {
      ctx.strokeStyle = '#166534'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(0,-25); ctx.stroke();
      ctx.fillStyle = '#facc15';
      ctx.beginPath(); ctx.arc(0,-25, 6, 0, Math.PI*2); ctx.fill();
      ctx.fillStyle = '#451a03';
      ctx.beginPath(); ctx.arc(0,-25, 2, 0, Math.PI*2); ctx.fill();
  } else if (plant.type === EntityType.WILD_ORCHID) {
      ctx.strokeStyle = '#166534'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(0,-15); ctx.stroke();
      ctx.fillStyle = '#d946ef';
      ctx.beginPath(); ctx.ellipse(0, -15, 4, 6, 0, 0, Math.PI*2); ctx.fill();
  }

  ctx.restore();
};
