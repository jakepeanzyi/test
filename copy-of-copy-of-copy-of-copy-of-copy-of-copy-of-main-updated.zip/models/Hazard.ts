
import { Entity, EntityType, GameSettings } from '../types';

export const drawHazard = (ctx: CanvasRenderingContext2D, hazard: Entity, settings: GameSettings, time: number) => {
  ctx.save();
  const seed = parseInt(hazard.id.replace(/\D/g, '')) || 0;

  if (hazard.type === EntityType.QUICKSAND) {
    ctx.fillStyle = '#7c2d12';
    ctx.beginPath();
    ctx.ellipse(0, 0, hazard.size, hazard.size * 0.7, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#451a03';
    ctx.lineWidth = 2;
    ctx.stroke();
    
    // Swirl effect
    if (!settings.lowPerformance) {
        ctx.save();
        ctx.rotate(time / 1000);
        ctx.strokeStyle = 'rgba(0,0,0,0.2)';
        ctx.beginPath();
        ctx.arc(0, 0, hazard.size * 0.5, 0, Math.PI);
        ctx.stroke();
        ctx.restore();
    }
  } else if (hazard.type === EntityType.GAS_CLOUD) {
    const pulse = Math.sin(time / 500 + seed) * 5;
    ctx.fillStyle = 'rgba(77, 124, 15, 0.4)';
    if (!settings.lowPerformance) {
        const grad = ctx.createRadialGradient(0, 0, 5, 0, 0, hazard.size + pulse);
        grad.addColorStop(0, 'rgba(132, 204, 22, 0.6)');
        grad.addColorStop(1, 'rgba(77, 124, 15, 0)');
        ctx.fillStyle = grad;
    }
    ctx.beginPath();
    ctx.arc(0, 0, hazard.size + pulse, 0, Math.PI * 2);
    ctx.fill();
  } else if (hazard.type === EntityType.RADIATION_ZONE) {
    const pulse = Math.sin(time / 800 + seed) * 3;
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.3)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, hazard.size + pulse, 0, Math.PI * 2);
    ctx.stroke();
    
    if (!settings.lowPerformance) {
        ctx.fillStyle = 'rgba(56, 189, 248, 0.05)';
        ctx.fill();
        // Particles
        ctx.fillStyle = 'rgba(56, 189, 248, 0.5)';
        for(let i=0; i<3; i++) {
            const px = Math.sin(time/200 + i*10) * hazard.size * 0.5;
            const py = Math.cos(time/200 + i*10) * hazard.size * 0.5;
            ctx.fillRect(px, py, 2, 2);
        }
    }
  }
  
  ctx.restore();
};
