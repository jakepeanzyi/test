
import { Particle } from '../types';

export const drawParticle = (ctx: CanvasRenderingContext2D, p: Particle) => {
  ctx.save();
  ctx.translate(p.x, p.y);
  if (p.rotation) ctx.rotate(p.rotation);
  
  ctx.globalAlpha = p.life / p.maxLife;
  ctx.fillStyle = p.color;

  if (p.type === 'leaf') {
      // Leaf shape
      ctx.beginPath();
      ctx.ellipse(0, 0, p.size, p.size * 0.4, 0, 0, Math.PI * 2);
      ctx.fill();
  } else if (p.type === 'stone') {
      // Chunky rock
      ctx.fillRect(-p.size/2, -p.size/2, p.size, p.size);
  } else if (p.type === 'spark') {
      // Intense small dot
      ctx.globalCompositeOperation = 'screen';
      ctx.beginPath(); ctx.arc(0, 0, p.size/2, 0, Math.PI*2); ctx.fill();
  } else {
      // Default square
      ctx.fillRect(-p.size/2, -p.size/2, p.size, p.size);
  }
  
  ctx.restore();
};
