
import { Entity, EntityType, GameSettings } from '../types';

export const drawNPC = (ctx: CanvasRenderingContext2D, npc: Entity, settings: GameSettings, time: number, isShadow: boolean = false) => {
  ctx.save();
  ctx.rotate(npc.rotation);

  if (isShadow) {
      ctx.fillStyle = 'rgba(0,0,0,0.2)';
      ctx.beginPath(); ctx.arc(0, 0, 14, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
      return;
  }

  // Hit reaction
  if (npc.hitReaction && npc.hitReaction > 0) {
    ctx.translate((Math.random() - 0.5) * 2, (Math.random() - 0.5) * 2);
  }

  // Base colors
  let bodyColor = '#262626';
  let headColor = '#262626';
  let weaponColor = '#000';

  if (npc.type.includes('SCIENTIST')) {
      if (npc.type === EntityType.HEAVY_SCIENTIST || npc.type.includes('HEAVY')) {
          bodyColor = '#1e1b4b'; // Dark blue heavy armor
          headColor = '#000'; // Visor
      } else if (npc.type === EntityType.ARCTIC_SCIENTIST) {
          bodyColor = '#fff';
          headColor = '#e5e7eb';
      } else {
          bodyColor = '#2563eb'; // Blue hazmat
          headColor = '#3b82f6';
      }
  } else if (npc.type === EntityType.BANDIT_CAMP_GUARD || npc.type === EntityType.HUNTER) {
      bodyColor = '#3f6212'; // Camo
      headColor = '#1c1917'; // Mask
  } else if (npc.type === EntityType.LUMBERJACK || npc.type === EntityType.MINER) {
      bodyColor = '#991b1b'; // Plaid/Work shirt
      headColor = '#d4a373';
  } else if (npc.type === EntityType.TUNNEL_DWELLER || npc.type === EntityType.UNDERWATER_DWELLER) {
      bodyColor = '#78350f'; // Rags
      headColor = '#57534e';
  } else if (npc.type === EntityType.SCARECROW) { // Usually event, assuming npc style
      bodyColor = '#a16207';
      headColor = '#ea580c';
  }

  // Body
  ctx.fillStyle = bodyColor;
  ctx.beginPath(); ctx.arc(0, 0, 14, 0, Math.PI*2); ctx.fill();

  // Head
  ctx.fillStyle = headColor;
  ctx.beginPath(); ctx.arc(0, 0, 10, 0, Math.PI*2); ctx.fill();

  // Weapon indicator
  ctx.fillStyle = weaponColor;
  ctx.fillRect(8, 2, 16, 4);

  // Special equipment
  if (npc.type === EntityType.HEAVY_SCIENTIST_FLAMETHROWER) {
      ctx.fillStyle = '#ea580c'; ctx.beginPath(); ctx.arc(10, 5, 3, 0, Math.PI*2); ctx.fill();
  }
  if (npc.type === EntityType.NVG_SCIENTIST) {
      ctx.fillStyle = '#22c55e'; // Green eyes
      ctx.fillRect(6, -3, 2, 2); ctx.fillRect(6, 3, 2, 2);
  }

  ctx.restore();
};
