
import { Entity, GameSettings } from '../types';

export const drawBarrel = (ctx: CanvasRenderingContext2D, barrel: Entity, settings: GameSettings, time: number, isShadow: boolean = false) => {
  ctx.save();
  ctx.rotate(barrel.rotation);

  if (isShadow) {
      ctx.fillStyle = 'rgba(0,0,0,0.2)';
      ctx.beginPath(); ctx.arc(0, 0, barrel.size/2, 0, Math.PI*2); ctx.fill();
      ctx.restore();
      return;
  }

  // Hit shake
  if (barrel.hitReaction && barrel.hitReaction > 0) {
    const intensity = barrel.hitReaction * 0.8;
    ctx.translate((Math.random() - 0.5) * intensity, (Math.random() - 0.5) * intensity);
  }

  // Determine color based on variant (Red vs Blue barrels)
  const isRed = (barrel.variant || 0) % 2 === 0;
  const baseColor = isRed ? '#b91c1c' : '#1d4ed8'; // Red or Blue
  const rimColor = '#d4d4d4'; // Metal rim

  // Main Cylinder Body
  ctx.fillStyle = baseColor;
  ctx.beginPath(); ctx.arc(0, 0, barrel.size/2, 0, Math.PI*2); ctx.fill();
  
  // Metal Rims (Two rings)
  ctx.strokeStyle = rimColor;
  ctx.lineWidth = 2;
  ctx.beginPath(); ctx.arc(0, 0, barrel.size/2, 0, Math.PI*2); ctx.stroke();
  ctx.beginPath(); ctx.arc(0, 0, barrel.size/2 - 4, 0, Math.PI*2); ctx.stroke();

  // Lid Detail / Dent
  ctx.fillStyle = 'rgba(0,0,0,0.1)';
  ctx.beginPath(); ctx.arc(5, 5, barrel.size/4, 0, Math.PI*2); ctx.fill();

  // Highlight
  if (!settings.lowPerformance) {
      ctx.fillStyle = 'rgba(255,255,255,0.1)';
      ctx.beginPath(); ctx.ellipse(-5, -5, barrel.size/3, barrel.size/4, Math.PI/4, 0, Math.PI*2); ctx.fill();
  }

  ctx.restore();
};
