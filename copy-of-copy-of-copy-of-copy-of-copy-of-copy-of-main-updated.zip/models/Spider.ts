
import { Entity, GameSettings } from '../types';

export const drawSpider = (ctx: CanvasRenderingContext2D, spider: Entity, settings: GameSettings, time: number) => {
  ctx.save();
  ctx.rotate(spider.rotation);
  
  // Legs animation
  const legSpeed = spider.aiState === 'CHASE' ? 15 : 50;
  const legSwing = Math.sin(time / legSpeed) * 0.2;

  ctx.strokeStyle = '#09090b'; 
  ctx.lineWidth = 2;
  for(let i = 0; i < 8; i++) {
    const angle = (i * Math.PI / 4) + (i % 2 === 0 ? legSwing : -legSwing);
    ctx.beginPath(); 
    ctx.moveTo(0,0); 
    ctx.lineTo(Math.cos(angle) * 15, Math.sin(angle) * 15); 
    ctx.stroke();
  }

  // Body
  ctx.fillStyle = '#09090b'; 
  ctx.beginPath(); ctx.arc(0, 0, 8, 0, Math.PI * 2); ctx.fill(); 
  
  // Head
  ctx.beginPath(); ctx.arc(6, 0, 5, 0, Math.PI * 2); ctx.fill(); 
  
  // Eyes (Multiple)
  ctx.fillStyle = 'red'; 
  ctx.fillRect(8, -2, 1, 1); 
  ctx.fillRect(8, 2, 1, 1);
  ctx.fillRect(7, -1, 1, 1); 
  ctx.fillRect(7, 1, 1, 1);

  ctx.restore();
};
