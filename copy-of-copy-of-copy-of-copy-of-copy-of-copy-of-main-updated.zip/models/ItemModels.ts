
import { ItemType } from '../types';
import { ITEM_DATA } from '../constants';

const drawOutline = (ctx: CanvasRenderingContext2D) => {
    // Disabled outlines for cleaner look
};

const drawContainer = (ctx: CanvasRenderingContext2D, color: string, stripe: string) => {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.rect(-6, -8, 12, 16);
  ctx.fill();
  drawOutline(ctx);
  
  ctx.fillStyle = stripe;
  ctx.beginPath();
  ctx.rect(-6, -2, 12, 4);
  ctx.fill();
};

const drawBlade = (ctx: CanvasRenderingContext2D, color: string) => {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(2, -10); ctx.lineTo(14, -14); ctx.lineTo(16, -2); ctx.lineTo(2, -6);
  ctx.closePath(); ctx.fill();
  drawOutline(ctx);
};

const drawHandle = (ctx: CanvasRenderingContext2D, color: string) => {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.rect(-2, -12, 4, 28);
  ctx.fill();
  drawOutline(ctx);
};

const drawPistol = (ctx: CanvasRenderingContext2D, color: string, barrelLen: number = 10) => {
    ctx.fillStyle = color;
    // Grip
    ctx.beginPath(); ctx.rect(-4, 0, 6, 12); ctx.fill(); drawOutline(ctx);
    // Barrel/Slide
    ctx.beginPath(); ctx.rect(-6, -6, barrelLen + 6, 8); ctx.fill(); drawOutline(ctx);
};

const drawRifle = (ctx: CanvasRenderingContext2D, color: string, stockColor: string, length: number = 24) => {
    // Stock
    ctx.fillStyle = stockColor;
    ctx.beginPath(); ctx.moveTo(-10, 0); ctx.lineTo(-16, 6); ctx.lineTo(-16, -2); ctx.fill(); drawOutline(ctx);
    // Body
    ctx.fillStyle = color;
    ctx.beginPath(); ctx.rect(-10, -4, length, 6); ctx.fill(); drawOutline(ctx);
    // Mag
    ctx.beginPath(); ctx.rect(-2, 2, 4, 8); ctx.fill(); drawOutline(ctx);
};

const drawMeleeBlade = (ctx: CanvasRenderingContext2D, bladeColor: string, handleColor: string, length: number = 20) => {
    ctx.fillStyle = handleColor;
    ctx.beginPath(); ctx.rect(-2, 10, 4, 10); ctx.fill(); drawOutline(ctx);
    ctx.fillStyle = bladeColor;
    ctx.beginPath(); ctx.moveTo(-3, 10); ctx.lineTo(3, 10); ctx.lineTo(0, -length); ctx.fill(); drawOutline(ctx);
};

export const drawItemModel = (ctx: CanvasRenderingContext2D, type: ItemType, time: number = 0) => {
  ctx.save();
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';

  switch(type) {
    // --- TOOLS ---
    case ItemType.ROCK_TOOL: 
    case ItemType.STONE:
      ctx.fillStyle = '#a8a29e'; // Stone Grey
      ctx.beginPath();
      // Irregular rock shape
      ctx.moveTo(-8, -5); ctx.lineTo(6, -8); ctx.lineTo(10, 6); ctx.lineTo(-4, 9); ctx.lineTo(-10, 2);
      ctx.closePath(); ctx.fill();
      drawOutline(ctx);
      // Highlight
      ctx.fillStyle = '#d6d3d1'; ctx.beginPath(); ctx.arc(-2, -2, 3, 0, Math.PI * 2); ctx.fill();
      break;

    case ItemType.TORCH:
      // Handle
      ctx.fillStyle = '#78350f'; 
      ctx.beginPath(); ctx.rect(-3, -2, 6, 20); ctx.fill(); drawOutline(ctx);
      // Flame
      const flicker = Math.sin(time / 80) * 2;
      ctx.fillStyle = '#f97316';
      ctx.beginPath(); 
      ctx.moveTo(-6, -2); ctx.quadraticCurveTo(0, -2 - 18 - flicker, 6, -2); 
      ctx.closePath(); ctx.fill(); drawOutline(ctx);
      // Inner Flame
      ctx.fillStyle = '#facc15';
      ctx.beginPath(); ctx.arc(0, -8, 3, 0, Math.PI*2); ctx.fill();
      break;

    case ItemType.AXE:
    case ItemType.IRON_AXE:
      drawHandle(ctx, type === ItemType.AXE ? '#78350f' : '#334155');
      drawBlade(ctx, type === ItemType.AXE ? '#9ca3af' : '#cbd5e1');
      break;

    case ItemType.PICKAXE:
    case ItemType.IRON_PICKAXE:
      drawHandle(ctx, type === ItemType.PICKAXE ? '#78350f' : '#334155');
      ctx.fillStyle = type === ItemType.PICKAXE ? '#9ca3af' : '#cbd5e1';
      ctx.beginPath(); 
      ctx.moveTo(-16, -8); ctx.quadraticCurveTo(0, -12, 16, -8); 
      ctx.lineTo(14, -4); ctx.quadraticCurveTo(0, -8, -14, -4); 
      ctx.closePath(); ctx.fill();
      drawOutline(ctx);
      break;

    case ItemType.HAMMER:
      drawHandle(ctx, '#78350f');
      ctx.fillStyle = '#475569'; 
      ctx.beginPath(); ctx.rect(-8, -14, 16, 10); ctx.fill(); drawOutline(ctx);
      break;

    case ItemType.SPEAR:
    case ItemType.IRON_SPEAR:
    case ItemType.STONE_SPEAR:
      ctx.fillStyle = '#78350f'; 
      ctx.beginPath(); ctx.rect(-1.5, -10, 3, 40); ctx.fill(); drawOutline(ctx);
      ctx.fillStyle = type === ItemType.IRON_SPEAR ? '#94a3b8' : (type === ItemType.STONE_SPEAR ? '#a8a29e' : '#d6d3d1');
      ctx.beginPath(); ctx.moveTo(0, -26); ctx.lineTo(6, -10); ctx.lineTo(-6, -10); ctx.closePath(); ctx.fill();
      drawOutline(ctx);
      break;

    case ItemType.FISHING_ROD:
      ctx.strokeStyle = '#a16207'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(-8, 12); ctx.lineTo(8, -12); ctx.stroke();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(8, -12); ctx.quadraticCurveTo(12, 0, 8, 10); ctx.stroke();
      break;

    case ItemType.BUILDING_PLAN:
      ctx.fillStyle = '#3b82f6'; 
      ctx.beginPath(); ctx.rect(-10, -14, 20, 28); ctx.fill(); drawOutline(ctx);
      // Blueprint lines
      ctx.strokeStyle = 'white'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(-5, -8); ctx.lineTo(5, -8); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-5, 0); ctx.lineTo(5, 0); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-5, 8); ctx.lineTo(0, 8); ctx.stroke();
      break;

    // --- WEAPONS ---
    case ItemType.BOW:
      ctx.strokeStyle = '#78350f'; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.arc(-4, 0, 16, -Math.PI/2, Math.PI/2); ctx.stroke();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(-4, -16); ctx.lineTo(-4, 16); ctx.stroke();
      break;
      
    case ItemType.COMPOUND_BOW:
      ctx.strokeStyle = '#171717'; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(-4, -16); ctx.lineTo(4, 0); ctx.lineTo(-4, 16); ctx.stroke();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(-4, -16); ctx.lineTo(-4, 16); ctx.stroke();
      break;

    case ItemType.CROSSBOW:
    case ItemType.MINI_CROSSBOW:
      ctx.fillStyle = '#78350f';
      ctx.beginPath(); ctx.rect(-2, -10, 4, 20); ctx.fill(); drawOutline(ctx);
      ctx.strokeStyle = '#171717'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(-10, -8); ctx.quadraticCurveTo(0, -12, 10, -8); ctx.stroke();
      break;

    case ItemType.ARROW:
      ctx.strokeStyle = '#78350f'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(-10, 10); ctx.lineTo(10, -10); ctx.stroke();
      // Fletching
      ctx.fillStyle = '#ef4444';
      ctx.beginPath(); ctx.moveTo(-10, 10); ctx.lineTo(-14, 8); ctx.lineTo(-12, 12); ctx.fill();
      // Tip
      ctx.fillStyle = '#9ca3af';
      ctx.beginPath(); ctx.moveTo(10, -10); ctx.lineTo(14, -14); ctx.lineTo(12, -8); ctx.fill();
      break;

    case ItemType.GRENADE:
      ctx.fillStyle = '#3f6212'; // Olive drab
      ctx.beginPath(); ctx.roundRect(-8, -10, 16, 20, 5); ctx.fill(); drawOutline(ctx);
      // Pin
      ctx.strokeStyle = '#9ca3af'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(0, -12, 4, 0, Math.PI*2); ctx.stroke();
      break;
      
    case ItemType.F1_GRENADE:
      ctx.fillStyle = '#166534';
      ctx.beginPath(); ctx.ellipse(0, 0, 8, 10, 0, 0, Math.PI*2); ctx.fill(); drawOutline(ctx);
      break;

    // --- GUNS ---
    case ItemType.ASSAULT_RIFLE:
      drawRifle(ctx, '#1c1917', '#78350f', 24); // AK Look
      break;
    case ItemType.LR300_ASSAULT_RIFLE:
      drawRifle(ctx, '#374151', '#1f2937', 22);
      break;
    case ItemType.BOLT_ACTION_RIFLE:
      drawRifle(ctx, '#1c1917', '#3f3f46', 30);
      break;
    case ItemType.L96_RIFLE:
      drawRifle(ctx, '#166534', '#14532d', 32);
      break;
    case ItemType.M249:
      drawRifle(ctx, '#1c1917', '#171717', 28);
      // Box mag
      ctx.fillStyle = '#166534'; ctx.fillRect(-2, 2, 8, 8);
      break;
    case ItemType.SEMI_AUTOMATIC_RIFLE:
    case ItemType.SKS:
    case ItemType.M39_RIFLE:
      drawRifle(ctx, '#57534e', '#44403c', 26);
      break;
      
    case ItemType.CUSTOM_SMG:
    case ItemType.HANDMADE_SMG:
    case ItemType.THOMPSON:
    case ItemType.MP5A4:
      drawRifle(ctx, '#292524', '#1c1917', 16);
      break;

    case ItemType.REVOLVER:
    case ItemType.PYTHON_REVOLVER:
    case ItemType.HIGH_CALIBER_REVOLVER:
      drawPistol(ctx, type === ItemType.REVOLVER ? '#78716c' : '#1c1917', 12);
      // Cylinder
      ctx.fillStyle = '#44403c'; ctx.beginPath(); ctx.arc(-2, -2, 4, 0, Math.PI*2); ctx.fill();
      break;

    case ItemType.SEMI_AUTOMATIC_PISTOL:
    case ItemType.M92_PISTOL:
    case ItemType.PROTOTYPE_17:
      drawPistol(ctx, '#334155', 10);
      break;
      
    case ItemType.EOKA_PISTOL:
      // Crude tube
      ctx.fillStyle = '#78350f'; ctx.beginPath(); ctx.rect(-4, 0, 6, 12); ctx.fill();
      ctx.fillStyle = '#b45309'; ctx.beginPath(); ctx.rect(-6, -8, 14, 8); ctx.fill(); drawOutline(ctx);
      break;
      
    case ItemType.NAILGUN:
      ctx.fillStyle = '#ef4444'; // Red tool body
      ctx.beginPath(); ctx.rect(-6, -6, 12, 12); ctx.fill(); drawOutline(ctx);
      ctx.fillStyle = '#a16207'; // Mag
      ctx.fillRect(-2, 6, 4, 6);
      break;

    case ItemType.DOUBLE_BARREL_SHOTGUN:
      drawRifle(ctx, '#44403c', '#78350f', 14);
      // Two barrels
      ctx.fillStyle = '#1c1917'; ctx.beginPath(); ctx.arc(14, -4, 2, 0, Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.arc(14, 0, 2, 0, Math.PI*2); ctx.fill();
      break;
      
    case ItemType.PUMP_SHOTGUN:
    case ItemType.SPAS12_SHOTGUN:
    case ItemType.M4_SHOTGUN:
      drawRifle(ctx, '#1c1917', '#171717', 22);
      // Pump handle
      ctx.fillStyle = '#44403c'; ctx.fillRect(4, -1, 8, 4);
      break;
      
    case ItemType.WATERPIPE_SHOTGUN:
      ctx.fillStyle = '#57534e'; // Pipe
      ctx.beginPath(); ctx.rect(-10, -4, 20, 4); ctx.fill(); drawOutline(ctx);
      ctx.fillStyle = '#78350f'; // Wood grip
      ctx.fillRect(-10, 0, 6, 8);
      break;

    case ItemType.ROCKET_LAUNCHER:
    case ItemType.RPG_LAUNCHER:
    case ItemType.HOMING_MISSILE_LAUNCHER:
      ctx.fillStyle = '#3f6212';
      ctx.beginPath(); ctx.rect(-14, -6, 28, 12); ctx.fill(); drawOutline(ctx);
      break;
      
    case ItemType.FLAME_THROWER:
    case ItemType.MILITARY_FLAME_THROWER:
      ctx.fillStyle = '#b91c1c';
      ctx.beginPath(); ctx.rect(-10, -6, 20, 8); ctx.fill(); drawOutline(ctx);
      // Nozzle
      ctx.fillStyle = '#facc15'; ctx.fillRect(10, -4, 4, 4);
      break;
      
    case ItemType.MINIGUN:
      ctx.fillStyle = '#1c1917';
      ctx.beginPath(); ctx.rect(-10, -8, 20, 16); ctx.fill(); drawOutline(ctx);
      // Barrels
      ctx.fillStyle = '#525252';
      ctx.fillRect(10, -6, 8, 2); ctx.fillRect(10, -2, 8, 2); ctx.fillRect(10, 2, 8, 2);
      break;

    // --- MELEE ---
    case ItemType.LONGSWORD:
    case ItemType.SALVAGED_SWORD:
    case ItemType.MACHETE:
    case ItemType.SALVAGED_CLEAVER:
    case ItemType.COMBAT_KNIFE:
    case ItemType.BONE_KNIFE:
    case ItemType.BUTCHER_KNIFE:
      drawMeleeBlade(ctx, '#d4d4d4', '#78350f', 24);
      break;
      
    case ItemType.MACE:
    case ItemType.BONE_CLUB:
    case ItemType.CANDY_CANE_CLUB:
    case ItemType.PADDLE:
      // Blunt
      ctx.fillStyle = type === ItemType.CANDY_CANE_CLUB ? '#ef4444' : '#78350f';
      ctx.beginPath(); ctx.rect(-2, -10, 4, 20); ctx.fill();
      ctx.fillStyle = type === ItemType.MACE ? '#44403c' : (type === ItemType.CANDY_CANE_CLUB ? '#fff' : '#d6d3d1');
      ctx.beginPath(); ctx.arc(0, -10, 6, 0, Math.PI*2); ctx.fill(); drawOutline(ctx);
      break;

    // --- RESOURCES ---
    case ItemType.WOOD:
      ctx.fillStyle = '#78350f'; 
      ctx.beginPath(); ctx.roundRect(-12, -4, 24, 8, 2); ctx.fill(); drawOutline(ctx);
      // Knot
      ctx.fillStyle = '#451a03'; ctx.beginPath(); ctx.arc(-4, 0, 2, 0, Math.PI*2); ctx.fill();
      break;

    case ItemType.METAL_ORE:
    case ItemType.SULFUR_ORE:
    case ItemType.SCRAP_METAL:
      ctx.fillStyle = type === ItemType.METAL_ORE ? '#525252' : (type === ItemType.SULFUR_ORE ? '#eab308' : '#737373');
      ctx.beginPath();
      ctx.moveTo(-8, 0); ctx.lineTo(0, -10); ctx.lineTo(8, 0); ctx.lineTo(4, 8); ctx.lineTo(-4, 8);
      ctx.closePath(); ctx.fill(); drawOutline(ctx);
      break;

    case ItemType.IRON_BAR:
    case ItemType.STEEL_BAR:
      ctx.fillStyle = type === ItemType.IRON_BAR ? '#cbd5e1' : '#334155';
      ctx.beginPath(); ctx.rect(-10, -6, 20, 12); ctx.fill(); drawOutline(ctx);
      break;

    case ItemType.CLOTH:
      ctx.fillStyle = '#f1f5f9';
      ctx.beginPath(); ctx.moveTo(-10, -8); ctx.lineTo(10, -4); ctx.lineTo(8, 10); ctx.lineTo(-8, 6); ctx.closePath(); ctx.fill(); drawOutline(ctx);
      break;

    case ItemType.LEATHER:
      ctx.fillStyle = '#78350f';
      ctx.beginPath();
      ctx.moveTo(-10, -8); ctx.quadraticCurveTo(0, -12, 10, -8);
      ctx.lineTo(8, 8); ctx.quadraticCurveTo(0, 12, -8, 8);
      ctx.closePath(); ctx.fill(); drawOutline(ctx);
      break;

    case ItemType.ROPE:
    case ItemType.FIBER:
      ctx.strokeStyle = type === ItemType.ROPE ? '#a16207' : '#4d7c0f';
      ctx.lineWidth = 4;
      ctx.beginPath(); ctx.arc(0, 0, 10, 0, Math.PI*1.5); ctx.stroke();
      break;

    case ItemType.PLASTIC:
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath(); ctx.arc(0, 0, 8, 0, Math.PI*2); ctx.fill(); drawOutline(ctx);
      break;

    // --- CONSUMABLES ---
    case ItemType.FOOD_CAN:
      drawContainer(ctx, '#3f6212', '#a3e635');
      break;

    case ItemType.WATER_BOTTLE:
      ctx.fillStyle = '#0ea5e9';
      ctx.beginPath(); ctx.rect(-6, -8, 12, 16); ctx.fill(); drawOutline(ctx);
      ctx.fillStyle = '#fff';
      ctx.beginPath(); ctx.rect(-3, -11, 6, 3); ctx.fill(); drawOutline(ctx);
      break;

    case ItemType.BERRY:
      ctx.fillStyle = '#be123c';
      ctx.beginPath(); ctx.arc(-4, 2, 5, 0, Math.PI*2); ctx.fill(); drawOutline(ctx);
      ctx.beginPath(); ctx.arc(4, -2, 5, 0, Math.PI*2); ctx.fill(); drawOutline(ctx);
      ctx.beginPath(); ctx.arc(0, 5, 5, 0, Math.PI*2); ctx.fill(); drawOutline(ctx);
      break;

    case ItemType.PUMPKIN:
      ctx.fillStyle = '#ea580c';
      ctx.beginPath(); ctx.ellipse(0, 2, 12, 10, 0, 0, Math.PI*2); ctx.fill(); drawOutline(ctx);
      ctx.fillStyle = '#3f6212'; // Stem
      ctx.beginPath(); ctx.rect(-2, -12, 4, 6); ctx.fill();
      break;

    case ItemType.FISH:
    case ItemType.COOKED_MEAT:
      ctx.fillStyle = type === ItemType.FISH ? '#60a5fa' : '#b91c1c';
      ctx.beginPath(); 
      if (type === ItemType.FISH) {
          ctx.ellipse(0, 0, 14, 6, 0, 0, Math.PI*2);
      } else {
          ctx.ellipse(0, 0, 10, 10, 0, 0, Math.PI*2); // Steak shape
      }
      ctx.fill(); drawOutline(ctx);
      break;

    case ItemType.BANDAGE:
      ctx.fillStyle = '#f1f5f9';
      ctx.beginPath(); ctx.roundRect(-10, -6, 20, 12, 4); ctx.fill(); drawOutline(ctx);
      ctx.fillStyle = '#ef4444'; // Red Cross
      ctx.beginPath(); ctx.rect(-2, -4, 4, 8); ctx.fill();
      ctx.beginPath(); ctx.rect(-4, -2, 8, 4); ctx.fill();
      break;

    case ItemType.MEDKIT:
      ctx.fillStyle = '#ef4444';
      ctx.beginPath(); ctx.rect(-12, -10, 24, 20); ctx.fill(); drawOutline(ctx);
      ctx.fillStyle = '#fff'; // White Cross
      ctx.beginPath(); ctx.rect(-3, -6, 6, 12); ctx.fill();
      ctx.beginPath(); ctx.rect(-6, -3, 12, 6); ctx.fill();
      break;

    // --- EQUIPMENT ---
    case ItemType.BACKPACK:
      ctx.fillStyle = '#78350f';
      ctx.beginPath(); ctx.roundRect(-10, -12, 20, 24, 4); ctx.fill(); drawOutline(ctx);
      // Pocket
      ctx.fillStyle = '#92400e';
      ctx.beginPath(); ctx.roundRect(-8, 0, 16, 10, 2); ctx.fill(); drawOutline(ctx);
      break;

    case ItemType.WOLF_FUR_COAT:
      ctx.fillStyle = '#451a03';
      // T-shirt shape
      ctx.beginPath();
      ctx.moveTo(-12, -10); ctx.lineTo(12, -10); ctx.lineTo(16, -4); ctx.lineTo(12, 0); ctx.lineTo(12, 14);
      ctx.lineTo(-12, 14); ctx.lineTo(-12, 0); ctx.lineTo(-16, -4); 
      ctx.closePath(); ctx.fill(); drawOutline(ctx);
      break;

    case ItemType.COMPASS:
      ctx.fillStyle = '#e5e5e5';
      ctx.beginPath(); ctx.arc(0, 0, 12, 0, Math.PI*2); ctx.fill(); drawOutline(ctx);
      // Needle
      ctx.fillStyle = '#ef4444';
      ctx.beginPath(); ctx.moveTo(0, -8); ctx.lineTo(3, 0); ctx.lineTo(-3, 0); ctx.fill();
      break;

    case ItemType.MAP:
      ctx.fillStyle = '#fef3c7'; // Paper color
      ctx.beginPath(); ctx.rect(-10, -12, 20, 24); ctx.fill(); drawOutline(ctx);
      // Map markings
      ctx.strokeStyle = '#78350f'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(-6, -6); ctx.lineTo(0, 0); ctx.lineTo(6, -4); ctx.stroke();
      break;

    case ItemType.BLUEPRINT:
      ctx.fillStyle = '#3b82f6';
      // Rolled paper cylinder
      ctx.beginPath(); ctx.rect(-12, -6, 24, 12); ctx.fill(); drawOutline(ctx);
      ctx.fillStyle = '#2563eb';
      ctx.beginPath(); ctx.ellipse(-12, 0, 3, 6, 0, 0, Math.PI*2); ctx.fill(); drawOutline(ctx);
      // White lines
      ctx.strokeStyle = 'white'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(-4, -6); ctx.lineTo(-4, 6); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(4, -6); ctx.lineTo(4, 6); ctx.stroke();
      break;

    // --- MISC ---
    case ItemType.HEMP_SEED:
    case ItemType.BERRY_SEED:
    case ItemType.PUMPKIN_SEED:
      ctx.fillStyle = type === ItemType.PUMPKIN_SEED ? '#fdba74' : '#4d7c0f';
      for(let i=0; i<3; i++) {
          ctx.beginPath(); ctx.arc(-5 + i*5, 0, 3, 0, Math.PI*2); ctx.fill();
      }
      break;
      
    // --- ATTACHMENTS ---
    case ItemType.SCOPE_8X:
    case ItemType.HOLOSIGHT:
    case ItemType.SIMPLE_HANDMADE_SIGHT:
    case ItemType.VARIABLE_ZOOM_SCOPE:
      ctx.fillStyle = '#000';
      ctx.fillRect(-6, -6, 12, 12);
      ctx.fillStyle = '#ef4444'; // Lens
      ctx.beginPath(); ctx.arc(0, 0, 4, 0, Math.PI*2); ctx.fill();
      break;
      
    case ItemType.MILITARY_SILENCER:
    case ItemType.OIL_FILTER_SILENCER:
    case ItemType.SODA_CAN_SILENCER:
      ctx.fillStyle = type === ItemType.SODA_CAN_SILENCER ? '#ef4444' : '#000';
      ctx.beginPath(); ctx.rect(-4, -10, 8, 20); ctx.fill(); drawOutline(ctx);
      break;

    default:
      // Fallback: Generic Box
      ctx.fillStyle = ITEM_DATA[type]?.color || '#a8a29e';
      ctx.beginPath(); ctx.rect(-8, -8, 16, 16); ctx.fill(); drawOutline(ctx);
      ctx.fillStyle = 'rgba(0,0,0,0.2)';
      ctx.font = 'bold 10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('?', 0, 4);
  }
  ctx.restore();
};
