
import { Entity, GameSettings, EntityType } from '../types';

export const drawAnimal = (ctx: CanvasRenderingContext2D, ent: Entity, settings: GameSettings, time: number, isShadow: boolean = false) => {
  ctx.save();
  ctx.rotate(ent.rotation);

  if (isShadow) {
      ctx.fillStyle = 'rgba(0,0,0,0.2)';
      let shadowSize = ent.size * 0.6;
      if (ent.type === EntityType.SNAKE) shadowSize = ent.size * 0.3;
      if (ent.type === EntityType.BEAR || ent.type === EntityType.POLAR_BEAR) shadowSize = ent.size * 0.7;
      ctx.beginPath(); ctx.ellipse(0, 0, ent.size/2, shadowSize/2, 0, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
      return;
  }

  // Hit reaction shake
  if (ent.hitReaction && ent.hitReaction > 0) {
    const intensity = ent.hitReaction * 0.8;
    ctx.translate((Math.random() - 0.5) * intensity, (Math.random() - 0.5) * intensity);
  }

  const isChase = ent.aiState === 'CHASE';
  const walkCycle = Math.sin(time / (isChase ? 100 : 200)) * 0.2;

  switch(ent.type) {
      case EntityType.WOLF:
          // Body
          ctx.fillStyle = '#4b5563'; // Grey
          ctx.fillRect(-12, -8, 24, 16);
          // Head
          ctx.fillStyle = '#374151'; 
          ctx.fillRect(10, -6, 10, 12);
          // Tail
          ctx.save(); ctx.translate(-12, 0); ctx.rotate(walkCycle); ctx.fillStyle = '#374151'; ctx.fillRect(-8, -2, 8, 4); ctx.restore();
          // Eyes
          ctx.fillStyle = isChase ? '#ef4444' : '#fbbf24'; ctx.fillRect(16, -4, 2, 2); ctx.fillRect(16, 2, 2, 2);
          break;

      case EntityType.BEAR:
      case EntityType.POLAR_BEAR:
          const isPolar = ent.type === EntityType.POLAR_BEAR;
          const furColor = isPolar ? '#f1f5f9' : '#451a03';
          const headColor = isPolar ? '#e2e8f0' : '#27272a';
          // Body
          ctx.fillStyle = furColor;
          ctx.beginPath(); ctx.ellipse(0, 0, 22, 16, 0, 0, Math.PI*2); ctx.fill();
          // Head
          ctx.fillStyle = headColor;
          ctx.beginPath(); ctx.arc(18, 0, 12, 0, Math.PI*2); ctx.fill();
          // Ears
          ctx.beginPath(); ctx.arc(14, -10, 4, 0, Math.PI*2); ctx.fill();
          ctx.beginPath(); ctx.arc(14, 10, 4, 0, Math.PI*2); ctx.fill();
          // Eyes
          ctx.fillStyle = isChase ? '#ef4444' : '#000';
          ctx.beginPath(); ctx.arc(22, -4, 1.5, 0, Math.PI*2); ctx.fill();
          ctx.beginPath(); ctx.arc(22, 4, 1.5, 0, Math.PI*2); ctx.fill();
          break;

      case EntityType.BOAR:
          ctx.fillStyle = '#573c29'; // Dark brown
          ctx.beginPath(); ctx.ellipse(0, 0, 16, 10, 0, 0, Math.PI*2); ctx.fill();
          // Head
          ctx.fillStyle = '#3e2b1d';
          ctx.beginPath(); ctx.moveTo(10, -8); ctx.lineTo(22, 0); ctx.lineTo(10, 8); ctx.fill();
          // Tusks
          ctx.fillStyle = '#fff';
          ctx.beginPath(); ctx.moveTo(20, -3); ctx.lineTo(24, -5); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(20, 3); ctx.lineTo(24, 5); ctx.stroke();
          break;

      case EntityType.CHICKEN:
          // Body
          ctx.fillStyle = '#fff';
          ctx.beginPath(); ctx.ellipse(0, 0, 8, 6, 0, 0, Math.PI*2); ctx.fill();
          // Head
          ctx.beginPath(); ctx.arc(8, 0, 4, 0, Math.PI*2); ctx.fill();
          // Comb
          ctx.fillStyle = '#ef4444';
          ctx.fillRect(8, -1, 3, 2);
          break;

      case EntityType.STAG:
          // Body
          ctx.fillStyle = '#854d0e';
          ctx.fillRect(-14, -6, 28, 12);
          // Neck/Head
          ctx.fillStyle = '#713f12';
          ctx.beginPath(); ctx.arc(16, 0, 6, 0, Math.PI*2); ctx.fill();
          // Antlers
          ctx.strokeStyle = '#3f2e18'; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(16, -4); ctx.lineTo(20, -12); ctx.lineTo(24, -14); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(16, 4); ctx.lineTo(20, 12); ctx.lineTo(24, 14); ctx.stroke();
          break;

      case EntityType.HORSE:
          // Body
          ctx.fillStyle = '#78350f';
          ctx.beginPath(); ctx.ellipse(0, 0, 20, 8, 0, 0, Math.PI*2); ctx.fill();
          // Neck/Head
          ctx.save(); ctx.translate(14, 0); ctx.rotate(-0.3);
          ctx.fillStyle = '#55361e';
          ctx.beginPath(); ctx.ellipse(0, 0, 10, 5, 0, 0, Math.PI*2); ctx.fill();
          // Mane
          ctx.fillStyle = '#000';
          ctx.fillRect(-8, -1, 10, 2);
          ctx.restore();
          break;

      case EntityType.SNAKE:
          ctx.strokeStyle = '#3f6212'; ctx.lineWidth = 4;
          ctx.lineCap = 'round';
          ctx.beginPath();
          const wave = Math.sin(time / 200) * 5;
          ctx.moveTo(-15, 0);
          ctx.quadraticCurveTo(-5, wave, 5, -wave);
          ctx.lineTo(15, 0);
          ctx.stroke();
          // Head
          ctx.fillStyle = '#14532d';
          ctx.beginPath(); ctx.arc(16, 0, 3, 0, Math.PI*2); ctx.fill();
          break;

      case EntityType.SHARK:
          ctx.fillStyle = '#64748b'; // Slate grey
          // Body
          ctx.beginPath(); ctx.ellipse(0, 0, 25, 10, 0, 0, Math.PI*2); ctx.fill();
          // Fins
          ctx.beginPath(); ctx.moveTo(-5, -10); ctx.lineTo(5, 0); ctx.lineTo(-5, 10); ctx.fill();
          // Tail
          ctx.save(); ctx.translate(-25, 0); ctx.rotate(walkCycle * 2);
          ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(-10, -10); ctx.lineTo(-10, 10); ctx.fill();
          ctx.restore();
          break;

      case EntityType.CROCODILE:
          ctx.fillStyle = '#3f6212';
          // Body
          ctx.fillRect(-20, -8, 40, 16);
          // Tail
          ctx.beginPath(); ctx.moveTo(-20, -6); ctx.lineTo(-40, 0); ctx.lineTo(-20, 6); ctx.fill();
          // Head/Snout
          ctx.fillRect(20, -5, 15, 10);
          // Eyes
          ctx.fillStyle = '#facc15';
          ctx.beginPath(); ctx.arc(18, -4, 2, 0, Math.PI*2); ctx.fill();
          ctx.beginPath(); ctx.arc(18, 4, 2, 0, Math.PI*2); ctx.fill();
          break;

      case EntityType.PANTHER:
          ctx.fillStyle = '#171717'; // Neutral 900
          // Body
          ctx.beginPath(); ctx.ellipse(0, 0, 18, 8, 0, 0, Math.PI*2); ctx.fill();
          // Head
          ctx.beginPath(); ctx.arc(18, 0, 7, 0, Math.PI*2); ctx.fill();
          // Tail
          ctx.strokeStyle = '#171717'; ctx.lineWidth = 3;
          ctx.beginPath(); ctx.moveTo(-15, 0); ctx.quadraticCurveTo(-25, 10, -30, 0); ctx.stroke();
          // Eyes
          ctx.fillStyle = '#facc15';
          ctx.beginPath(); ctx.arc(20, -3, 1.5, 0, Math.PI*2); ctx.fill();
          ctx.beginPath(); ctx.arc(20, 3, 1.5, 0, Math.PI*2); ctx.fill();
          break;
          
      default:
          ctx.fillStyle = '#666';
          ctx.beginPath(); ctx.arc(0, 0, 10, 0, Math.PI*2); ctx.fill();
  }

  ctx.restore();
};
