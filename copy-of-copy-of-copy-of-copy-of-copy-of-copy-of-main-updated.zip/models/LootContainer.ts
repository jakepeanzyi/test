
import { Entity, GameSettings, EntityType } from '../types';
import { LOOT_CONTAINER_DATA } from '../constants';

export const drawLootContainer = (ctx: CanvasRenderingContext2D, ent: Entity, settings: GameSettings, time: number, isShadow: boolean = false) => {
  ctx.save();
  const data = LOOT_CONTAINER_DATA[ent.type];
  const color = ent.color || (data ? data.color : '#854d0e');
  const size = ent.size;

  ctx.rotate(ent.rotation);

  if (isShadow) {
      ctx.fillStyle = 'rgba(0,0,0,0.2)';
      // Adjust shadow shape based on container type
      if (ent.type.includes('BARREL')) {
          ctx.beginPath(); ctx.ellipse(0, 0, size/2, size/2, 0, 0, Math.PI*2); ctx.fill();
      } else {
          ctx.fillRect(-size/2, -size/4, size, size/2);
      }
      ctx.restore();
      return;
  }

  if (ent.hitReaction && ent.hitReaction > 0) {
    const intensity = ent.hitReaction * 0.8;
    ctx.translate((Math.random() - 0.5) * intensity, (Math.random() - 0.5) * intensity);
  }

  // Draw Logic
  if (ent.type.includes('BARREL')) {
      // Cylindrical
      ctx.fillStyle = color;
      ctx.beginPath(); ctx.arc(0, 0, size/2, 0, Math.PI*2); ctx.fill();
      
      if (ent.type === EntityType.OIL_BARREL) {
          ctx.fillStyle = '#000';
          ctx.font = 'bold 8px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('OIL', 0, 3);
      }
  } else if (ent.type === EntityType.TOOL_BOX || ent.type === EntityType.FISHERMAN_TACKLE_BOX) {
      // Rectangular with handle
      ctx.fillStyle = color;
      ctx.fillRect(-size/2, -size/3, size, size/1.5);
      // Handle
      ctx.fillStyle = '#1f2937';
      ctx.fillRect(-4, -size/3 - 2, 8, 4);
  } else if (ent.type.includes('CRATE') || ent.type.includes('CACHE') || ent.type.includes('BOX')) {
      // Boxy
      ctx.fillStyle = color;
      ctx.fillRect(-size/2, -size/2, size, size);
      
      // Cross brace
      ctx.strokeStyle = 'rgba(0,0,0,0.1)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-size/2, -size/2); ctx.lineTo(size/2, size/2);
      ctx.moveTo(size/2, -size/2); ctx.lineTo(-size/2, size/2);
      ctx.stroke();

      if (ent.type === EntityType.MEDICAL_CRATE || ent.type === EntityType.UNDERWATER_LAB_MEDICAL_CRATE) {
          ctx.fillStyle = '#ef4444';
          ctx.fillRect(-4, -10, 8, 20); ctx.fillRect(-10, -4, 20, 8);
      }
      if (ent.type === EntityType.MILITARY_CRATE || ent.type === EntityType.ELITE_TIER_CRATE) {
          ctx.fillStyle = 'rgba(255,255,255,0.2)';
          ctx.fillRect(-size/2, -size/4, size, size/2);
      }
  } else if (ent.type === EntityType.NATURAL_BEEHIVE) {
      // Organic
      ctx.fillStyle = '#facc15';
      ctx.beginPath(); ctx.arc(0, 0, size/2, 0, Math.PI*2); ctx.fill();
      ctx.fillStyle = '#a16207';
      ctx.beginPath(); ctx.arc(0, 0, size/3, 0, Math.PI*2); ctx.fill();
  } else {
      // Default Cube
      ctx.fillStyle = color;
      ctx.fillRect(-size/2, -size/2, size, size);
  }

  // Label/Icon overlay for elite/special
  if (ent.type.includes('ELITE') || ent.type.includes('LOCKED')) {
      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = 2;
      ctx.strokeRect(-size/2, -size/2, size, size);
  }

  ctx.restore();
};
