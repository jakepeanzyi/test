
import { Entity, GameSettings } from '../types';

export const drawWolf = (ctx: CanvasRenderingContext2D, wolf: Entity, settings: GameSettings, time: number) => {
  ctx.save();
  ctx.rotate(wolf.rotation);
  
  // Body
  ctx.fillStyle = '#1e293b'; 
  ctx.fillRect(-15, -8, 30, 16);
  
  // Tail (Wagging)
  if (!settings.lowPerformance) {
    const wag = Math.sin(time / 150) * 0.4;
    ctx.save();
    ctx.translate(-15, 0);
    ctx.rotate(wag);
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(-10, -2, 10, 4);
    ctx.restore();
  }

  // Head
  ctx.fillStyle = '#0f172a'; 
  ctx.fillRect(10, -6, 12, 12);
  
  // Eyes
  ctx.fillStyle = wolf.aiState === 'CHASE' ? '#ff0000' : '#ef4444'; 
  ctx.fillRect(18, -4, 2, 2); 
  ctx.fillRect(18, 2, 2, 2);
  
  ctx.restore();
};
