
import { Entity, GameSettings } from '../types';

export const drawBoar = (ctx: CanvasRenderingContext2D, boar: Entity, settings: GameSettings) => {
  ctx.save();
  ctx.rotate(boar.rotation);
  ctx.fillStyle = '#78350f'; 
  ctx.fillRect(-12, -8, 24, 16); 
  ctx.fillStyle = '#451a03'; 
  ctx.fillRect(8, -6, 10, 12); 
  ctx.fillStyle = 'white'; 
  ctx.fillRect(16, -7, 4, 2); 
  ctx.fillRect(16, 5, 4, 2); 
  ctx.restore();
};
