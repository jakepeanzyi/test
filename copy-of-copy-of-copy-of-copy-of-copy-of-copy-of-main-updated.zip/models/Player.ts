
import { Player, GameSettings, ItemType } from '../types';
import { drawItemModel } from './ItemModels';

export const drawPlayer = (ctx: CanvasRenderingContext2D, player: Player, settings: GameSettings, time: number, isShadow: boolean = false) => {
  ctx.save();
  
  if (isShadow) {
      ctx.rotate(player.rotation);
      ctx.fillStyle = 'rgba(0,0,0,0.2)';
      // Round shadow for player
      ctx.beginPath(); ctx.arc(0, 0, 16, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
      return;
  }

  const cust = player.customization || { skinColor: player.color || '#d4a373', cloakColor: '#262626', eyeColor: '#1c1917' };

  if (!settings.lowPerformance && player.hitReaction && player.hitReaction > 0) {
    const shake = player.hitReaction * 1.5;
    ctx.translate((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake);
  }

  let isFlashing = player.damageFlash && player.damageFlash > 0;

  if (player.isSleeping) {
    ctx.rotate(Math.PI / 2);
    ctx.translate(0, 5);
  } else {
    ctx.rotate(player.rotation);
  }
  
  // Body (Kenney Style: Simple rounded rect/circle)
  ctx.fillStyle = isFlashing ? '#ef4444' : cust.cloakColor; 
  
  // Shoulders/Body
  ctx.beginPath(); 
  ctx.arc(0, 0, 15, 0, Math.PI * 2); 
  ctx.fill();

  // Backpack (Small rectangle on back)
  if (!settings.lowPerformance) {
    ctx.fillStyle = isFlashing ? '#ef4444' : '#57534e';
    ctx.fillRect(-14, -8, 6, 16);
  }

  // Head (Circle)
  ctx.fillStyle = isFlashing ? '#fecaca' : cust.skinColor; 
  ctx.beginPath(); ctx.arc(0, 0, 12, 0, Math.PI * 2); ctx.fill();

  // Eyes (Simple dots for vector look)
  ctx.fillStyle = isFlashing ? 'white' : cust.eyeColor;
  if (player.isSleeping) {
      // Sleeping eyes (lines)
      ctx.strokeStyle = '#000';
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(4, -4); ctx.lineTo(8, -4); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(4, 4); ctx.lineTo(8, 4); ctx.stroke();
  } else {
      ctx.beginPath(); ctx.arc(6, -4, 2.5, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(6, 4, 2.5, 0, Math.PI * 2); ctx.fill();
  }

  // Hands (Floating circles typical of Kenney style)
  if (!player.isSleeping) {
    // Right Hand (Animation)
    let handX = 16, handY = 12, swingAngle = 0;
    if (player.isSwinging) {
        const p = player.swingProgress;
        if (p < 0.35) {
            const t = p / 0.35; const ease = 1 - Math.pow(1 - t, 2);
            swingAngle = -0.7 * ease; handX = 16 - (5 * ease); handY = 12 - (2 * ease);
        } else if (p < 0.6) {
            const t = (p - 0.35) / 0.25;
            swingAngle = -0.7 + (2.5 * t); handX = 11 + (14 * t); handY = 10 + (Math.sin(t * Math.PI) * 5);
        } else {
            const t = (p - 0.6) / 0.4; const ease = t * (2 - t);
            swingAngle = 1.8 * (1 - ease); handX = 25 - (9 * ease); handY = 12;
        }

        // [ULTRA] SWING TRAIL
        if (settings.ultraMode) {
            ctx.save();
            ctx.translate(handX, handY);
            ctx.rotate(swingAngle);
            ctx.beginPath();
            ctx.arc(15, 0, 15, Math.PI/2, Math.PI * 1.5, true);
            ctx.lineWidth = 4 * (1 - player.swingProgress);
            ctx.strokeStyle = `rgba(255, 255, 255, ${0.5 * (1 - player.swingProgress)})`;
            ctx.stroke();
            ctx.restore();
        }
    }

    // Left Hand
    ctx.fillStyle = isFlashing ? '#fecaca' : cust.skinColor;
    ctx.beginPath(); ctx.arc(14, -12, 5, 0, Math.PI * 2); ctx.fill();

    // Right Hand
    ctx.save();
    ctx.translate(handX, handY);
    ctx.beginPath(); ctx.arc(0, 0, 5, 0, Math.PI * 2); ctx.fill();

    const heldItem = player.inventory[player.selectedHotbarIndex];
    if (heldItem) {
      ctx.save(); ctx.rotate(swingAngle); ctx.translate(6, 0); 
      drawItemModel(ctx, heldItem.type, time);
      ctx.restore();
    }
    ctx.restore();
  }

  ctx.restore();
};
