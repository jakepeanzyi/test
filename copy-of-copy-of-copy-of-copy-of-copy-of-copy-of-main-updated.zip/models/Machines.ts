
import { Entity, EntityType, GameSettings } from '../types';

export const drawMachine = (ctx: CanvasRenderingContext2D, ent: Entity, settings: GameSettings, time: number, isShadow: boolean = false) => {
  ctx.save();
  ctx.rotate(ent.rotation);

  if (isShadow) {
      ctx.fillStyle = 'rgba(0,0,0,0.2)';
      ctx.fillRect(-ent.size/2, -ent.size/2, ent.size, ent.size);
      ctx.restore();
      return;
  }

  if (ent.type === EntityType.RECYCLER || ent.type === EntityType.SAFE_ZONE_RECYCLER) {
      ctx.fillStyle = '#166534'; // Green machine
      ctx.fillRect(-15, -15, 30, 30);
      ctx.fillStyle = '#000'; // Hole
      ctx.beginPath(); ctx.arc(0, 0, 8, 0, Math.PI*2); ctx.fill();
      // Movement
      if (ent.processorActive) {
          ctx.strokeStyle = '#facc15'; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.arc(0,0, 10, 0, Math.PI + Math.sin(time/100)); ctx.stroke();
      }
  } else if (ent.type === EntityType.GIANT_EXCAVATOR) {
      ctx.fillStyle = '#78350f'; // Rusted giant
      ctx.beginPath(); ctx.arc(0, 0, 100, 0, Math.PI*2); ctx.fill();
      // Arm
      ctx.fillStyle = '#a16207';
      ctx.save(); ctx.rotate(time / 5000);
      ctx.fillRect(0, -10, 120, 20);
      ctx.restore();
  } else if (ent.type === EntityType.MLRS) {
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(-20, -30, 40, 60);
      ctx.fillStyle = '#000';
      for(let i=0; i<12; i++) {
          const x = (i % 3) * 10 - 10;
          const y = Math.floor(i / 3) * 10 - 15;
          ctx.beginPath(); ctx.arc(x, y, 3, 0, Math.PI*2); ctx.fill();
      }
  } else if (ent.type === EntityType.MONUMENT_SAM_SITE || ent.type === EntityType.OUTPOST_SENTRY) {
      ctx.fillStyle = '#111827';
      ctx.fillRect(-10, -10, 20, 20);
      ctx.fillStyle = '#ef4444'; // Eye
      ctx.fillRect(5, -2, 4, 4);
      // Scan
      ctx.save(); ctx.rotate(Math.sin(time/500));
      ctx.fillStyle = 'rgba(239, 68, 68, 0.2)';
      ctx.beginPath(); ctx.moveTo(0,0); ctx.arc(0,0, 100, -0.2, 0.2); ctx.fill();
      ctx.restore();
  } else if (ent.type === EntityType.CZ_721) { // Loot Drone
      const float = Math.sin(time/300) * 3;
      ctx.translate(0, float);
      ctx.fillStyle = '#0ea5e9';
      ctx.beginPath(); ctx.arc(0, 0, 10, 0, Math.PI*2); ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke();
  } else {
      // Default
      ctx.fillStyle = '#57534e';
      ctx.fillRect(-ent.size/2, -ent.size/2, ent.size, ent.size);
  }

  ctx.restore();
};
