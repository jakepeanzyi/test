
import { Entity, GameSettings } from '../types';

export const drawProjectile = (ctx: CanvasRenderingContext2D, projectile: Entity, settings: GameSettings, time: number) => {
  ctx.save();
  ctx.rotate(projectile.rotation);

  // Arrow Shaft
  ctx.fillStyle = '#a8a29e';
  ctx.fillRect(-10, -1, 20, 2);
  
  // Arrow Head
  ctx.fillStyle = '#d6d3d1';
  ctx.beginPath();
  ctx.moveTo(10, -2);
  ctx.lineTo(14, 0);
  ctx.lineTo(10, 2);
  ctx.fill();

  // Fletching
  ctx.fillStyle = '#ef4444';
  ctx.fillRect(-12, -2, 4, 1);
  ctx.fillRect(-12, 1, 4, 1);

  ctx.restore();
};
