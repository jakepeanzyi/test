
import { Entity, GameSettings } from '../types';

export const drawScrap = (ctx: CanvasRenderingContext2D, scrap: Entity, settings: GameSettings) => {
  ctx.save();
  ctx.rotate(scrap.rotation);
  ctx.fillStyle = '#a1a1aa';
  ctx.fillRect(-scrap.size / 3, -scrap.size / 3, scrap.size / 1.5, scrap.size / 1.5);
  
  // Add some internal details
  ctx.fillStyle = '#71717a';
  ctx.fillRect(-2, -2, 4, 4);
  ctx.restore();
};
