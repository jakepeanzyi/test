
import { Entity, EntityType, GameSettings } from '../types';

export const drawCollectible = (ctx: CanvasRenderingContext2D, ent: Entity, settings: GameSettings, time: number, isShadow: boolean = false) => {
  ctx.save();
  ctx.rotate(ent.rotation);

  if (isShadow) {
      ctx.fillStyle = 'rgba(0,0,0,0.2)';
      ctx.beginPath(); ctx.arc(0, 0, ent.size/2, 0, Math.PI*2); ctx.fill();
      ctx.restore();
      return;
  }

  // Hit reaction
  if (ent.hitReaction && ent.hitReaction > 0) {
    const intensity = ent.hitReaction * 0.8;
    ctx.translate((Math.random() - 0.5) * intensity, (Math.random() - 0.5) * intensity);
  }

  switch(ent.type) {
      case EntityType.MUSHROOM:
          ctx.fillStyle = '#fef3c7'; // Stalk
          ctx.beginPath(); ctx.rect(-2, 0, 4, 6); ctx.fill();
          ctx.fillStyle = '#78350f'; // Cap
          ctx.beginPath(); ctx.arc(0, 0, 6, Math.PI, 0); ctx.fill();
          break;

      case EntityType.SCATTERED_STONE_ROCK:
          ctx.fillStyle = '#a8a29e'; 
          ctx.strokeStyle = '#57534e'; ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(-6, 4); ctx.lineTo(0, -6); ctx.lineTo(6, 2); ctx.closePath(); ctx.fill(); ctx.stroke();
          break;

      case EntityType.SCATTERED_METAL_ROCK:
          ctx.fillStyle = '#573024'; 
          ctx.beginPath(); ctx.arc(0, 0, 6, 0, Math.PI*2); ctx.fill();
          ctx.fillStyle = '#d6d3d1'; ctx.beginPath(); ctx.arc(-2, -2, 2, 0, Math.PI*2); ctx.fill();
          break;

      case EntityType.SCATTERED_SULFUR_ROCK:
          ctx.fillStyle = '#ca8a04'; 
          ctx.beginPath(); ctx.moveTo(-6, -2); ctx.lineTo(0, -6); ctx.lineTo(6, 0); ctx.lineTo(0, 6); ctx.closePath(); ctx.fill();
          break;

      case EntityType.STUMP:
          ctx.fillStyle = '#78350f'; 
          ctx.beginPath(); ctx.arc(0, 0, 10, 0, Math.PI*2); ctx.fill();
          ctx.fillStyle = '#d6d3d1'; // Rings
          ctx.beginPath(); ctx.arc(0, 0, 7, 0, Math.PI*2); ctx.fill();
          ctx.fillStyle = '#78350f'; 
          ctx.beginPath(); ctx.arc(0, 0, 3, 0, Math.PI*2); ctx.fill();
          break;

      case EntityType.DIESEL_BARREL:
          ctx.fillStyle = '#dc2626'; // Red barrel
          ctx.beginPath(); ctx.arc(0, 0, 12, 0, Math.PI*2); ctx.fill();
          ctx.strokeStyle = '#fca5a5'; ctx.lineWidth = 2; ctx.stroke();
          ctx.fillStyle = '#facc15'; // Yellow symbol
          ctx.font = 'bold 10px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('⚠', 0, 4);
          break;
  }

  ctx.restore();
};
