
import { Entity, GameSettings } from '../types';

export const drawRock = (ctx: CanvasRenderingContext2D, rock: Entity, settings: GameSettings, isShadow: boolean = false) => {
  ctx.save();
  const variant = rock.variant || 0;
  
  if (rock.hitReaction && rock.hitReaction > 0 && !isShadow) {
    const intensity = rock.hitReaction * 0.6;
    ctx.translate((Math.random() - 0.5) * intensity, (Math.random() - 0.5) * intensity);
  }

  if (isShadow) {
      ctx.rotate(rock.rotation);
      ctx.fillStyle = 'rgba(0,0,0,0.2)';
      ctx.beginPath(); ctx.arc(0, 0, rock.size/2, 0, Math.PI*2); ctx.fill();
      ctx.restore();
      return;
  }

  ctx.rotate(rock.rotation);
  
  // Kenney Style: Angular, flat grey
  ctx.fillStyle = '#9ca3af'; // Light grey

  ctx.beginPath();
  if (variant === 1) {
      // Pointy rock
      ctx.moveTo(-15, 10); ctx.lineTo(-10, -10); ctx.lineTo(0, -20); ctx.lineTo(15, -5); ctx.lineTo(10, 15); ctx.lineTo(-5, 12);
  } else {
      // Blocky rock
      ctx.moveTo(-20, 5); ctx.lineTo(-15, -15); ctx.lineTo(5, -20); ctx.lineTo(20, -5); ctx.lineTo(15, 15); ctx.lineTo(-10, 20);
  }
  ctx.closePath();
  ctx.fill();

  // Surface Detail (Cracks/Facets)
  ctx.fillStyle = '#d1d5db'; // Highlight facet
  ctx.beginPath();
  ctx.moveTo(-5, -5); ctx.lineTo(5, -10); ctx.lineTo(0, 0);
  ctx.fill();

  ctx.restore();
};
