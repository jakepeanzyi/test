
import { Entity, GameSettings } from '../types';

export const drawBush = (ctx: CanvasRenderingContext2D, bush: Entity, settings: GameSettings, time: number, isShadow: boolean = false) => {
  const seed = parseInt(bush.id.replace(/\D/g, '')) || 0;
  ctx.save();
  
  if (isShadow) {
      ctx.fillStyle = 'rgba(0,0,0,0.2)';
      ctx.beginPath(); ctx.arc(0, 0, bush.size * 0.5, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
      return;
  }
  
  if (bush.hitReaction && bush.hitReaction > 0) {
    const intensity = bush.hitReaction * 0.7;
    ctx.translate((Math.random() - 0.5) * intensity, (Math.random() - 0.5) * intensity);
  }

  const sway = Math.sin(time / 1500 + seed) * 2;
  ctx.translate(sway, 0);

  if (!settings.lowPerformance) {
    ctx.fillStyle = 'rgba(0,0,0,0.1)';
    ctx.beginPath(); ctx.ellipse(0, bush.size * 0.3, bush.size * 0.8, bush.size * 0.4, 0, 0, Math.PI * 2); ctx.fill();
  }
  
  ctx.fillStyle = bush.color;
  const offsets = [
    { x: -bush.size * 0.25, y: 0, r: bush.size * 0.45 },
    { x: bush.size * 0.25, y: bush.size * 0.1, r: bush.size * 0.4 },
    { x: 0, y: -bush.size * 0.2, r: bush.size * 0.5 },
    { x: -bush.size * 0.1, y: bush.size * 0.15, r: bush.size * 0.35 }
  ];
  
  offsets.forEach(o => {
    ctx.beginPath(); ctx.arc(o.x, o.y, o.r, 0, Math.PI * 2); ctx.fill();
  });

  ctx.fillStyle = 'rgba(255,255,255,0.15)';
  for(let i = 0; i < 3; i++) {
    const bx = ((seed * (i + 3)) % (bush.size * 0.8)) - (bush.size * 0.4);
    const by = ((seed * (i + 5)) % (bush.size * 0.6)) - (bush.size * 0.3);
    ctx.beginPath(); ctx.arc(bx, by, 2, 0, Math.PI * 2); ctx.fill();
  }
  
  ctx.restore();
};
