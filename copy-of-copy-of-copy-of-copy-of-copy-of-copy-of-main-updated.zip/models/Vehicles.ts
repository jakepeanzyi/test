
import { Entity, EntityType, GameSettings } from '../types';

export const drawVehicle = (ctx: CanvasRenderingContext2D, ent: Entity, settings: GameSettings, time: number, isShadow: boolean = false) => {
  ctx.save();
  ctx.rotate(ent.rotation);

  if (isShadow) {
      ctx.fillStyle = 'rgba(0,0,0,0.2)';
      if (ent.type.includes('HELICOPTER') || ent.type === EntityType.MINICOPTER || ent.type === EntityType.HOT_AIR_BALLOON) {
          ctx.beginPath(); ctx.ellipse(0, 0, ent.size/2, ent.size/2, 0, 0, Math.PI*2); ctx.fill();
      } else {
          ctx.fillRect(-ent.size/2, -ent.size/3, ent.size, ent.size/1.5);
      }
      ctx.restore();
      return;
  }

  // Generic hit shake
  if (ent.hitReaction && ent.hitReaction > 0) {
    ctx.translate((Math.random() - 0.5) * 2, (Math.random() - 0.5) * 2);
  }

  const rotorSpeed = 20; // Simulated rotor spin for helis

  switch(ent.type) {
      case EntityType.MINICOPTER:
      case EntityType.SCRAP_TRANSPORT_HELICOPTER:
      case EntityType.ATTACK_HELICOPTER:
      case EntityType.PATROL_HELICOPTER:
          // Body
          ctx.fillStyle = ent.type === EntityType.SCRAP_TRANSPORT_HELICOPTER ? '#a8a29e' : (ent.type === EntityType.ATTACK_HELICOPTER ? '#1e293b' : '#3f3f46');
          ctx.fillRect(-15, -10, 30, 20);
          // Tail
          ctx.fillRect(-30, -2, 15, 4);
          // Rotor
          ctx.strokeStyle = 'rgba(0,0,0,0.5)';
          ctx.lineWidth = 4;
          ctx.save();
          ctx.rotate(time / rotorSpeed);
          ctx.beginPath(); ctx.moveTo(-35, 0); ctx.lineTo(35, 0); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(0, -35); ctx.lineTo(0, 35); ctx.stroke();
          ctx.restore();
          break;

      case EntityType.HOT_AIR_BALLOON:
          // Basket
          ctx.fillStyle = '#78350f';
          ctx.fillRect(-8, -8, 16, 16);
          // Balloon (high above)
          if (!settings.lowPerformance) {
              ctx.save();
              ctx.scale(1.5, 1.5);
              ctx.fillStyle = '#ef4444';
              ctx.globalAlpha = 0.9;
              ctx.beginPath(); ctx.arc(0, 0, 25, 0, Math.PI*2); ctx.fill();
              ctx.fillStyle = '#facc15';
              ctx.beginPath(); ctx.arc(0, 0, 15, 0, Math.PI*2); ctx.fill();
              ctx.restore();
          }
          break;

      case EntityType.MOTOR_ROWBOAT:
      case EntityType.RHIB:
      case EntityType.TUGBOAT:
          // Hull
          ctx.fillStyle = ent.type === EntityType.RHIB ? '#1f2937' : (ent.type === EntityType.TUGBOAT ? '#dc2626' : '#9ca3af');
          ctx.beginPath();
          ctx.moveTo(20, 0);
          ctx.quadraticCurveTo(10, 12, -20, 10);
          ctx.lineTo(-20, -10);
          ctx.quadraticCurveTo(10, -12, 20, 0);
          ctx.fill();
          // Motor
          ctx.fillStyle = '#000';
          ctx.fillRect(-22, -4, 4, 8);
          break;

      case EntityType.SOLO_SUBMARINE:
      case EntityType.DUO_SUBMARINE:
          ctx.fillStyle = '#facc15'; // Yellow subs
          ctx.beginPath(); ctx.ellipse(0, 0, 20, 8, 0, 0, Math.PI*2); ctx.fill();
          // Hatch
          ctx.fillStyle = '#1e293b';
          ctx.beginPath(); ctx.arc(5, 0, 6, 0, Math.PI*2); ctx.fill();
          break;

      case EntityType.BRADLEY_APC:
          ctx.fillStyle = '#3f6212'; // Tank Green
          ctx.fillRect(-20, -12, 40, 24);
          // Turret
          ctx.fillStyle = '#14532d';
          ctx.beginPath(); ctx.arc(0, 0, 10, 0, Math.PI*2); ctx.fill();
          // Barrel
          ctx.fillStyle = '#000';
          ctx.fillRect(8, -2, 14, 4);
          break;

      case EntityType.MODULE_VEHICLE_2:
      case EntityType.MODULE_VEHICLE_3:
      case EntityType.MODULE_VEHICLE_4:
      case EntityType.SCRAPPED_PICKUP_TRUCK:
          ctx.fillStyle = '#a16207'; // Rust
          ctx.fillRect(-20, -10, 40, 20);
          // Cabin
          ctx.fillStyle = '#262626';
          ctx.fillRect(-5, -8, 15, 16);
          break;

      case EntityType.MOTORBIKE:
      case EntityType.SIDECAR_MOTORBIKE:
      case EntityType.BIKE:
      case EntityType.TRIKE:
      case EntityType.SNOWMOBILE:
          ctx.fillStyle = ent.type === EntityType.SNOWMOBILE ? '#fff' : '#ef4444';
          ctx.fillRect(-10, -3, 20, 6);
          // Handlebars
          ctx.strokeStyle = '#000'; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(8, -6); ctx.lineTo(8, 6); ctx.stroke();
          if (ent.type === EntityType.SIDECAR_MOTORBIKE) {
              ctx.fillRect(0, 4, 10, 6); // Sidecar
          }
          break;
          
      case EntityType.MAGNET_CRANE:
          ctx.fillStyle = '#facc15'; // Construction Yellow
          ctx.fillRect(-15, -15, 30, 30);
          // Arm
          ctx.fillStyle = '#000';
          ctx.fillRect(0, -4, 30, 8);
          break;

      default:
          ctx.fillStyle = '#78716c';
          ctx.fillRect(-10, -10, 20, 20);
  }

  ctx.restore();
};
