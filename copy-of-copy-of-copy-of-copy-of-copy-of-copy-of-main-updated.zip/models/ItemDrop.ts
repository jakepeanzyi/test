
import { Entity, GameSettings } from '../types';

export const drawItemDrop = (ctx: CanvasRenderingContext2D, item: Entity, settings: GameSettings, time: number) => {
  ctx.save();
  if (settings.shimmerEnabled && !settings.lowPerformance) {
    const float = Math.sin(time / 200) * 5;
    ctx.translate(0, float);
    
    // Shadow pulse
    ctx.fillStyle = 'rgba(0,0,0,0.2)';
    ctx.beginPath(); ctx.ellipse(0, 10 - float, 6, 3, 0, 0, Math.PI * 2); ctx.fill();
  }
  
  ctx.fillStyle = item.color; 
  ctx.beginPath(); ctx.arc(0, 0, item.size, 0, Math.PI * 2); ctx.fill();
  
  ctx.restore();
};
