
import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyBtzsiAGSWrZu_ogAiAoCE_Rm1Jim5gy8A",
  authDomain: "picosurvial.firebaseapp.com",
  databaseURL: "https://picosurvial-default-rtdb.firebaseio.com",
  projectId: "picosurvial",
  storageBucket: "picosurvial.firebasestorage.app",
  messagingSenderId: "161928957082",
  appId: "1:161928957082:web:b956b7d0c2fea686566323",
  measurementId: "G-0KFKM8PQJS"
};

const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);
