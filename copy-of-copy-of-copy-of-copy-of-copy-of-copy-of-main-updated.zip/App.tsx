
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  GameState, Player, EntityType, ItemType, Vector2, Entity, WeatherType, GameSettings, InventoryItem, ItemPickupNotification, ItemCategory, Particle, NetworkPlayer, Cloud, Footprint
} from './types';
import { 
  WORLD_SIZE, PLAYER_SPEED, STAMINA_REGEN, HUNGER_DECAY, THIRST_DECAY, CHUNK_SIZE, VIEW_RADIUS, BUILDING_RECIPES, ITEM_DATA, RECIPES, UPGRADE_DATA, BASE_INVENTORY_SLOTS, CONTAINER_SLOTS, COLLECTIBLE_DATA, MAP_CHUNK_RADIUS
} from './constants';
import { generateEntitiesForChunk, getBiomeAt, findSpawnPosition, renderChunkTerrain, setWorldSeed } from './engine/WorldGenerator';
import UIOverlay from './components/UIOverlay';
import GameCanvas from './components/GameCanvas';
import MapOverlay from './components/MapOverlay';
import LandingPage from './components/LandingPage';
import Lobby from './components/Lobby';
import LoadingScreen from './components/LoadingScreen';
import AuthForm from './components/AuthForm';
import PostProcessing from './components/PostProcessing';
import { playFab, PlayFabUser } from './services/playfabService';
import { 
    loadPlayerProfile, updatePlayerState,
    saveBuildingToServer, removeBuildingFromServer, fetchWorldBuildingsOnce,
    subscribeToPlayers, subscribeToWorldBuildings,
    subscribeToWorldState, updateWorldState, damagePlayer,
    subscribeToDestroyedEntities, markEntityDestroyed
} from './services/persistenceService';
import { soundService } from './services/soundService';
import { ref, onValue } from "firebase/database";
import { db } from "./firebase";

const SPRINT_SPEED = 4.0; 
const SPRINT_STAMINA_COST = 0.4;
const SNAP_THRESHOLD = 40; 
const HARVEST_RANGE = 150; 
const LOOT_RANGE = 100; 
const DECAY_TICK_RATE = 10000;
const TICK_RATE = 100;
const TC_PROTECTION_RADIUS = 300;

// CHUNK LOADING SETTINGS
const DEFAULT_RENDER_DISTANCE = 2;

// AI Constants
const AGGRO_RANGE = 300;
const FLEE_RANGE = 200;
const ANIMAL_SPEED_WANDER = 0.5;
const ANIMAL_SPEED_RUN = 2.8;

const AGGRESSIVE_ANIMALS = new Set([
    EntityType.WOLF, EntityType.BEAR, EntityType.POLAR_BEAR, EntityType.SHARK, 
    EntityType.CROCODILE, EntityType.SNAKE, EntityType.PANTHER, EntityType.BOAR
]);

// PARTICLE POOLING
const MAX_PARTICLES = 200;
const particlePool: Particle[] = new Array(MAX_PARTICLES).fill(null).map(() => ({ x: 0, y: 0, vx: 0, vy: 0, life: 0, maxLife: 0, color: '', size: 0, type: 'circle', active: false }));

const spawnParticle = (x: number, y: number, color: string, type: 'circle' | 'leaf' | 'stone' | 'spark' = 'circle', count: number = 1) => {
    let spawned = 0;
    for (let i = 0; i < MAX_PARTICLES; i++) {
        if (!particlePool[i].active) {
            particlePool[i].active = true;
            particlePool[i].x = x;
            particlePool[i].y = y;
            particlePool[i].vx = (Math.random() - 0.5) * 4;
            particlePool[i].vy = (Math.random() - 0.5) * 4;
            particlePool[i].life = 20 + Math.random() * 20;
            particlePool[i].maxLife = particlePool[i].life;
            particlePool[i].color = color;
            particlePool[i].size = 2 + Math.random() * 3;
            particlePool[i].type = type;
            spawned++;
            if (spawned >= count) break;
        }
    }
};

const updateParticles = () => {
    for (let i = 0; i < MAX_PARTICLES; i++) {
        if (particlePool[i].active) {
            particlePool[i].x += particlePool[i].vx;
            particlePool[i].y += particlePool[i].vy;
            particlePool[i].life--;
            if (particlePool[i].life <= 0) {
                particlePool[i].active = false;
            }
        }
    }
};

const isLowSpecDevice = () => {
  if (typeof navigator !== 'undefined') {
    // @ts-ignore
    const ram = navigator.deviceMemory || 8; 
    const cores = navigator.hardwareConcurrency || 8;
    return ram < 4 || cores < 4;
  }
  return false;
};

const generateStartingItems = () => {
  const rockId = `start-rock-${Math.random().toString(36).substr(2, 9)}`;
  const torchId = `start-torch-${Math.random().toString(36).substr(2, 9)}`;
  
  const items = new Array(BASE_INVENTORY_SLOTS).fill(null) as (InventoryItem | null)[];
  items[0] = { id: rockId, type: ItemType.ROCK_TOOL, count: 1, durability: 100, maxDurability: 100 };
  items[1] = { id: torchId, type: ItemType.TORCH, count: 1, durability: 100, maxDurability: 100 };
  
  return { inventory: items, hotbar: [rockId, torchId, null, null, null, null] };
};

const INITIAL_PLAYER_BASE: Omit<Player, 'inventory' | 'hotbar'> = { 
  id: 'player-1', type: EntityType.PLAYER, pos: { x: 0, y: 0 }, size: 16, health: 100, maxHealth: 100, hunger: 100, thirst: 100, stamina: 100, bodyTemperature: 50, rotation: 0, velocity: { x: 0, y: 0 }, selectedHotbarIndex: 0, color: '#d4a373', customization: { skinColor: '#d4a373', cloakColor: '#262626', eyeColor: '#1c1917' }, isSwinging: false, swingProgress: 0, walkCycle: 0, isMoving: false, regenCooldown: 0, isSleeping: false, sleepTimer: 0, spawnProtectionTimer: 0, damageFlash: 0, godMode: false, speedMultiplier: 1, selectedBuildingType: EntityType.WOOD_FLOOR, unlockedBlueprints: [], visitedChunks: [], isSwimming: false
};

const getInitialPlayer = (): Player => {
  const { inventory, hotbar } = generateStartingItems();
  const spawnPos = { x: 0, y: 0 }; // Will be overridden by findSpawnPosition
  return { ...INITIAL_PLAYER_BASE, pos: spawnPos, inventory, hotbar } as Player;
};

const SOLID_ENTITIES = new Set([
  EntityType.TREE, EntityType.ROCK, EntityType.STONE_ORE_NODE, EntityType.METAL_ORE_NODE, EntityType.SULFUR_ORE_NODE, EntityType.SCRAP, EntityType.WALL, EntityType.STONE_WALL, EntityType.METAL_WALL, EntityType.HQ_WALL, EntityType.DOORWAY, EntityType.WINDOW_WALL, EntityType.WORKBENCH, EntityType.FURNACE, EntityType.FIREPIT, EntityType.STORAGE_BOX, EntityType.LARGE_CHEST, EntityType.SPIKE_TRAP, EntityType.RAIN_COLLECTOR, EntityType.BARBED_WIRE, EntityType.LAND_MINE, EntityType.SOLAR_PANEL, EntityType.WOLF, EntityType.BEAR, EntityType.BOAR, EntityType.NPC, EntityType.LOOT_CRATE, EntityType.TOOL_CUPBOARD, EntityType.SINGLE_DOOR, EntityType.PLAYER
]);

const getCollisionRadius = (ent: Entity): number => {
    if (ent.isBuilding) {
        if ([EntityType.WALL, EntityType.STONE_WALL, EntityType.METAL_WALL, EntityType.HQ_WALL, EntityType.DOORWAY, EntityType.WINDOW_WALL, EntityType.SINGLE_DOOR].includes(ent.type)) {
            return 10;
        }
        if (ent.type === EntityType.TOOL_CUPBOARD || ent.type === EntityType.SLEEPING_BAG) {
            return 15;
        }
        return ent.size * 0.45;
    }
    switch (ent.type) {
        case EntityType.TREE: return 12;
        case EntityType.ROCK: 
        case EntityType.STONE_ORE_NODE:
        case EntityType.METAL_ORE_NODE:
        case EntityType.SULFUR_ORE_NODE: return ent.size * 0.5;
        case EntityType.SCRAP: return 10;
        case EntityType.LOOT_CRATE: return 15;
        case EntityType.PLAYER: return 12;
        case EntityType.WOLF: return 12;
        case EntityType.BEAR: return 20;
        case EntityType.BOAR: return 12;
        case EntityType.BUSH: return 0;
        case EntityType.PLANT_HEMP: 
        case EntityType.HEMP_FIBERS:
        case EntityType.PLANT_BERRY: 
        case EntityType.PLANT_PUMPKIN: 
        case EntityType.BLUE_BERRY_BUSH:
        case EntityType.RED_BERRY_BUSH:
        case EntityType.GREEN_BERRY_BUSH:
        case EntityType.YELLOW_BERRY_BUSH:
        case EntityType.WHITE_BERRY_BUSH:
        case EntityType.WILD_CORN_PLANT:
        case EntityType.WILD_POTATO_PLANT:
        case EntityType.WILD_PUMPKIN_PLANT:
        case EntityType.WILD_WHEAT:
        case EntityType.MUSHROOM:
        case EntityType.WILD_ROSE:
        case EntityType.WILD_SUNFLOWER:
        case EntityType.WILD_ORCHID:
            return 0;
        default: return ent.size * 0.4;
    }
};

const isPositionValid = (pos: Vector2, chunks: Record<string, Entity[]>, playerRadius: number, ignoreBuildings: boolean = false, ignoreId?: string, isPlacement: boolean = false): boolean => {
  const cx = Math.floor(pos.x / CHUNK_SIZE);
  const cy = Math.floor(pos.y / CHUNK_SIZE);
  
  for (let x = cx - 1; x <= cx + 1; x++) {
    for (let y = cy - 1; y <= cy + 1; y++) {
      const entities = chunks[`${x},${y}`];
      if (!entities) continue;
      const len = entities.length;
      for (let i = 0; i < len; i++) {
        const ent = entities[i];
        if (ent.id === ignoreId) continue;
        if (isPlacement && ent.type === EntityType.PLAYER) continue;

        const isDoor = [EntityType.WOOD_DOOR, EntityType.STONE_DOOR, EntityType.METAL_DOOR, EntityType.SINGLE_DOOR].includes(ent.type);
        if (!isDoor && !SOLID_ENTITIES.has(ent.type)) continue;
        if (isDoor && ent.isOpen) continue;
        
        if (ignoreBuildings && ent.isBuilding) continue;
        
        const entRadius = getCollisionRadius(ent);
        if (entRadius <= 0) continue;

        const dx = pos.x - ent.pos.x;
        const dy = pos.y - ent.pos.y;
        
        const isWall = [EntityType.WALL, EntityType.STONE_WALL, EntityType.METAL_WALL, EntityType.HQ_WALL, EntityType.DOORWAY, EntityType.WINDOW_WALL, EntityType.SINGLE_DOOR].includes(ent.type) || isDoor;
        if (isWall) {
          const cos = Math.cos(-ent.rotation);
          const sin = Math.sin(-ent.rotation);
          const localX = dx * cos - dy * sin;
          const localY = dx * sin + dy * cos;
          const halfWidth = ent.size / 2;
          const halfThick = 10;
          if (Math.abs(localX) < halfWidth + playerRadius && Math.abs(localY) < halfThick + playerRadius) {
              return false;
          }
        } else {
          const minDist = playerRadius + entRadius;
          if (dx*dx + dy*dy < minDist * minDist) return false;
        }
      }
    }
  }
  return true;
};

const addItemToInventory = (inventory: (InventoryItem | null)[], type: ItemType, count: number): (InventoryItem | null)[] => {
  const data = ITEM_DATA[type];
  if (!data) return inventory;
  const stack = data.stackSize || 64;
  let remaining = count;
  const newInv = [...inventory];
  
  for (let i = 0; i < newInv.length; i++) {
    const item = newInv[i];
    if (item && item.type === type && item.count < stack) {
      const canAdd = Math.min(remaining, stack - item.count);
      newInv[i] = { ...item, count: item.count + canAdd };
      remaining -= canAdd;
    }
    if (remaining <= 0) break;
  }

  if (remaining > 0) {
      for (let i = 0; i < newInv.length; i++) {
          if (newInv[i] === null) {
              const add = Math.min(remaining, stack);
              const newItem: InventoryItem = { 
                  id: `it-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`, 
                  type, 
                  count: add 
              };
              if (data && data.maxDurability !== undefined) {
                  newItem.durability = data.maxDurability;
                  newItem.maxDurability = data.maxDurability;
              }
              newInv[i] = newItem;
              remaining -= add;
              if (remaining <= 0) break;
          }
      }
  }
  return newInv;
};

const addNotification = (list: ItemPickupNotification[], type: ItemType, count: number): ItemPickupNotification[] => {
    const now = Date.now();
    let newList = list.filter(n => now - n.timestamp < 5000);
    const existingIndex = newList.findIndex(n => n.type === type && (now - n.timestamp < 2000));
    if (existingIndex !== -1) {
      const existing = newList[existingIndex];
      newList[existingIndex] = { ...existing, count: existing.count + count, timestamp: now };
      return newList;
    }
    return [...newList, { id: `not-${now}-${Math.random()}`, type, count, timestamp: now }];
};

const lerp = (start: number, end: number, t: number) => start * (1 - t) + end * t;

const App: React.FC = () => {
  const [authState, setAuthState] = useState<{ user: PlayFabUser | null, show: boolean, mode: 'login' | 'register' }>({ user: playFab.getPersistedUser(), show: false, mode: 'login' });
  const [view, setView] = useState<'landing' | 'lobby' | 'game'>('landing');
  const [isLoading, setIsLoading] = useState(false);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [loadingText, setLoadingText] = useState('');
  
  const remotePlayersRef = useRef<Map<string, NetworkPlayer>>(new Map());
  const remotePlayersListRef = useRef<Player[]>([]);
  const [remotePlayersUI, setRemotePlayersUI] = useState<Player[]>([]);
  
  const navigateTo = useCallback((v: 'landing' | 'lobby' | 'game') => {
      if (v === 'game') setIsLoading(true); 
      setView(v);
  }, []);
  
  const [destroyedEntityIds, setDestroyedEntityIds] = useState<Set<string>>(new Set());

  // Use a Ref for the chunk generation queue to decouple it from React state renders
  const chunkGenerationQueueRef = useRef<{x: number, y: number, key: string}[]>([]);

  // Initial Game State Factory
  const createInitialState = (): GameState => {
    const isLow = isLowSpecDevice();
    const clouds: Cloud[] = [];
    for(let i=0; i<15; i++) {
        clouds.push({
            id: `cloud-${i}`,
            x: (Math.random()-0.5) * 4000,
            y: (Math.random()-0.5) * 4000,
            scale: 0.8 + Math.random() * 1.5,
            speed: 0.2 + Math.random() * 0.3,
            opacity: 0.15 + Math.random() * 0.25,
            textureId: Math.floor(Math.random() * 3)
        });
    }

    return { 
      player: getInitialPlayer(), 
      chunks: {}, terrainCache: {}, projectiles: [], particles: particlePool, clouds, footprints: [], worldSize: WORLD_SIZE, dayTime: 6000, weather: WeatherType.CLEAR, weatherTimer: 5000, camera: { x: 0, y: 0 }, craftingQueue: [], uiOpen: null, openedContainerId: null, inspectingItemId: null, selectedBuildingId: null, currentServer: 1, 
      settings: { 
          volume: 80, musicVolume: 50, ambienceVolume: 60, particles: isLow ? 'Low' : 'High', shimmerEnabled: !isLow, shimmerRange: 120, lowPerformance: isLow, 
          controls: { MOVE_UP: 'KeyW', MOVE_DOWN: 'KeyS', MOVE_LEFT: 'KeyA', MOVE_RIGHT: 'KeyD', ACTION: 'KeyE', INVENTORY: 'Tab', SETTINGS: 'KeyX', SPRINT: 'ShiftLeft' },
          showCoords: true, showFPS: false, showNames: true, screenShakeEnabled: true, vignetteStrength: 80, scanlinesEnabled: false, hudOpacity: 100, crosshairStyle: 'circle', viewBobbing: true, shadowsEnabled: !isLow, autoSprint: false, streamerMode: false, retroMode: false, ultraMode: !isLow,
          renderDistance: DEFAULT_RENDER_DISTANCE
      },
      screenShake: 0, buildingRotation: 0, buildingPreview: null, consoleHistory: ["System: Link Established."], airdropTimer: 15000, notifications: [],
      mapOpen: false, team: [], debugGrid: false, debugChunks: false
    };
  };

  const gameStateRef = useRef<GameState>(createInitialState());
  const [uiState, setUiState] = useState<GameState>(gameStateRef.current);
  const lastUiUpdateRef = useRef(0);
  const frameCountRef = useRef(0);
  const lastChunkCheckRef = useRef(0); // For throttling chunk management
  const lastTimeRef = useRef<number>(0); // For RAF delta

  const keysRef = useRef<Record<string, boolean>>({});
  const mousePosRef = useRef<Vector2>({ x: 0, y: 0 });
  const isMouseDownRef = useRef<boolean>(false);
  const swingHitRegisteredRef = useRef<boolean>(false);
  const lastAttackTimeRef = useRef<number>(0);
  const playerRef = useRef<Player>(gameStateRef.current.player);
  const buildingPreviewRef = useRef<any>(null); 
  const generatedChunksRef = useRef<Set<string>>(new Set());
  
  useEffect(() => { 
      playerRef.current = gameStateRef.current.player; 
      buildingPreviewRef.current = gameStateRef.current.buildingPreview;
  }, []);

  // Sync helpers
  const syncUiState = () => setUiState({ ...gameStateRef.current });
  const updateSettings = (s: Partial<GameSettings>) => {
      gameStateRef.current.settings = { ...gameStateRef.current.settings, ...s };
      syncUiState();
  };

  // Chunk Management Logic
  const manageChunks = useCallback((playerPos: Vector2) => {
      const cx = Math.floor(playerPos.x / CHUNK_SIZE);
      const cy = Math.floor(playerPos.y / CHUNK_SIZE);
      const state = gameStateRef.current;
      
      const renderDist = state.settings.renderDistance || 2;
      const loadRadius = renderDist + 1; 
      const unloadRadius = loadRadius + 2;
      
      const loadedKeys = new Set(Object.keys(state.chunks));
      const neededChunks: {x: number, y: number, key: string, dist: number}[] = [];

      // Identify needed chunks
      for (let x = cx - loadRadius; x <= cx + loadRadius; x++) {
          for (let y = cy - loadRadius; y <= cy + loadRadius; y++) {
              const key = `${x},${y}`;
              
              // Only consider valid map area
              if (Math.abs(x) <= MAP_CHUNK_RADIUS + 2 && Math.abs(y) <= MAP_CHUNK_RADIUS + 2) {
                  // If chunk is missing, we need it
                  if (!state.chunks[key]) {
                      const dist = (x-cx)**2 + (y-cy)**2;
                      neededChunks.push({x, y, key, dist});
                  }
              }
          }
      }

      // Cleanup Queue: Remove chunks that are now too far away
      chunkGenerationQueueRef.current = chunkGenerationQueueRef.current.filter(c => {
          const dist = Math.max(Math.abs(c.x - cx), Math.abs(c.y - cy));
          return dist <= loadRadius;
      });

      // Add missing chunks to queue if not already there
      neededChunks.forEach(c => {
          if (!chunkGenerationQueueRef.current.some(q => q.key === c.key)) {
              chunkGenerationQueueRef.current.push(c);
          }
      });

      // Sort queue by distance to player so we load closest first
      chunkGenerationQueueRef.current.sort((a, b) => {
          const distA = (a.x - cx)**2 + (a.y - cy)**2;
          const distB = (b.x - cx)**2 + (b.y - cy)**2;
          return distA - distB;
      });

      // Unload distant chunks
      loadedKeys.forEach(key => {
          const [kx, ky] = key.split(',').map(Number);
          // Check distance
          if (Math.abs(kx - cx) > unloadRadius || Math.abs(ky - cy) > unloadRadius) {
              delete state.chunks[key];
              delete state.terrainCache[key]; 
          }
      });
  }, []);

  // REAL LOADING IMPLEMENTATION
  useEffect(() => {
    if (isLoading && view === 'game') {
      let isCancelled = false;
      const loadWorld = async () => {
          // 0. Initialize Random World Seed
          const seed = Math.floor(Math.random() * 100000);
          setWorldSeed(seed);
          setLoadingText(`Initializing Seed #${seed}...`);
          setLoadingProgress(10);
          await new Promise(r => setTimeout(r, 200));

          // 1. Locate Spawn
          const spawn = findSpawnPosition();
          gameStateRef.current.player.pos = spawn;
          
          setLoadingText("Loading Local Terrain...");
          
          // 2. Initial Chunk Load (Around Spawn Only)
          manageChunks(spawn);
          
          // Process queue immediately for initial load
          const initialQueue = chunkGenerationQueueRef.current;
          for(const item of initialQueue) {
              if (Math.abs(item.x - Math.floor(spawn.x/CHUNK_SIZE)) <= 1 && Math.abs(item.y - Math.floor(spawn.y/CHUNK_SIZE)) <= 1) {
                  gameStateRef.current.chunks[item.key] = generateEntitiesForChunk(item.x, item.y);
                  const img = await renderChunkTerrain(item.x, item.y);
                  gameStateRef.current.terrainCache[item.key] = img;
              }
          }
          // Clear processed items
          chunkGenerationQueueRef.current = chunkGenerationQueueRef.current.filter(i => !gameStateRef.current.chunks[i.key]);

          setLoadingProgress(80);
          await new Promise(r => setTimeout(r, 300));

          setLoadingText("Warming Up...");
          setLoadingProgress(100);
          setIsLoading(false);
      };

      loadWorld();
      return () => { isCancelled = true; };
    }
  }, [isLoading, view, manageChunks]);

  // Game Loop and Input Handling
  useEffect(() => {
    if (view !== 'game' || isLoading) return;

    const handleKeyDown = (e: KeyboardEvent) => {
        const state = gameStateRef.current;
        if (state.uiOpen && e.code !== 'Escape' && e.code !== state.settings.controls.INVENTORY && e.code !== state.settings.controls.SETTINGS && e.code !== 'KeyB') return;
        keysRef.current[e.code] = true;
        if (e.code === state.settings.controls.INVENTORY) {
            state.uiOpen = state.uiOpen === 'inv' ? null : 'inv';
            state.openedContainerId = null;
            syncUiState();
        } else if (e.code === 'KeyM') {
            state.mapOpen = !state.mapOpen;
            syncUiState();
        } else if (e.code === state.settings.controls.SETTINGS) {
            state.uiOpen = state.uiOpen === 'settings' ? null : 'settings';
            syncUiState();
        } else if (e.code === 'Escape') {
            state.uiOpen = null;
            state.openedContainerId = null;
            state.mapOpen = false;
            syncUiState();
        } else if (e.code === 'KeyR' && !state.uiOpen) {
            state.buildingRotation = (state.buildingRotation + Math.PI/2) % (Math.PI*2);
        } else if (e.code.startsWith('Digit')) {
            const idx = parseInt(e.code.replace('Digit', '')) - 1;
            if (idx >= 0 && idx < 6) {
                state.player.selectedHotbarIndex = idx;
                syncUiState();
            }
        } else if (e.code === 'KeyB') {
            const held = state.player.inventory[state.player.selectedHotbarIndex];
            if (held?.type === ItemType.BUILDING_PLAN) {
                if (state.uiOpen === 'build_wheel') {
                    state.uiOpen = null;
                } else if (!state.uiOpen) {
                    state.uiOpen = 'build_wheel';
                }
                syncUiState();
            }
        }
    };

    const handleContextMenu = (e: MouseEvent) => {
        const state = gameStateRef.current;
        const held = state.player.inventory[state.player.selectedHotbarIndex];
        if (held?.type === ItemType.BUILDING_PLAN) {
            e.preventDefault();
            if (state.uiOpen === 'build_wheel') {
                state.uiOpen = null;
            } else if (!state.uiOpen) {
                state.uiOpen = 'build_wheel';
            }
            syncUiState();
        }
    };

    const handleKeyUp = (e: KeyboardEvent) => { keysRef.current[e.code] = false; };
    const handleMouseDown = (e: MouseEvent) => { 
        if (!gameStateRef.current.uiOpen && e.button === 0) isMouseDownRef.current = true; 
    };
    const handleMouseUp = () => { isMouseDownRef.current = false; };
    const handleMouseMove = (e: MouseEvent) => { mousePosRef.current = { x: e.clientX, y: e.clientY }; };
    const handleBlur = () => { keysRef.current = {}; isMouseDownRef.current = false; };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('blur', handleBlur);
    window.addEventListener('contextmenu', handleContextMenu);

    let rafId: number;
    const loop = (timestamp: number) => {
        if (!lastTimeRef.current) lastTimeRef.current = timestamp;
        const dt = (timestamp - lastTimeRef.current) / 16.66; // Normalize to 60fps
        lastTimeRef.current = timestamp;

        const state = gameStateRef.current;
        const player = state.player;
        const controls = state.settings.controls;
        const keys = keysRef.current;
        const now = Date.now();
        frameCountRef.current++;

        // Chunk Management Check (Every 500ms)
        if (now - lastChunkCheckRef.current > 500) {
            manageChunks(player.pos);
            lastChunkCheckRef.current = now;
        }

        // --- Process Chunk Queue (One per frame) ---
        if (chunkGenerationQueueRef.current.length > 0) {
            const next = chunkGenerationQueueRef.current.shift();
            if (next && !state.chunks[next.key]) {
                state.chunks[next.key] = generateEntitiesForChunk(next.x, next.y);
                // Fire off terrain generation (handled by GPU/offscreen canvas)
                renderChunkTerrain(next.x, next.y).then(img => {
                    state.terrainCache[next.key] = img;
                });
            }
        }

        // Check Death
        if (player.health <= 0 && !state.uiOpen) {
            state.uiOpen = 'respawn';
            syncUiState();
            return;
        }

        // --- Rotation Logic ---
        const camX = state.camera.x;
        const camY = state.camera.y;
        const screenPlayerX = (window.innerWidth / 2) + (player.pos.x - camX);
        const screenPlayerY = (window.innerHeight / 2) + (player.pos.y - camY);
        const dx = mousePosRef.current.x - screenPlayerX;
        const dy = mousePosRef.current.y - screenPlayerY;
        
        // Rotation Deadzone to prevent jitter
        if (dx*dx + dy*dy > 400) {
            player.rotation = Math.atan2(dy, dx);
        }

        // --- Relative Movement Logic (Tank/Strafing) ---
        let forward = 0;
        let strafe = 0;

        if (!state.uiOpen && !player.isSleeping && player.health > 0) {
            if (keys[controls.MOVE_UP]) forward += 1;
            if (keys[controls.MOVE_DOWN]) forward -= 1;
            if (keys[controls.MOVE_RIGHT]) strafe += 1;
            if (keys[controls.MOVE_LEFT]) strafe -= 1;
        }

        const inputLen = Math.sqrt(forward*forward + strafe*strafe);
        if (inputLen > 0) {
            forward /= inputLen;
            strafe /= inputLen;
        }

        // BIOME & SWIMMING CHECK
        const currentBiome = getBiomeAt(player.pos);
        player.isSwimming = currentBiome === 'LAKE' || currentBiome === 'OCEAN'; 

        const isSprinting = keys[controls.SPRINT] && player.stamina > 0;
        let speed = (isSprinting ? SPRINT_SPEED : PLAYER_SPEED) * (player.speedMultiplier || 1);
        if (player.isSwimming) speed *= 0.6; 

        // Apply Speed and Delta
        const moveStep = speed * Math.min(dt, 2.0); 
        
        const cos = Math.cos(player.rotation);
        const sin = Math.sin(player.rotation);

        let vx = (forward * cos) - (strafe * sin);
        let vy = (forward * sin) + (strafe * cos);

        vx *= moveStep;
        vy *= moveStep;

        let newX = player.pos.x + vx;
        let newY = player.pos.y + vy;

        if (!isPositionValid({ x: newX, y: player.pos.y }, state.chunks, player.size, false, player.id)) newX = player.pos.x;
        if (!isPositionValid({ x: newX, y: newY }, state.chunks, player.size, false, player.id)) newY = player.pos.y;

        player.pos.x = newX;
        player.pos.y = newY;
        player.isMoving = (forward !== 0 || strafe !== 0);

        // Camera follow (lerp)
        state.camera.x = lerp(state.camera.x, newX, 0.1 * dt);
        state.camera.y = lerp(state.camera.y, newY, 0.1 * dt);

        // --- Survival Stats Decay ---
        if (frameCountRef.current % 10 === 0) {
            player.hunger = Math.max(0, player.hunger - HUNGER_DECAY);
            player.thirst = Math.max(0, player.thirst - THIRST_DECAY);
            if (player.hunger <= 0) player.health = Math.max(0, player.health - 0.02);
            if (player.thirst <= 0) player.health = Math.max(0, player.health - 0.03);
        }
        
        // Stamina
        if (isSprinting && player.isMoving) {
            player.stamina = Math.max(0, player.stamina - SPRINT_STAMINA_COST * dt);
        } else {
            player.stamina = Math.min(100, player.stamina + STAMINA_REGEN * dt);
        }

        // --- Building Logic ---
        const heldItem = player.inventory[player.selectedHotbarIndex];
        let isBuilding = false;
        
        if (heldItem?.type === ItemType.BUILDING_PLAN) {
            isBuilding = true;
            const worldMouseX = mousePosRef.current.x - (window.innerWidth / 2) + state.camera.x;
            const worldMouseY = mousePosRef.current.y - (window.innerHeight / 2) + state.camera.y;
            
            const selectedType = player.selectedBuildingType || EntityType.WOOD_FLOOR;
            let targetPos = { x: worldMouseX, y: worldMouseY };
            let snapped = false;
            let minDst = SNAP_THRESHOLD;

            // Simple Snap Logic
            const cx = Math.floor(targetPos.x / CHUNK_SIZE);
            const cy = Math.floor(targetPos.y / CHUNK_SIZE);
            for (let x = cx - 1; x <= cx + 1; x++) {
                for (let y = cy - 1; y <= cy + 1; y++) {
                    const entities = state.chunks[`${x},${y}`] || [];
                    for (const ent of entities) {
                        if (!ent.isBuilding) continue;
                        if (Math.abs(ent.pos.x - targetPos.x) > 200 || Math.abs(ent.pos.y - targetPos.y) > 200) continue;
                        
                        const size = 100; // Simplified snap size
                        const snapOffsets = [{x: size, y: 0}, {x: -size, y: 0}, {x: 0, y: size}, {x: 0, y: -size}];
                        
                        for (const offset of snapOffsets) {
                            const rx = offset.x * Math.cos(ent.rotation) - offset.y * Math.sin(ent.rotation);
                            const ry = offset.x * Math.sin(ent.rotation) + offset.y * Math.cos(ent.rotation);
                            const sx = ent.pos.x + rx;
                            const sy = ent.pos.y + ry;
                            const d = Math.sqrt((sx - targetPos.x)**2 + (sy - targetPos.y)**2);
                            if (d < minDst) {
                                minDst = d;
                                targetPos = { x: sx, y: sy };
                                snapped = true;
                            }
                        }
                    }
                }
            }

            const recipeKey = Object.keys(BUILDING_RECIPES).find(k => BUILDING_RECIPES[k].type === selectedType);
            const recipe = recipeKey ? BUILDING_RECIPES[recipeKey] : null;
            
            let isValid = true;
            if (recipe) {
                const hasMats = recipe.requirements.every(r => {
                    const count = player.inventory.reduce((acc, i) => (i?.type === r.type ? acc + i.count : acc), 0);
                    return count >= r.count;
                });
                if (!hasMats) isValid = false;
            }
            
            // Allow overlap if snapped (building chains), else check collision
            if (!snapped) {
                 if (!isPositionValid(targetPos, state.chunks, 40, true, undefined, true)) isValid = false;
            } else {
                 // Check exact duplicate
                 const cxSnap = Math.floor(targetPos.x / CHUNK_SIZE);
                 const cySnap = Math.floor(targetPos.y / CHUNK_SIZE);
                 const ents = state.chunks[`${cxSnap},${cySnap}`] || [];
                 const duplicate = ents.find(e => Math.abs(e.pos.x - targetPos.x) < 10 && Math.abs(e.pos.y - targetPos.y) < 10);
                 if (duplicate) isValid = false;
            }

            state.buildingPreview = {
                pos: targetPos,
                rotation: state.buildingRotation,
                type: selectedType,
                isValid
            };

            // PLACE
            if (isMouseDownRef.current && !state.uiOpen && isValid && (now - lastAttackTimeRef.current > 200)) {
                lastAttackTimeRef.current = now;
                if (recipe) {
                    const cxBuild = Math.floor(targetPos.x / CHUNK_SIZE);
                    const cyBuild = Math.floor(targetPos.y / CHUNK_SIZE);
                    const key = `${cxBuild},${cyBuild}`;
                    if (!state.chunks[key]) state.chunks[key] = [];
                    
                    const newBuilding: Entity = {
                        id: `build-${Date.now()}-${Math.random()}`,
                        type: selectedType,
                        pos: targetPos,
                        size: 100,
                        health: 100,
                        maxHealth: 500,
                        rotation: state.buildingRotation,
                        velocity: {x:0, y:0},
                        color: '#78350f',
                        isBuilding: true,
                        ownerId: player.playFabId
                    };
                    
                    let newInv = [...player.inventory];
                    recipe.requirements.forEach(req => {
                        let rem = req.count;
                        for(let i=0; i<newInv.length; i++) {
                            if(newInv[i]?.type === req.type) {
                                const take = Math.min(rem, newInv[i]!.count);
                                newInv[i] = { ...newInv[i]!, count: newInv[i]!.count - take };
                                if(newInv[i]!.count <= 0) newInv[i] = null;
                                rem -= take;
                                if(rem<=0) break;
                            }
                        }
                    });
                    player.inventory = newInv;
                    state.chunks[key].push(newBuilding);
                    saveBuildingToServer(state.currentServer || 1, newBuilding);
                    soundService.playHarvest('WOOD', targetPos, player.pos); 
                }
            }
        } else {
            state.buildingPreview = null;
        }

        // --- Crafting Queue Processing ---
        const queue = state.craftingQueue;
        if (queue.length > 0) {
            const active = queue[0];
            active.progress += 16.6 * dt; 
            if (active.progress >= active.duration) {
                const recipe = RECIPES.find(r => r.id === active.recipeId);
                if (recipe) {
                    state.player.inventory = addItemToInventory(state.player.inventory, recipe.output as ItemType, 1);
                    state.notifications = addNotification(state.notifications, recipe.output as ItemType, 1);
                    soundService.playHarvest('FIBER', player.pos, player.pos); 
                }
                state.craftingQueue.shift();
            }
        }

        // --- AI Update (Animals) ---
        // Optimization: Only update AI in nearby chunks
        const chunkX = Math.floor(newX / CHUNK_SIZE);
        const chunkY = Math.floor(newY / CHUNK_SIZE);
        
        for (let x = chunkX - 1; x <= chunkX + 1; x++) {
            for (let y = chunkY - 1; y <= chunkY + 1; y++) {
                const key = `${x},${y}`;
                const chunk = state.chunks[key];
                if (!chunk) continue; 

                for (let i = 0; i < chunk.length; i++) {
                    const ent = chunk[i];
                    
                    const idHash = ent.id.charCodeAt(ent.id.length - 1);
                    const shouldUpdateAI = (frameCountRef.current + idHash) % 10 === 0;

                    if (shouldUpdateAI && ent.aiState && ent.type !== EntityType.PLAYER) {
                        const distSq = (ent.pos.x - newX)**2 + (ent.pos.y - newY)**2;
                        const distToPlayer = Math.sqrt(distSq);
                        
                        let nextState = ent.aiState;
                        let moveX = 0, moveY = 0;
                        let speed = ANIMAL_SPEED_WANDER;

                        // State Transitions
                        const isAggressive = AGGRESSIVE_ANIMALS.has(ent.type);
                        if (isAggressive && distToPlayer < AGGRO_RANGE && player.health > 0) {
                            nextState = 'CHASE';
                        } else if (!isAggressive && distToPlayer < FLEE_RANGE) {
                            nextState = 'FLEE';
                        } else if (ent.aiTimer && ent.aiTimer > 0) {
                            // Keep state
                        } else {
                            nextState = Math.random() > 0.7 ? 'WANDER' : 'IDLE';
                        }

                        // Behavior
                        if (nextState === 'CHASE') {
                            speed = ANIMAL_SPEED_RUN;
                            const angle = Math.atan2(newY - ent.pos.y, newX - ent.pos.x);
                            moveX = Math.cos(angle) * speed * 10; 
                            moveY = Math.sin(angle) * speed * 10;
                            ent.rotation = angle;
                            if (distToPlayer < 25 && player.health > 0) {
                                player.health -= 0.05 * 10; 
                            }
                        } else if (nextState === 'FLEE') {
                            speed = ANIMAL_SPEED_RUN;
                            const angle = Math.atan2(ent.pos.y - newY, ent.pos.x - newX);
                            moveX = Math.cos(angle) * speed * 10;
                            moveY = Math.sin(angle) * speed * 10;
                            ent.rotation = angle;
                        } else if (nextState === 'WANDER') {
                            moveX = Math.cos(ent.rotation) * speed * 10;
                            moveY = Math.sin(ent.rotation) * speed * 10;
                            if (Math.random() < 0.2) { 
                                ent.rotation += (Math.random() - 0.5) * 2;
                            }
                        }

                        if ((ent.aiTimer || 0) <= 0) ent.aiTimer = 60 + Math.random() * 120;
                        else ent.aiTimer! -= 10;

                        if (nextState !== 'IDLE') {
                            ent.velocity = { x: moveX / 10, y: moveY / 10 };
                        } else {
                            ent.velocity = { x: 0, y: 0 };
                        }
                        ent.aiState = nextState;
                    }

                    if (ent.velocity && (ent.velocity.x !== 0 || ent.velocity.y !== 0)) {
                        let nextX = ent.pos.x + ent.velocity.x;
                        let nextY = ent.pos.y + ent.velocity.y;
                        
                        if (isPositionValid({x: nextX, y: ent.pos.y}, state.chunks, ent.size/2, true, ent.id)) {
                            ent.pos.x = nextX;
                        }
                        if (isPositionValid({x: ent.pos.x, y: nextY}, state.chunks, ent.size/2, true, ent.id)) {
                            ent.pos.y = nextY;
                        }
                    }
                }
            }
        }

        // --- Attack / Gather Logic ---
        if (isMouseDownRef.current && !state.uiOpen && !player.isSwinging && !isBuilding && (now - lastAttackTimeRef.current > 400)) {
            player.isSwinging = true;
            player.swingProgress = 0;
            lastAttackTimeRef.current = now;
            swingHitRegisteredRef.current = false;
        }

        if (player.isSwinging) {
            player.swingProgress += 0.1 * dt;
            if (player.swingProgress >= 0.4 && !swingHitRegisteredRef.current) {
                swingHitRegisteredRef.current = true;
                const heldItem = player.inventory[player.selectedHotbarIndex];
                
                const worldMouseX = mousePosRef.current.x - (window.innerWidth / 2) + state.camera.x;
                const worldMouseY = mousePosRef.current.y - (window.innerHeight / 2) + state.camera.y;
                
                let bestTarget: { ent: Entity, key: string, distToMouse: number } | null = null;

                for (let x = chunkX - 1; x <= chunkX + 1; x++) {
                    for (let y = chunkY - 1; y <= chunkY + 1; y++) {
                        const key = `${x},${y}`;
                        const chunk = state.chunks[key];
                        if (!chunk) continue;
                        
                        for (const ent of chunk) {
                            const dx = ent.pos.x - player.pos.x;
                            const dy = ent.pos.y - player.pos.y;
                            if (dx*dx + dy*dy < (HARVEST_RANGE + ent.size/2)**2) {
                                let hitY = ent.pos.y - worldMouseY;
                                if(ent.type === EntityType.TREE) hitY += 30;
                                const mDx = ent.pos.x - worldMouseX;
                                const distToMouse = Math.sqrt(mDx*mDx + hitY*hitY);
                                let hitRadius = (ent.size / 2) + 20; 
                                if (ent.type === EntityType.TREE) hitRadius = 45;

                                if (distToMouse < hitRadius) {
                                    if (!bestTarget || distToMouse < bestTarget.distToMouse) {
                                        bestTarget = { ent, key, distToMouse };
                                    }
                                }
                            }
                        }
                    }
                }

                if (bestTarget) {
                    const { ent, key } = bestTarget;
                    let damage = 10;
                    let gatherAmount = 1;
                    let resourceType: ItemType | null = null;
                    if (heldItem && ITEM_DATA[heldItem.type].damage) damage = ITEM_DATA[heldItem.type].damage!;

                    if (ent.type === EntityType.TREE) {
                        resourceType = ItemType.WOOD;
                        gatherAmount = heldItem?.type === ItemType.AXE || heldItem?.type === ItemType.IRON_AXE ? 15 : 5;
                        soundService.playHarvest('WOOD', ent.pos, player.pos);
                    } else if (ent.type.includes('NODE') || ent.type === EntityType.ROCK) {
                        if (ent.type.includes('SULFUR')) resourceType = ItemType.SULFUR_ORE;
                        else if (ent.type.includes('METAL')) resourceType = ItemType.METAL_ORE;
                        else resourceType = ItemType.STONE;
                        gatherAmount = heldItem?.type === ItemType.PICKAXE || heldItem?.type === ItemType.IRON_PICKAXE ? 15 : 5;
                        soundService.playHarvest('STONE', ent.pos, player.pos);
                    } else if (COLLECTIBLE_DATA[ent.type]) {
                        damage = 999;
                        const data = COLLECTIBLE_DATA[ent.type];
                        player.inventory = addItemToInventory(player.inventory, data.item, data.count);
                        state.notifications = addNotification(state.notifications, data.item, data.count);
                        soundService.playHarvest('FIBER', ent.pos, player.pos);
                    } else {
                        soundService.playHarvest('FIBER', ent.pos, player.pos);
                    }

                    if (resourceType) {
                        player.inventory = addItemToInventory(player.inventory, resourceType, gatherAmount);
                        state.notifications = addNotification(state.notifications, resourceType, gatherAmount);
                        
                        if (!state.settings.lowPerformance) {
                            spawnParticle(ent.pos.x, ent.pos.y, '#fff', 'spark', 2);
                        }
                    }

                    ent.health -= damage;
                    ent.hitReaction = 5;
                    ent.lastAttackerPos = {x: player.pos.x, y: player.pos.y};
                    if (ent.aiState !== undefined) {
                        ent.aiState = AGGRESSIVE_ANIMALS.has(ent.type) || ent.type === EntityType.BOAR ? 'CHASE' : 'FLEE';
                    }

                    if (ent.health <= 0) {
                        const chunk = state.chunks[key];
                        const idx = chunk.indexOf(ent);
                        if (idx > -1) chunk.splice(idx, 1);
                    }
                }
            }
            if (player.swingProgress >= 1) {
                player.isSwinging = false;
                player.swingProgress = 0;
            }
        }

        updateParticles();

        state.dayTime = (state.dayTime + dt) % 24000;

        if (now - lastUiUpdateRef.current > 50 || state.uiOpen) {
            syncUiState();
            lastUiUpdateRef.current = now;
        }

        rafId = requestAnimationFrame(loop);
    };

    rafId = requestAnimationFrame(loop);

    return () => {
        cancelAnimationFrame(rafId);
        window.removeEventListener('keydown', handleKeyDown);
        window.removeEventListener('keyup', handleKeyUp);
        window.removeEventListener('mousedown', handleMouseDown);
        window.removeEventListener('mouseup', handleMouseUp);
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('blur', handleBlur);
        window.removeEventListener('contextmenu', handleContextMenu);
    };
  }, [view, isLoading, manageChunks]);

  const handleCraftStart = (recipeId: string) => {
      const state = gameStateRef.current;
      const recipe = RECIPES.find(r => r.id === recipeId);
      if (!recipe) return;

      const inventoryCounts = state.player.inventory.reduce((acc, it) => { 
          if(it) acc[it.type] = (acc[it.type] || 0) + it.count; 
          return acc; 
      }, {} as Record<ItemType, number>);

      const canCraft = recipe.requirements.every(r => (inventoryCounts[r.type] || 0) >= r.count);
      if (!canCraft) return;

      let newInv = [...state.player.inventory];
      recipe.requirements.forEach(req => {
          let remaining = req.count;
          for(let i=0; i<newInv.length; i++) {
              if (newInv[i] && newInv[i]!.type === req.type) {
                  const take = Math.min(remaining, newInv[i]!.count);
                  newInv[i] = { ...newInv[i]!, count: newInv[i]!.count - take };
                  remaining -= take;
                  if (newInv[i]!.count <= 0) newInv[i] = null;
                  if (remaining <= 0) break;
              }
          }
      });
      state.player.inventory = newInv;

      state.craftingQueue.push({
          recipeId: recipe.id,
          progress: 0,
          startTime: Date.now(),
          duration: 1000
      });
      syncUiState();
  };

  const handleUseItem = (itemId: string) => {
      const prev = gameStateRef.current;
      const inv = [...prev.player.inventory];
      const itemIdx = inv.findIndex(i => i?.id === itemId);
      if (itemIdx === -1) return;
      
      const item = inv[itemIdx];
      if (!item) return;
      
      const data = ITEM_DATA[item.type];
      let consumed = false;
      let newPlayer = { ...prev.player };

      if (data && data.restore) {
          if (data.restore.health) newPlayer.health = Math.min(100, newPlayer.health + data.restore.health);
          if (data.restore.hunger) newPlayer.hunger = Math.min(100, newPlayer.hunger + data.restore.hunger);
          if (data.restore.thirst) newPlayer.thirst = Math.min(100, newPlayer.thirst + data.restore.thirst);
          consumed = true;
      }

      if (consumed) {
          if (item.count > 1) {
              inv[itemIdx] = { ...item, count: item.count - 1 };
          } else {
              inv[itemIdx] = null;
          }
      }

      gameStateRef.current.player = { ...newPlayer, inventory: inv };
      syncUiState();
  };

  const handleOpenUI = () => {
      gameStateRef.current.uiOpen = 'inv';
      syncUiState();
  };

  const handleCloseUI = () => {
      if(authState.user) updatePlayerState(String(authState.user.playFabId), gameStateRef.current.player, gameStateRef.current.currentServer || 1, buildingPreviewRef.current);
      gameStateRef.current.uiOpen = null;
      gameStateRef.current.openedContainerId = null;
      syncUiState();
  };

  const handleSelectBuilding = (type: EntityType) => {
      gameStateRef.current.player.selectedBuildingType = type;
      gameStateRef.current.uiOpen = null;
      syncUiState();
  };

  const handleRespawn = (pos?: Vector2) => {
      const spawnPos = pos || findSpawnPosition();
      gameStateRef.current.player.health = 100;
      gameStateRef.current.player.hunger = 100;
      gameStateRef.current.player.thirst = 100;
      gameStateRef.current.player.stamina = 100;
      gameStateRef.current.player.pos = spawnPos;
      gameStateRef.current.player.isSleeping = false;
      gameStateRef.current.player.damageFlash = 0;
      gameStateRef.current.uiOpen = null;
      syncUiState();
  };

  return (
    <div className="w-full h-screen bg-[#0c0a09] relative overflow-hidden">
      {isLoading && view === 'game' && <LoadingScreen progress={loadingProgress} text={loadingText} />}
      {view === 'landing' && (
        <LandingPage 
            isAuthenticated={!!authState.user} 
            username={authState.user?.displayName || null} 
            onPlay={() => navigateTo('lobby')} 
            onOpenAuth={(mode) => setAuthState({...authState, show: true, mode})}
            settings={uiState.settings}
            onUpdateSettings={updateSettings}
        />
      )}
      {view === 'lobby' && authState.user && <Lobby userId={authState.user.playFabId} username={authState.user.displayName || 'Survivor'} onPlay={() => navigateTo('game')} onOpenSettings={() => { gameStateRef.current.uiOpen = 'settings'; syncUiState(); }} onServerSelect={(id) => { gameStateRef.current.currentServer = id; syncUiState(); }} />}
      {view === 'game' && !isLoading && (
        <>
          <GameCanvas gameStateRef={gameStateRef} userHandle={authState.user?.displayName || 'Survivor'} remotePlayersRef={remotePlayersListRef} />
          <PostProcessing vignetteStrength={uiState.settings.vignetteStrength} scanlinesEnabled={uiState.settings.scanlinesEnabled} ultraMode={uiState.settings.ultraMode} lowPerformance={uiState.settings.lowPerformance} />
          <UIOverlay 
            gameState={uiState} 
            remotePlayers={remotePlayersUI} 
            serverPop={remotePlayersUI.length+1} 
            onActionTrigger={()=>{}} 
            onCraftStart={handleCraftStart}
            onCraftStop={() => {}}
            onRepair={() => {}}
            onUseItem={handleUseItem}
            onDropItem={(idx) => { /* logic */ }}
            onToggleSlot={() => {}}
            onMoveItem={() => { /* logic */ }}
            onSortInventory={() => {}}
            onUpdateSettings={updateSettings}
            onInspectItem={(id) => { gameStateRef.current.uiOpen = 'inspect'; gameStateRef.current.inspectingItemId = id; syncUiState(); }} 
            onCloseUI={handleCloseUI}
            onOpenUI={handleOpenUI}
            onOpenSettings={() => { gameStateRef.current.uiOpen = 'settings'; syncUiState(); }} 
            onSelectBuilding={handleSelectBuilding}
            onLeaveServer={async ()=>{ if (authState.user) { await updatePlayerState(String(authState.user.playFabId), playerRef.current, gameStateRef.current.currentServer || 1, buildingPreviewRef.current); } navigateTo('landing'); }} 
            onRespawn={handleRespawn}
            onConsoleCommand={() => { /* logic */ }}
            onMoveToContainer={() => { /* logic */ }}
            onTakeFromContainer={() => { /* logic */ }}
          />
          {uiState.mapOpen && <MapOverlay playerPos={uiState.player.pos} teammates={remotePlayersUI.filter(rp => uiState.team.includes(rp.id))} visitedChunks={uiState.player.visitedChunks} onClose={() => { gameStateRef.current.mapOpen = false; syncUiState(); }} chunks={uiState.chunks} />}
        </>
      )}
      {authState.show && <AuthForm initialMode={authState.mode} onSuccess={(u)=>{setAuthState({...authState,user:u,show:false});navigateTo('lobby');}} onClose={()=>setAuthState({...authState,show:false})} />}
    </div>
  );
};
export default App;
