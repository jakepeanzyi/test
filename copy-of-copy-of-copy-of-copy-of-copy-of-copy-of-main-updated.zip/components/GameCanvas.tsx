
import React, { useRef, useEffect, useMemo } from 'react';
import { GameState, EntityType, ItemType, Entity, Vector2, Player, InventoryItem, WeatherType, GameSettings } from '../types';
import { CHUNK_SIZE, VIEW_RADIUS, ITEM_DATA, LOOT_CONTAINER_DATA } from '../constants';
import { getBiomeAt } from '../engine/WorldGenerator';

import { drawPlayer } from '../models/Player';
import { drawAnimal } from '../models/Animals';
import { drawTree } from '../models/Tree';
import { drawBush } from '../models/Bush';
import { drawRock } from '../models/Rock';
import { drawOreNode } from '../models/Ores';
import { drawScrap } from '../models/Scrap';
import { drawBuilding } from '../models/Building';
import { drawItemDrop } from '../models/ItemDrop';
import { drawProjectile } from '../models/Projectile';
import { drawPlant } from '../models/Plant';
import { drawParticle } from '../models/Particle';
import { drawBarrel } from '../models/Barrel';
import { drawLootContainer } from '../models/LootContainer';
import { drawCollectible } from '../models/Collectibles';
import { drawVehicle } from '../models/Vehicles';
import { drawNPC } from '../models/NPCs';
import { drawMachine } from '../models/Machines';

interface Props {
  gameStateRef: React.MutableRefObject<GameState>;
  userHandle: string | null;
  remotePlayersRef?: React.MutableRefObject<Player[]>;
}

const VISION_RADIUS_TORCH = 480;
const VISION_RADIUS_FIREPIT = 420;
const VISION_RADIUS_BASE = 150;

const drawHealthBar = (ctx: CanvasRenderingContext2D, health: number, maxHealth: number, size: number, type: EntityType) => {
  const max = maxHealth || 100;
  if (health >= max) return; 
  
  let yOffset = 0;
  let barWidth = 30;
  
  if (type === EntityType.TREE) { yOffset = -15; barWidth = 24; }
  else if (type === EntityType.STONE_ORE_NODE || type === EntityType.METAL_ORE_NODE || type === EntityType.SULFUR_ORE_NODE) { yOffset = -10; barWidth = 30; }
  else if (type === EntityType.PLAYER) { yOffset = -25; barWidth = 24; }
  else if ([EntityType.WOLF, EntityType.BEAR, EntityType.BOAR, EntityType.POLAR_BEAR, EntityType.PANTHER, EntityType.SHARK, EntityType.CROCODILE, EntityType.HORSE, EntityType.STAG].includes(type)) { yOffset = -20; barWidth = 24; }
  else if (type === EntityType.WALL || type === EntityType.STONE_WALL || type === EntityType.METAL_WALL) { yOffset = -25; barWidth = 40; }
  else { yOffset = -size * 0.8; barWidth = 30; }

  const height = 4;
  const x = -barWidth / 2;
  const y = yOffset;

  ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
  ctx.fillRect(x, y, barWidth, height);
  
  const healthPercent = Math.max(0, health / max);
  ctx.fillStyle = healthPercent > 0.5 ? '#22c55e' : (healthPercent > 0.25 ? '#f59e0b' : '#ef4444');
  ctx.fillRect(x + 1, y + 1, (barWidth - 2) * healthPercent, height - 2);
};

const drawNameTag = (ctx: CanvasRenderingContext2D, name: string, size: number, yOffset: number, color: string = 'white') => {
  ctx.font = 'bold 10px Courier Prime, monospace';
  ctx.textAlign = 'center';
  ctx.fillStyle = 'rgba(0,0,0,0.4)';
  const metrics = ctx.measureText(name);
  ctx.fillRect(-metrics.width/2 - 4, -size - yOffset - 12, metrics.width + 8, 14);
  ctx.fillStyle = color;
  ctx.fillText(name, 0, -size - yOffset - 2);
};

const drawCrosshair = (ctx: CanvasRenderingContext2D, x: number, y: number, style: 'dot' | 'cross' | 'circle' = 'circle') => {
  ctx.save();
  ctx.translate(x, y);
  ctx.shadowColor = 'black';
  ctx.shadowBlur = 2;
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
  ctx.lineWidth = 2;
  if (style === 'circle') {
      ctx.beginPath(); ctx.arc(0, 0, 6, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = 'rgba(255, 255, 255, 0.9)'; ctx.beginPath(); ctx.arc(0, 0, 1.5, 0, Math.PI * 2); ctx.fill();
  } else if (style === 'cross') {
      ctx.beginPath(); ctx.moveTo(-6, 0); ctx.lineTo(6, 0); ctx.moveTo(0, -6); ctx.lineTo(0, 6); ctx.stroke();
  } else {
      ctx.fillStyle = 'rgba(255, 255, 255, 0.9)'; ctx.beginPath(); ctx.arc(0, 0, 3, 0, Math.PI * 2); ctx.fill();
  }
  ctx.restore();
};

const drawSimpleShadow = (ctx: CanvasRenderingContext2D, ent: Entity) => {
    ctx.fillStyle = 'rgba(0,0,0,0.2)';
    ctx.beginPath();
    ctx.ellipse(0, 0, ent.size / 2, ent.size / 4, 0, 0, Math.PI * 2);
    ctx.fill();
};

const GameCanvas: React.FC<Props> = ({ gameStateRef, userHandle, remotePlayersRef }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const maskCanvasRef = useRef<HTMLCanvasElement>(null);
  const mousePosRef = useRef({ x: window.innerWidth/2, y: window.innerHeight/2 });
  const rainDropsRef = useRef<{x: number, y: number, len: number, speed: number}[]>([]);
  
  const fogParticles = useMemo(() => {
    const p = [];
    for (let i = 0; i < 40; i++) {
      p.push({
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        size: 150 + Math.random() * 200,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.3,
        offset: Math.random() * Math.PI * 2
      });
    }
    return p;
  }, []);

  const getLightingState = (dayTime: number) => {
    let darkness = 0;
    if (dayTime < 4000) darkness = 1.0 - (dayTime / 4000);
    else if (dayTime > 16000 && dayTime < 20000) darkness = (dayTime - 16000) / 4000;
    else if (dayTime >= 20000) darkness = 1.0;
    let sunX = 0, sunY = 0;
    if (dayTime >= 4000 && dayTime <= 20000) {
        const dayProgress = (dayTime - 4000) / 16000;
        const angle = dayProgress * Math.PI;
        sunX = Math.cos(angle); sunY = -Math.sin(angle);
    }
    return { darknessAlpha: Math.max(0, Math.min(0.95, darkness)), sunX, sunY, dayTime };
  };

  useEffect(() => {
    const handleMove = (e: MouseEvent) => { mousePosRef.current = { x: e.clientX, y: e.clientY }; };
    window.addEventListener('mousemove', handleMove);
    return () => window.removeEventListener('mousemove', handleMove);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: false }); if (!ctx) return; 
    if (!maskCanvasRef.current) maskCanvasRef.current = document.createElement('canvas');
    const mCanvas = maskCanvasRef.current;
    
    if (rainDropsRef.current.length === 0) {
        for(let i=0; i<100; i++) {
            rainDropsRef.current.push({ x: Math.random() * window.innerWidth, y: Math.random() * window.innerHeight, len: 10 + Math.random() * 10, speed: 8 + Math.random() * 5 });
        }
    }
    
    const resize = () => { 
      canvas.width = window.innerWidth; 
      canvas.height = window.innerHeight; 
      const scale = gameStateRef.current.settings.lowPerformance ? 0.5 : 1;
      mCanvas.width = window.innerWidth * scale; 
      mCanvas.height = window.innerHeight * scale;
    };
    resize();
    window.addEventListener('resize', resize);
    
    const render = (time: number) => {
      const state = gameStateRef.current;
      const remotePlayers = remotePlayersRef?.current || [];
      const { player, chunks, projectiles, particles, footprints, camera, dayTime, settings, uiOpen, buildingPreview, team, weather, terrainCache } = state;
      const { darknessAlpha, sunX, sunY } = getLightingState(dayTime);
      const ox = canvas.width / 2 - camera.x, oy = canvas.height / 2 - camera.y;
      const equippedItem = player.inventory[player.selectedHotbarIndex];
      const isHoldingHammer = equippedItem?.type === ItemType.HAMMER;
      const isHoldingTorch = equippedItem?.type === ItemType.TORCH;
      
      // Clear
      ctx.fillStyle = '#0c0a09';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.imageSmoothingEnabled = false;

      // --- TERRAIN ---
      const renderRadius = (settings.renderDistance || 2);
      const loadRadius = renderRadius + 1; 
      const cx = Math.floor(player.pos.x / CHUNK_SIZE);
      const cy = Math.floor(player.pos.y / CHUNK_SIZE);

      for (let x = cx - loadRadius; x <= cx + loadRadius; x++) {
          for (let y = cy - loadRadius; y <= cy + loadRadius; y++) {
              const key = `${x},${y}`;
              const terrain = terrainCache[key];
              if (terrain) {
                  const drawX = Math.floor(x * CHUNK_SIZE + ox);
                  const drawY = Math.floor(y * CHUNK_SIZE + oy);
                  if (drawX + CHUNK_SIZE > 0 && drawX < canvas.width && drawY + CHUNK_SIZE > 0 && drawY < canvas.height) {
                      ctx.drawImage(terrain, drawX, drawY);
                  }
              }
          }
      }

      // --- ENTITIES SETUP ---
      const floors: Entity[] = [];
      const objects: Entity[] = [];
      
      for (let x = cx - renderRadius; x <= cx + renderRadius; x++) {
        for (let y = cy - renderRadius; y <= cy + renderRadius; y++) {
          const key = `${x},${y}`;
          if (chunks[key]) chunks[key].forEach(ent => {
             const sx = ent.pos.x + ox, sy = ent.pos.y + oy;
             if (sx > -200 && sx < canvas.width + 200 && sy > -200 && sy < canvas.height + 200) {
                 const isFloor = [
                   EntityType.WOOD_FLOOR, EntityType.STONE_FLOOR, EntityType.METAL_FLOOR, EntityType.HQ_FLOOR,
                   EntityType.TRIANGLE_FLOOR, EntityType.TRIANGLE_STONE_FLOOR, EntityType.TRIANGLE_METAL_FLOOR, EntityType.TRIANGLE_HQ_FLOOR,
                   EntityType.FOUNDATION, EntityType.STONE_FOUNDATION, EntityType.METAL_FOUNDATION, EntityType.HQ_FOUNDATION,
                   EntityType.TRIANGLE_FOUNDATION, EntityType.TRIANGLE_STONE_FOUNDATION, EntityType.TRIANGLE_METAL_FOUNDATION, EntityType.TRIANGLE_HQ_FOUNDATION
                 ].includes(ent.type);
                 if (isFloor) floors.push(ent);
                 else objects.push(ent);
             }
          });
        }
      }

      // --- [LOW PERF OPTIMIZATION] SKIP FOOTPRINTS ---
      if (!settings.lowPerformance) {
          footprints.forEach(fp => {
              const fx = fp.x + ox, fy = fp.y + oy;
              if (fx > 0 && fx < canvas.width && fy > 0 && fy < canvas.height) {
                  ctx.save();
                  ctx.translate(fx, fy);
                  ctx.rotate(fp.rotation);
                  ctx.globalAlpha = fp.age * 0.5;
                  ctx.fillStyle = fp.color;
                  ctx.fillRect(-2, -4, 4, 8);
                  ctx.restore();
              }
          });
      }

      // Floors
      floors.forEach(ent => {
        const sx = Math.floor(ent.pos.x + ox), sy = Math.floor(ent.pos.y + oy);
        ctx.save(); ctx.translate(sx, sy);
        drawBuilding(ctx, ent, settings, time);
        ctx.restore();
      });

      // Objects
      const sortedObjects = [...objects, ...(projectiles || [])].sort((a, b) => (a.pos.y + a.size) - (b.pos.y + b.size));

      // --- [ULTRA] REFLECTIONS ---
      if (settings.ultraMode) {
          ctx.save();
          sortedObjects.forEach(ent => {
              // Simple biome check for water based on cached biome if available, or just recalculate (expensive but its Ultra)
              // To optimize, we check logic: Reflections only in LAKES or OCEAN edges
              const isReflective = getBiomeAt(ent.pos) === 'LAKE'; 
              
              if (isReflective) {
                  const sx = ent.pos.x + ox, sy = ent.pos.y + oy;
                  ctx.save();
                  ctx.translate(sx, sy + ent.size/3);
                  ctx.scale(1, -0.6); // Invert and squash
                  ctx.globalAlpha = 0.2;
                  // Draw simplified shape as reflection
                  ctx.fillStyle = ent.color;
                  ctx.beginPath(); ctx.arc(0,0, ent.size/2, 0, Math.PI*2); ctx.fill();
                  ctx.restore();
              }
          });
          ctx.restore();
      }

      // --- SHADOWS ---
      if (settings.shadowsEnabled) {
          ctx.save();
          const shadowLength = Math.max(0.2, Math.min(3, 1 / Math.abs(sunY + 0.1)));
          const skewX = sunX * shadowLength * -1, scaleY = 0.6;
          
          // [LOW PERF] - Force simple shadows
          // [ULTRA] - Detailed skew shadows for everything
          const useDetailedShadows = !settings.lowPerformance && settings.ultraMode && dayTime > 4000 && dayTime < 20000;

          const drawEntityShadow = (ent: Entity | Player) => {
              if (useDetailedShadows) {
                  ctx.save(); 
                  ctx.translate(ent.pos.x + ox, ent.pos.y + oy); 
                  ctx.transform(1, 0, skewX, scaleY, 0, 0);
                  
                  if (ent.type === EntityType.PLAYER) drawPlayer(ctx, ent as Player, settings, time, true);
                  else if (LOOT_CONTAINER_DATA[ent.type]) drawLootContainer(ctx, ent, settings, time, true);
                  else if (ent.type.includes('NODE')) drawOreNode(ctx, ent, settings, true);
                  else if (ent.type === EntityType.TREE) drawTree(ctx, ent, settings, time, true);
                  else if (ent.type === EntityType.BUSH) drawBush(ctx, ent, settings, time, true);
                  else drawSimpleShadow(ctx, ent);
                  
                  ctx.restore();
              } else {
                  ctx.save(); ctx.translate(ent.pos.x + ox, ent.pos.y + oy);
                  drawSimpleShadow(ctx, ent);
                  ctx.restore();
              }
          };

          [player, ...remotePlayers].forEach(p => drawEntityShadow(p));
          sortedObjects.forEach(ent => {
              if (ent.type === EntityType.ITEM_DROP || ent.type === EntityType.PROJECTILE) return;
              drawEntityShadow(ent);
          });
          
          ctx.restore();
      }

      // --- MAIN DRAW LOOP ---
      sortedObjects.forEach(ent => {
        const sx = Math.floor(ent.pos.x + ox), sy = Math.floor(ent.pos.y + oy);
        ctx.save(); ctx.translate(sx, sy);
        
        // [ULTRA] Ambient Occlusion
        if (settings.ultraMode && (ent.type === EntityType.TREE || ent.type === EntityType.ROCK || ent.isBuilding)) {
            const aoGrad = ctx.createRadialGradient(0, 0, ent.size/3, 0, 0, ent.size);
            aoGrad.addColorStop(0, 'rgba(0,0,0,0.4)');
            aoGrad.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.fillStyle = aoGrad;
            ctx.beginPath(); ctx.scale(1, 0.5); ctx.arc(0,0, ent.size, 0, Math.PI*2); ctx.fill();
            ctx.scale(1, 2); // Reset scale
        }

        if ((ent.type === EntityType.ITEM_DROP || ent.type === EntityType.BODY_BAG) && !settings.disableAnimations) { 
            const popScale = 0.85 + Math.abs(Math.sin(time / 250) * 0.1); 
            ctx.scale(popScale, popScale); 
        }
        
        // Draw Logic
        if (LOOT_CONTAINER_DATA[ent.type] || ent.type === EntityType.LOOT_CRATE) {
            drawLootContainer(ctx, ent, settings, time);
        } else if ([EntityType.STONE_ORE_NODE, EntityType.METAL_ORE_NODE, EntityType.SULFUR_ORE_NODE].includes(ent.type)) {
            drawOreNode(ctx, ent, settings);
        } else if ([EntityType.MUSHROOM, EntityType.SCATTERED_STONE_ROCK, EntityType.SCATTERED_METAL_ROCK, EntityType.SCATTERED_SULFUR_ROCK, EntityType.STUMP, EntityType.DIESEL_BARREL].includes(ent.type)) {
            drawCollectible(ctx, ent, settings, time);
        } else if ([EntityType.WOLF, EntityType.BEAR, EntityType.BOAR, EntityType.CHICKEN, EntityType.STAG, EntityType.HORSE, EntityType.PANTHER, EntityType.POLAR_BEAR, EntityType.SHARK, EntityType.CROCODILE, EntityType.SNAKE].includes(ent.type)) {
            drawAnimal(ctx, ent, settings, time);
        } else if (ent.type.includes('SCIENTIST') || ent.type.includes('GUARD') || ent.type === EntityType.HUNTER || ent.type === EntityType.LUMBERJACK || ent.type === EntityType.TUNNEL_DWELLER || ent.type === EntityType.MINER || ent.type === EntityType.STABLEHAND || ent.type === EntityType.UNDERWATER_DWELLER || ent.type === EntityType.VAGABOND || ent.type === EntityType.NEWMAN) {
            drawNPC(ctx, ent, settings, time);
        } else if (ent.type.includes('VEHICLE') || ent.type.includes('HELICOPTER') || ent.type.includes('BOAT') || ent.type.includes('SUBMARINE') || ent.type === EntityType.MINICOPTER || ent.type === EntityType.BIKE || ent.type === EntityType.MOTORBIKE || ent.type === EntityType.SIDECAR_MOTORBIKE || ent.type === EntityType.TRIKE || ent.type === EntityType.SNOWMOBILE || ent.type === EntityType.TUGBOAT || ent.type === EntityType.RHIB || ent.type === EntityType.BRADLEY_APC || ent.type === EntityType.SCRAPPED_PICKUP_TRUCK || ent.type === EntityType.HOT_AIR_BALLOON || ent.type === EntityType.MAGNET_CRANE) {
            drawVehicle(ctx, ent, settings, time);
        } else if ([EntityType.RECYCLER, EntityType.GIANT_EXCAVATOR, EntityType.MLRS, EntityType.MONUMENT_SAM_SITE, EntityType.SAFE_ZONE_RECYCLER, EntityType.SHREDDER, EntityType.OUTPOST_SENTRY, EntityType.CZ_721].includes(ent.type)) {
            drawMachine(ctx, ent, settings, time);
        } else {
            switch (ent.type) {
              case EntityType.TREE: drawTree(ctx, ent, settings, time); break;
              case EntityType.BUSH: drawBush(ctx, ent, settings, time); break;
              case EntityType.ROCK: drawRock(ctx, ent, settings); break;
              case EntityType.SCRAP: drawScrap(ctx, ent, settings); break;
              case EntityType.BARREL: drawBarrel(ctx, ent, settings, time); break;
              case EntityType.ITEM_DROP: drawItemDrop(ctx, ent, settings, time); break;
              case EntityType.PROJECTILE: drawProjectile(ctx, { ...ent, pos: {x:0,y:0} } as any, settings, time); break;
              case EntityType.PLANT_HEMP: 
              case EntityType.PLANT_BERRY: 
              case EntityType.PLANT_PUMPKIN:
              case EntityType.BLUE_BERRY_BUSH:
              case EntityType.GREEN_BERRY_BUSH:
              case EntityType.RED_BERRY_BUSH:
              case EntityType.WHITE_BERRY_BUSH:
              case EntityType.YELLOW_BERRY_BUSH:
              case EntityType.HEMP_FIBERS:
              case EntityType.WILD_CORN_PLANT:
              case EntityType.WILD_POTATO_PLANT:
              case EntityType.WILD_PUMPKIN_PLANT:
              case EntityType.WILD_WHEAT:
              case EntityType.WILD_ROSE:
              case EntityType.WILD_SUNFLOWER:
              case EntityType.WILD_ORCHID:
                  drawPlant(ctx, ent, settings, time); 
                  break;
              default: drawBuilding(ctx, ent, settings, time); break;
            }
        }
        if (isHoldingHammer && ent.isBuilding) {
            const healthPct = ent.health / (ent.maxHealth || 100);
            ctx.fillStyle = healthPct > 0.5 ? 'rgba(0,255,0,0.2)' : (healthPct > 0.2 ? 'rgba(255,165,0,0.3)' : 'rgba(255,0,0,0.4)');
            ctx.beginPath(); ctx.arc(0, 0, ent.size / 2, 0, Math.PI*2); ctx.fill();
        }
        if (ent.type !== EntityType.PROJECTILE && ent.type !== EntityType.ITEM_DROP) drawHealthBar(ctx, ent.health, ent.maxHealth, ent.size, ent.type);
        ctx.restore();
      });

      if (!settings.lowPerformance) {
          particles.forEach(p => { 
              const px = p.x + ox, py = p.y + oy;
              if(px > 0 && px < canvas.width && py > 0 && py < canvas.height) {
                  ctx.save(); ctx.translate(px, py); drawParticle(ctx, p); ctx.restore(); 
              }
          });
      }

      ctx.save(); ctx.translate(player.pos.x + ox, player.pos.y + oy);
      drawPlayer(ctx, player, settings, time);
      if (!settings.streamerMode) drawNameTag(ctx, userHandle || 'Survivor', player.size, 10, '#38bdf8');
      ctx.restore();

      remotePlayers.forEach(op => {
         if (op.isOffline || op.health <= 0) return;
         const sx = op.pos.x + ox, sy = op.pos.y + oy;
         if (sx < -50 || sx > canvas.width + 50 || sy < -50 || sy > canvas.height + 50) return;
         ctx.save(); ctx.translate(sx, sy);
         drawPlayer(ctx, op, settings, time);
         if (settings.showNames && !settings.streamerMode) { const isTeammate = team.includes(op.id); drawNameTag(ctx, op.id, op.size, 15, isTeammate ? '#4ade80' : '#f87171'); }
         ctx.restore();
      });

      if (buildingPreview && equippedItem?.type === ItemType.BUILDING_PLAN && !uiOpen) {
          ctx.save(); ctx.translate(buildingPreview.pos.x + ox, buildingPreview.pos.y + oy);
          drawBuilding(ctx, { type: buildingPreview.type, rotation: buildingPreview.rotation, size: 100, pos: buildingPreview.pos } as any, settings, time, true);
          ctx.restore();
      }

      // --- [LOW PERF OPTIMIZATION] SKIP WEATHER ---
      const baseFogDensity = (weather === WeatherType.FOG ? 1.0 : (weather === WeatherType.RAIN ? 0.3 : 0.05));
      const nightDensityMult = 1.0 + darknessAlpha * 1.5;
      const finalFogDensity = baseFogDensity * nightDensityMult;

      if (!settings.lowPerformance) {
          if (finalFogDensity > 0.01 && !settings.disableAnimations) {
              ctx.save();
              fogParticles.forEach(p => {
                  p.x += p.vx; p.y += p.vy;
                  if (p.x < -p.size) p.x = canvas.width + p.size;
                  if (p.x > canvas.width + p.size) p.x = -p.size;
                  if (p.y < -p.size) p.y = canvas.height + p.size;
                  if (p.y > canvas.height + p.size) p.y = -p.size;
                  
                  const pulse = Math.sin(time/2000 + p.offset) * 0.1 + 0.9;
                  const grad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size * pulse);
                  const color = `rgba(200, 210, 220, ${finalFogDensity * 0.12})`;
                  grad.addColorStop(0, color);
                  grad.addColorStop(1, 'rgba(200, 210, 220, 0)');
                  ctx.fillStyle = grad;
                  ctx.beginPath();
                  ctx.arc(p.x, p.y, p.size * pulse, 0, Math.PI * 2);
                  ctx.fill();
              });
              ctx.restore();
          }

          if (weather === WeatherType.FOG) { ctx.fillStyle = `rgba(200, 210, 220, ${0.1 * nightDensityMult})`; ctx.fillRect(0,0,canvas.width, canvas.height); }
          else if (weather === WeatherType.RAIN) {
              ctx.fillStyle = 'rgba(0, 0, 20, 0.15)'; ctx.fillRect(0,0,canvas.width, canvas.height);
              if (!settings.disableAnimations) {
                  ctx.strokeStyle = 'rgba(180, 200, 255, 0.3)'; ctx.lineWidth = 1;
                  rainDropsRef.current.forEach(drop => {
                      drop.y += drop.speed; drop.x -= 1;
                      if (drop.y > canvas.height) { drop.y = -drop.len; drop.x = Math.random() * canvas.width; }
                      ctx.beginPath(); ctx.moveTo(drop.x, drop.y); ctx.lineTo(drop.x - 3, drop.y + drop.len); ctx.stroke();
                  });
              }
          }
      }

      // --- [ULTRA] SUN SHAFTS ---
      if (settings.ultraMode && dayTime > 6000 && dayTime < 18000) {
          const sunScreenX = canvas.width/2 + sunX * 400;
          const sunScreenY = canvas.height/2 + sunY * 400;
          
          const grad = ctx.createRadialGradient(sunScreenX, sunScreenY, 20, sunScreenX, sunScreenY, 800);
          grad.addColorStop(0, 'rgba(255, 250, 200, 0.1)');
          grad.addColorStop(1, 'rgba(255, 250, 200, 0)');
          ctx.fillStyle = grad;
          ctx.globalCompositeOperation = 'screen';
          ctx.fillRect(0,0,canvas.width, canvas.height);
          ctx.globalCompositeOperation = 'source-over';
      }

      if (darknessAlpha > 0.05) {
          const mCtx = mCanvas.getContext('2d');
          if (mCtx) {
              const scaleFactor = settings.lowPerformance ? 0.5 : 1;
              mCtx.clearRect(0, 0, mCanvas.width, mCanvas.height);
              mCtx.fillStyle = `rgba(0,0,0,${darknessAlpha * 0.95})`; 
              mCtx.fillRect(0, 0, mCanvas.width, mCanvas.height);
              
              mCtx.globalCompositeOperation = 'destination-out';
              const drawLight = (p: Player | Entity, isSelf: boolean = false) => {
                  const hasTorch = isSelf ? isHoldingTorch : (p as Player).equipped === ItemType.TORCH;
                  const pos = p.pos;
                  const px = (pos.x + ox) * scaleFactor, py = (pos.y + oy) * scaleFactor;
                  
                  if (hasTorch) {
                      const flicker = settings.disableAnimations ? 1 : 1 + (Math.sin(time / 100) * 0.05 + Math.random() * 0.02);
                      const length = VISION_RADIUS_TORCH * scaleFactor * flicker;
                      const angle = p.rotation;
                      const spread = Math.PI / 2.5;
                      
                      const grad = mCtx.createRadialGradient(px, py, 10, px, py, length);
                      grad.addColorStop(0, 'rgba(255, 200, 100, 1.0)'); 
                      // [ULTRA] Richer light falloff
                      if (settings.ultraMode) grad.addColorStop(0.15, 'rgba(255, 220, 150, 0.9)');
                      grad.addColorStop(0.3, 'rgba(255, 180, 50, 0.6)'); 
                      grad.addColorStop(1, 'rgba(255, 150, 20, 0)');
                      
                      mCtx.fillStyle = grad;
                      mCtx.beginPath();
                      mCtx.moveTo(px, py);
                      mCtx.arc(px, py, length, angle - spread/2, angle + spread/2);
                      mCtx.fill();
                      
                      const innerGrad = mCtx.createRadialGradient(px, py, 0, px, py, 120 * scaleFactor * flicker);
                      innerGrad.addColorStop(0, 'rgba(255, 220, 150, 0.8)');
                      innerGrad.addColorStop(1, 'rgba(255, 220, 150, 0)');
                      mCtx.fillStyle = innerGrad;
                      mCtx.beginPath();
                      mCtx.arc(px, py, 120 * scaleFactor * flicker, 0, Math.PI * 2);
                      mCtx.fill();
                  } else {
                      const pRadius = VISION_RADIUS_BASE * scaleFactor;
                      const grad = mCtx.createRadialGradient(px, py, 0, px, py, pRadius);
                      grad.addColorStop(0, 'rgba(255, 255, 255, 0.9)');
                      grad.addColorStop(1, 'rgba(255, 255, 255, 0)');
                      mCtx.fillStyle = grad;
                      mCtx.beginPath();
                      mCtx.arc(px, py, pRadius, 0, Math.PI * 2);
                      mCtx.fill();
                  }
              };

              drawLight(player, true);
              remotePlayers.forEach(op => {
                  const sx = op.pos.x + ox, sy = op.pos.y + oy;
                  if (sx > -100 && sx < canvas.width + 100 && sy > -100 && sy < canvas.height + 100) {
                      drawLight(op);
                  }
              });
              
              const lightEntities = objects.filter(e => e.type === EntityType.FIREPIT || e.type === EntityType.FURNACE);
              lightEntities.forEach(e => {
                  const ex = (e.pos.x + ox) * scaleFactor, ey = (e.pos.y + oy) * scaleFactor;
                  if (ex < -50 || ex > mCanvas.width + 50 || ey < -50 || ey > mCanvas.height + 50) return;
                  
                  const flicker = settings.disableAnimations ? 1 : 1 + (Math.sin(time / 150) * 0.08);
                  const fr = VISION_RADIUS_FIREPIT * scaleFactor * flicker;
                  const g = mCtx.createRadialGradient(ex, ey, 0, ex, ey, fr);
                  g.addColorStop(0, 'rgba(255, 180, 100, 1.0)');
                  g.addColorStop(0.5, 'rgba(255, 100, 20, 0.4)');
                  g.addColorStop(1, 'rgba(255, 100, 20, 0)');
                  mCtx.fillStyle = g;
                  mCtx.beginPath();
                  mCtx.arc(ex, ey, fr, 0, Math.PI * 2);
                  mCtx.fill();
              });
              
              mCtx.globalCompositeOperation = 'source-over'; 
              ctx.drawImage(mCanvas, 0, 0, canvas.width, canvas.height);
              
              if (isHoldingTorch) {
                  ctx.save();
                  ctx.globalCompositeOperation = 'overlay';
                  ctx.fillStyle = 'rgba(255, 150, 0, 0.08)';
                  ctx.fillRect(0,0,canvas.width, canvas.height);
                  ctx.restore();
              }
          }
      }
      if (!uiOpen) drawCrosshair(ctx, mousePosRef.current.x, mousePosRef.current.y, settings.crosshairStyle);
    };
    let animId: number;
    const tick = (time: number) => { render(time); animId = requestAnimationFrame(tick); };
    animId = requestAnimationFrame(tick);
    return () => { window.removeEventListener('resize', resize); cancelAnimationFrame(animId); };
  }, [remotePlayersRef, userHandle, gameStateRef.current.settings.lowPerformance, gameStateRef.current.settings.ultraMode, fogParticles]); 
  
  return <canvas ref={canvasRef} className={`block ${gameStateRef.current.uiOpen ? '' : 'cursor-none'}`} />;
};
export default GameCanvas;
