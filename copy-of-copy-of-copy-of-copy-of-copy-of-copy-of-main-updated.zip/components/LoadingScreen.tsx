
import React, { useEffect, useState } from 'react';

interface Props {
  progress: number;
  text: string;
}

const TIPS = [
  "Harvest ore nodes for raw materials.",
  "Sulfur is essential for explosives.",
  "Metal fragments are needed for high tier structures.",
  "Be wary of radiation zones.",
  "Airdrops attract unwanted attention.",
  "Build a Tool Cupboard to prevent decay.",
];

const LoadingScreen: React.FC<Props> = ({ progress, text }) => {
  const [tip, setTip] = useState(TIPS[0]);

  useEffect(() => {
    setTip(TIPS[Math.floor(Math.random() * TIPS.length)]);
  }, []);

  return (
    <div className="fixed inset-0 bg-[#0c0a09] z-[9999] flex flex-col justify-between p-12 font-sans pointer-events-auto overflow-hidden text-white select-none">
        {/* Background */}
        <div 
            className="absolute inset-0 bg-cover bg-center opacity-30"
            style={{ 
                backgroundImage: `url("https://images.unsplash.com/photo-1518331483807-f671ed1968fb?q=80&w=2848&auto=format&fit=crop")`,
                filter: 'grayscale(100%) contrast(1.2)' 
            }} 
        />
        
        {/* Top Header */}
        <div className="relative z-10 flex justify-between items-start">
            <h1 className="text-5xl font-display text-white tracking-tight">
                LOADING
            </h1>
            <div className="flex flex-col items-end">
                <div className="text-[#ce422b] font-display text-2xl tracking-wider">PROCEDURAL MAP</div>
                <div className="text-stone-500 text-xs font-bold uppercase tracking-widest">Seed: 8842</div>
            </div>
        </div>

        {/* Center/Bottom Content */}
        <div className="relative z-10 w-full max-w-4xl mx-auto flex flex-col gap-4 mb-12">
            
            <div className="flex justify-between items-end mb-1">
                <span className="text-stone-400 text-sm font-bold uppercase tracking-wider">{text || "Initializing World..."}</span>
                <span className="text-white font-display text-2xl">{Math.floor(progress)}%</span>
            </div>

            {/* Progress Bar */}
            <div className="w-full h-2 bg-[#292524]">
                <div 
                    className="h-full bg-[#ce422b] transition-all duration-100 ease-linear" 
                    style={{ width: `${progress}%` }}
                />
            </div>

            {/* Tip Box */}
            <div className="mt-8 p-6 bg-black/40 border-l-4 border-[#ce422b] backdrop-blur-sm">
                <span className="text-[10px] text-[#ce422b] font-black uppercase tracking-widest block mb-2">HINT</span>
                <p className="text-lg font-display text-stone-200 tracking-wide">
                    {tip}
                </p>
            </div>
        </div>

        {/* Footer */}
        <div className="relative z-10 flex justify-between items-end text-stone-600 text-[10px] font-bold uppercase tracking-widest">
            <div>Asset Warmup: Complete</div>
            <div>Wilderness v1.2</div>
        </div>
    </div>
  );
};

export default LoadingScreen;
