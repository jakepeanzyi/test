
import React, { useState } from 'react';
import { GameSettings } from '../types';

interface Props {
  onPlay: () => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
  isAuthenticated: boolean;
  username: string | null;
  settings: GameSettings;
  onUpdateSettings: (settings: Partial<GameSettings>) => void;
}

const MENU_ITEMS = ['PLAY', 'NEWS', 'INVENTORY', 'ITEM STORE', 'WORKSHOP', 'RUST+', 'OPTIONS', 'QUIT'];

// Mock Data
const NEWS_ITEMS = [
    { id: 1, title: "Combat Update", date: "FEB 2025", image: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=600", desc: "New recoil patterns and ballistics overhaul. Prepare for a more skill-based experience." },
    { id: 2, title: "Base Decor DLC", date: "JAN 2025", image: "https://images.unsplash.com/photo-1518331483807-f671ed1968fb?auto=format&fit=crop&q=80&w=600", desc: "Spruce up your base with rugs, trophies, and neon signs. Make it feel like home." },
    { id: 3, title: "Performance Patch", date: "JAN 2025", image: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=600", desc: "Major optimizations for low-end hardware and server stability improvements." },
    { id: 4, title: "Wipe Hype", date: "DEC 2024", image: "https://images.unsplash.com/photo-1605218427306-635ba2439af2?auto=format&fit=crop&q=80&w=600", desc: "Fresh maps, fresh blueprints. Get ready to reclaim the island." },
];

const STORE_ITEMS = [
    { name: "Nomad Suit", price: "$9.99", color: "#b45309" },
    { name: "Blackout AK", price: "$4.99", color: "#171717" },
    { name: "Neon Box", price: "$2.99", color: "#9333ea" },
    { name: "Forest Camo", price: "$3.99", color: "#166534" },
    { name: "Metal Facemask", price: "$1.99", color: "#525252" },
    { name: "Spacesuit", price: "$12.99", color: "#e5e5e5" },
];

const INVENTORY_MOCK = Array(12).fill(null).map((_, i) => ({ 
    id: i, 
    name: `Skin #${i+1}`, 
    rarity: Math.random() > 0.8 ? 'Rare' : 'Common',
    color: Math.random() > 0.5 ? '#44403c' : '#57534e'
}));

const LandingPage: React.FC<Props> = ({ onPlay, onOpenAuth, isAuthenticated, username, settings, onUpdateSettings }) => {
  const [activeTab, setActiveTab] = useState<string | null>(null);

  const handleMenuClick = (item: string) => {
    if (item === 'PLAY') {
      if (isAuthenticated) {
        onPlay();
      } else {
        onOpenAuth('login');
      }
    } else if (item === 'QUIT') {
        window.location.reload();
    } else {
      setActiveTab(item === activeTab ? null : item);
    }
  };

  const renderContent = () => {
      if (!activeTab) return null;

      return (
          <div className="absolute top-0 right-0 h-full w-[calc(100%-400px)] bg-black/80 backdrop-blur-md animate-in slide-in-from-right duration-300 border-l border-white/10 flex flex-col p-12 overflow-y-auto custom-scrollbar z-20">
              <div className="flex justify-between items-end mb-8 border-b border-white/10 pb-4">
                  <h2 className="text-6xl font-display text-white tracking-tight uppercase">{activeTab}</h2>
                  <button onClick={() => setActiveTab(null)} className="text-stone-500 hover:text-white font-bold text-2xl">✕</button>
              </div>

              {activeTab === 'NEWS' && (
                  <div className="grid grid-cols-2 gap-6">
                      {NEWS_ITEMS.map(news => (
                          <div key={news.id} className="group cursor-pointer bg-white/5 border border-white/5 hover:bg-white/10 transition-all p-4 flex flex-col gap-4">
                              <div className="h-48 w-full bg-stone-800 overflow-hidden relative">
                                  <img src={news.image} className="w-full h-full object-cover opacity-80 group-hover:scale-110 transition-transform duration-700" />
                                  <div className="absolute top-2 left-2 bg-[#ce422b] text-white text-[10px] font-bold px-2 py-1 uppercase tracking-widest">{news.date}</div>
                              </div>
                              <div>
                                  <h3 className="text-2xl font-display text-white mb-2 group-hover:text-[#ce422b] transition-colors">{news.title}</h3>
                                  <p className="text-stone-400 text-sm leading-relaxed">{news.desc}</p>
                              </div>
                          </div>
                      ))}
                  </div>
              )}

              {activeTab === 'INVENTORY' && (
                  isAuthenticated ? (
                      <div className="grid grid-cols-4 gap-4">
                          {INVENTORY_MOCK.map(item => (
                              <div key={item.id} className="aspect-square bg-[#1c1917] border border-white/10 hover:border-white/30 transition-all p-4 flex flex-col items-center justify-center gap-2 group cursor-pointer relative">
                                  <div className="w-full h-full bg-black/20 absolute inset-0 group-hover:bg-transparent transition-colors" />
                                  <div className={`w-16 h-16 rounded-lg ${item.rarity === 'Rare' ? 'bg-purple-900/50' : 'bg-stone-700/50'} border-2 border-transparent group-hover:border-white/50 transition-all`} />
                                  <span className="text-stone-400 font-bold uppercase text-xs tracking-wider z-10">{item.name}</span>
                                  {item.rarity === 'Rare' && <span className="absolute top-2 right-2 text-[8px] bg-purple-600 text-white px-1 rounded">RARE</span>}
                              </div>
                          ))}
                      </div>
                  ) : (
                      <div className="flex flex-col items-center justify-center h-full gap-4 opacity-50">
                          <div className="text-4xl text-stone-600">🔒</div>
                          <p className="text-stone-400 text-xl font-display uppercase tracking-widest">Authentication Required</p>
                      </div>
                  )
              )}

              {activeTab === 'ITEM STORE' && (
                  <div className="grid grid-cols-3 gap-6">
                      {STORE_ITEMS.map((item, i) => (
                          <div key={i} className="bg-[#1c1917] border border-white/10 p-0 overflow-hidden group hover:border-[#ce422b] transition-colors">
                              <div className="h-40 bg-stone-800 relative flex items-center justify-center">
                                  <div className={`w-24 h-24 ${item.color} shadow-2xl rotate-3 group-hover:rotate-6 transition-transform duration-500 rounded-lg`} />
                                  <div className="absolute bottom-2 right-2 bg-black/80 text-white px-2 py-1 text-sm font-bold">{item.price}</div>
                              </div>
                              <div className="p-4 flex justify-between items-center bg-white/5">
                                  <span className="text-white font-bold uppercase tracking-wider text-sm">{item.name}</span>
                                  <button className="text-[10px] bg-[#ce422b] text-white px-3 py-1 uppercase font-bold hover:bg-red-600 transition-colors">Buy</button>
                              </div>
                          </div>
                      ))}
                  </div>
              )}

              {activeTab === 'WORKSHOP' && (
                  <div className="flex flex-col gap-6">
                      <div className="p-6 bg-[#ce422b]/10 border border-[#ce422b]/30 flex items-center gap-4">
                          <div className="text-4xl">⭐</div>
                          <div>
                              <h3 className="text-white font-display text-2xl">Community Vote</h3>
                              <p className="text-stone-400 text-sm">Vote for the next skins to be added to the game.</p>
                          </div>
                      </div>
                      <div className="grid grid-cols-3 gap-4">
                          {[1,2,3,4,5,6].map(i => (
                              <div key={i} className="aspect-video bg-stone-900 border border-white/5 hover:border-white/20 transition-all relative group cursor-pointer">
                                  <div className="absolute inset-0 flex items-center justify-center text-stone-700 font-display text-4xl group-hover:text-stone-600">PREVIEW</div>
                                  <div className="absolute bottom-0 left-0 w-full bg-black/80 p-2 flex justify-between items-center">
                                      <span className="text-white text-xs font-bold">Skin Concept #{i}</span>
                                      <span className="text-green-500 text-xs">▲ {Math.floor(Math.random()*1000)}</span>
                                  </div>
                              </div>
                          ))}
                      </div>
                  </div>
              )}

              {activeTab === 'RUST+' && (
                  <div className="flex flex-col items-center justify-center h-full gap-8 text-center">
                      <div className="w-64 h-64 bg-white p-4">
                          <div className="w-full h-full bg-black flex items-center justify-center text-white font-mono text-xs">
                              [ QR CODE PLACEHOLDER ]
                          </div>
                      </div>
                      <div className="max-w-md">
                          <h3 className="text-3xl font-display text-[#ce422b] mb-4">Companion App</h3>
                          <p className="text-stone-400 text-sm leading-relaxed">
                              Pair with the companion app to get push notifications when you're being raided, view the map, communicate with your team, and control smart devices from your real-world phone.
                          </p>
                      </div>
                  </div>
              )}

              {activeTab === 'OPTIONS' && (
                  <div className="space-y-8 max-w-2xl">
                      <div className="space-y-4">
                          <h3 className="text-[#ce422b] font-display text-2xl border-b border-white/10 pb-2">Audio</h3>
                          <div className="flex items-center justify-between">
                              <span className="text-stone-300 font-bold uppercase text-xs">Master Volume</span>
                              <input type="range" className="w-64 accent-[#ce422b]" min="0" max="100" value={settings.volume} onChange={e => onUpdateSettings({ volume: parseInt(e.target.value) })} />
                          </div>
                          <div className="flex items-center justify-between">
                              <span className="text-stone-300 font-bold uppercase text-xs">Music</span>
                              <input type="range" className="w-64 accent-[#ce422b]" min="0" max="100" value={settings.musicVolume} onChange={e => onUpdateSettings({ musicVolume: parseInt(e.target.value) })} />
                          </div>
                      </div>

                      <div className="space-y-4">
                          <h3 className="text-[#ce422b] font-display text-2xl border-b border-white/10 pb-2">Graphics</h3>
                          <div className="flex items-center justify-between">
                              <span className="text-stone-300 font-bold uppercase text-xs">Vignette</span>
                              <input type="range" className="w-64 accent-[#ce422b]" min="0" max="100" value={settings.vignetteStrength} onChange={e => onUpdateSettings({ vignetteStrength: parseInt(e.target.value) })} />
                          </div>
                          <div className="flex items-center justify-between bg-white/5 p-3 rounded">
                              <span className="text-stone-300 font-bold uppercase text-xs">Scanlines</span>
                              <input type="checkbox" checked={settings.scanlinesEnabled} onChange={e => onUpdateSettings({ scanlinesEnabled: e.target.checked })} className="accent-[#ce422b] scale-125" />
                          </div>
                          <div className="flex items-center justify-between bg-white/5 p-3 rounded">
                              <span className="text-stone-300 font-bold uppercase text-xs">Low Performance Mode</span>
                              <input type="checkbox" checked={settings.lowPerformance} onChange={e => onUpdateSettings({ lowPerformance: e.target.checked })} className="accent-[#ce422b] scale-125" />
                          </div>
                      </div>
                  </div>
              )}
          </div>
      );
  };

  return (
    <div className="fixed inset-0 z-[250] overflow-hidden select-none text-white">
      {/* Background Image - Industrial/Wasteland Sunset vibe */}
      <div 
        className="absolute inset-0 bg-cover bg-center transition-transform duration-[20s] hover:scale-105"
        style={{ 
            backgroundImage: `url("https://images.unsplash.com/photo-1558611977-7be377227c81?q=80&w=2940&auto=format&fit=crop")`,
            filter: 'brightness(0.6) sepia(0.2) contrast(1.1)' 
        }} 
      />
      
      {/* Vignette Overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(0,0,0,0.6)_100%)] pointer-events-none" />
      <div className="absolute inset-0 bg-gradient-to-r from-black/50 via-transparent to-black/20 pointer-events-none" />

      {/* Main Content Container */}
      <div className="relative z-10 w-full h-full flex p-8 md:p-12">
        
        {/* Left Column: Logo & Menu */}
        <div className="flex flex-col gap-12 w-full max-w-sm z-30">
            
            {/* Logo */}
            <div className="flex items-center gap-4 animate-in slide-in-from-left duration-700">
                <div className="w-16 h-16 bg-[#ce422b] flex items-center justify-center shadow-lg">
                    <svg className="w-10 h-10 text-white fill-current" viewBox="0 0 24 24">
                        <path d="M12 2L2 19h20L12 2zm0 3.8l6.8 11.2H5.2L12 5.8z"/>
                    </svg>
                </div>
                <h1 className="text-7xl font-display tracking-tight text-white drop-shadow-xl">
                    RUST<span className="text-[#ce422b]">ED</span>
                </h1>
            </div>

            {/* Menu Items */}
            <div className="flex flex-col items-start gap-1 font-display text-4xl tracking-wide animate-in slide-in-from-left duration-1000 delay-200">
                {MENU_ITEMS.map(item => (
                    <button 
                        key={item}
                        onClick={() => handleMenuClick(item)}
                        className={`hover:scale-105 hover:pl-2 transition-all duration-200 uppercase drop-shadow-md text-left w-full ${activeTab === item ? 'text-white pl-4 border-l-4 border-[#ce422b]' : 'text-white/50 hover:text-white'} ${item === 'RUST+' ? 'text-[#ce422b] hover:text-red-400' : ''}`}
                    >
                        {item === 'RUST+' ? (
                            <span className="relative">Rust+ <span className="absolute -top-1 -right-6 bg-[#ce422b] text-white text-[10px] px-1 rounded font-sans font-bold">NEW</span></span>
                        ) : item}
                    </button>
                ))}
            </div>
        </div>

        {/* Content Panels Rendered Here */}
        {renderContent()}

        {/* Right Column: Icons & Profile */}
        <div className="absolute right-0 top-0 h-full w-24 flex flex-col justify-between items-center py-8 bg-gradient-to-l from-black/40 to-transparent z-30">
            
            {/* Top Right: Profile */}
            <div className="flex flex-col items-center gap-4">
                {isAuthenticated ? (
                    <div className="relative group cursor-pointer">
                        <div className="w-12 h-12 bg-stone-700 overflow-hidden border-2 border-white/20 group-hover:border-white/50 transition-colors">
                            <img 
                                src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`} 
                                alt="User" 
                                className="w-full h-full object-cover"
                            />
                        </div>
                        <div className="absolute top-0 right-0 w-3 h-3 bg-green-500 border-2 border-black rounded-full"></div>
                    </div>
                ) : (
                    <button onClick={() => onOpenAuth('login')} className="w-12 h-12 bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors">
                        <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                    </button>
                )}
                
                <div className="w-8 h-px bg-white/20 my-2"></div>
                
                {/* Utility Icons */}
                <button className="text-white/50 hover:text-white transition-colors"><span className="text-xl">✉</span></button>
                <button className="text-white/50 hover:text-white transition-colors"><span className="text-xl">文</span></button>
            </div>

            {/* Bottom Right: Socials */}
            <div className="flex flex-col gap-6 items-center mb-8">
                {['Discord', 'Facebook', 'Twitter', 'Insta', 'Steam', 'Web'].map((icon, i) => (
                    <button key={icon} className="text-white/40 hover:text-white transition-all hover:scale-110">
                        <div className="w-6 h-6 bg-white/10 rounded flex items-center justify-center text-[10px]">
                            {/* Placeholder icons */}
                            {icon[0]}
                        </div>
                    </button>
                ))}
            </div>
        </div>

        {/* Bottom Status */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-white/20 text-xs font-sans font-bold tracking-widest z-30">
            76498 • v1.2.0 • EXPERIMENTAL
        </div>

      </div>
    </div>
  );
};

export default LandingPage;
