
import React from 'react';

interface Props {
  vignetteStrength?: number;
  scanlinesEnabled?: boolean;
  ultraMode?: boolean;
  lowPerformance?: boolean;
}

const PostProcessing: React.FC<Props> = ({ vignetteStrength = 80, scanlinesEnabled = false, ultraMode = false, lowPerformance = false }) => {
  if (lowPerformance) return null; // Completely bypass for maximum FPS

  const opacity = vignetteStrength / 100;
  return (
    <>
      {/* Heavy Vignette */}
      <div className="fixed inset-0 pointer-events-none z-[50]"
           style={{ background: `radial-gradient(circle, transparent 50%, rgba(0,0,0,${opacity}) 100%)` }} 
      />
      {/* Static Noise Overlay (Optimized CSS texture) */}
      <div className="fixed inset-0 pointer-events-none z-[40] opacity-[0.03] mix-blend-overlay"
           style={{ 
             backgroundImage: `url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyBAMAAAD9tt+IAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAANUExURf///////////////////6D/pVQAAAAIdFJOUz8ZIDBQUFBQZisvVwAAADRJREFUKM9jYMAFDAYMBgxGDAZGBjYQYGBgEGEEA8YGMAYDBlEGQzYGRhBGMAAByBwGDBgYAH6jAf9mQp78AAAAAElFTkSuQmCC")`,
             backgroundSize: '50px 50px'
           }}
      />
      {/* Scanlines */}
      {scanlinesEnabled && (
        <div className="fixed inset-0 pointer-events-none z-[60] opacity-[0.05]"
             style={{
               background: `linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.25) 50%)`,
               backgroundSize: '100% 4px'
             }}
        />
      )}
      
      {/* ULTRA GRAPHICS MODE EFFECTS */}
      {ultraMode && (
        <>
            {/* Color Grading: Boost Contrast & Saturation via Backdrop Filter */}
            <div className="fixed inset-0 pointer-events-none z-[45]" 
                 style={{ 
                   backdropFilter: 'contrast(1.15) saturate(1.25)',
                 }}
            />
            
            {/* Atmospheric Glow / Bloom Simulation */}
            <div className="fixed inset-0 pointer-events-none z-[46] opacity-40 mix-blend-screen"
                 style={{ background: 'radial-gradient(circle at 50% 0%, rgba(255,220,180,0.15) 0%, transparent 70%)' }} 
            />
            
            {/* Cinematic Overlay to unify colors */}
            <div className="fixed inset-0 pointer-events-none z-[47] opacity-[0.08] mix-blend-overlay bg-indigo-900" />
        </>
      )}
    </>
  );
};

export default PostProcessing;
