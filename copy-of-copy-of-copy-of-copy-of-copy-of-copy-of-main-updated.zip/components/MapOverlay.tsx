
import React, { useRef, useEffect, useState } from 'react';
import { Vector2, Player, Entity, EntityType } from '../types';
import { getGroundColorRGBAt } from '../engine/WorldGenerator';
import { CHUNK_SIZE } from '../constants';

interface Props {
  playerPos: Vector2;
  teammates: Player[];
  visitedChunks: string[];
  chunks: Record<string, Entity[]>;
  onClose: () => void;
}

// Resolution of the map tiles. 64px means each chunk (2048 units) is represented by 64x64 pixels.
// Each pixel represents 32x32 world units.
const TILE_RES = 64; 

const MapOverlay: React.FC<Props> = ({ playerPos, teammates, visitedChunks, chunks, onClose }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mapSize, setMapSize] = useState(600);
  const mapTileCache = useRef<Record<string, HTMLCanvasElement | OffscreenCanvas>>({});
  
  // Controls how much world area is shown.
  // Lower scale = zoomed out (more world). Higher scale = zoomed in.
  const scale = 0.15; 

  useEffect(() => {
      const handleResize = () => {
          const minDim = Math.min(window.innerWidth, window.innerHeight);
          setMapSize(Math.min(800, minDim - 100));
      };
      handleResize();
      window.addEventListener('resize', handleResize);
      return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Generate missing map tiles
  useEffect(() => {
      visitedChunks.forEach(key => {
          if (!mapTileCache.current[key]) {
              const [cx, cy] = key.split(',').map(Number);
              const size = TILE_RES;
              const canvas = new OffscreenCanvas(size, size);
              const ctx = canvas.getContext('2d');
              if (!ctx) return;

              const imgData = ctx.createImageData(size, size);
              const data = imgData.data;
              const startX = cx * CHUNK_SIZE;
              const startY = cy * CHUNK_SIZE;
              const step = CHUNK_SIZE / size;

              for (let y = 0; y < size; y++) {
                  for (let x = 0; x < size; x++) {
                      // Sample center of the sub-block
                      const wx = startX + x * step + step/2;
                      const wy = startY + y * step + step/2;
                      
                      const rgb = getGroundColorRGBAt({x: wx, y: wy});
                      const idx = (y * size + x) * 4;
                      data[idx] = rgb.r;
                      data[idx+1] = rgb.g;
                      data[idx+2] = rgb.b;
                      data[idx+3] = 255;
                  }
              }
              ctx.putImageData(imgData, 0, 0);
              mapTileCache.current[key] = canvas;
          }
      });
  }, [visitedChunks]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.imageSmoothingEnabled = false;
    
    // Clear background
    ctx.fillStyle = '#0c0a09';
    ctx.fillRect(0, 0, mapSize, mapSize);

    const halfMap = mapSize / 2;

    ctx.save();
    // Center map on player
    ctx.translate(halfMap, halfMap);
    ctx.scale(scale, scale);
    ctx.translate(-playerPos.x, -playerPos.y);

    // 1. Draw Map Tiles
    visitedChunks.forEach(key => {
        const tile = mapTileCache.current[key];
        if (tile) {
            const [cx, cy] = key.split(',').map(Number);
            // Draw chunk at correct world position with correct size
            ctx.drawImage(tile, cx * CHUNK_SIZE, cy * CHUNK_SIZE, CHUNK_SIZE, CHUNK_SIZE);
        }
    });

    // 2. Draw Entities
    // We only iterate through chunks that are somewhat visible or visited to save time
    visitedChunks.forEach(key => {
        if (chunks[key]) {
            chunks[key].forEach(ent => {
                if (ent.isBuilding) {
                    ctx.fillStyle = '#94a3b8';
                    ctx.fillRect(ent.pos.x - 25, ent.pos.y - 25, 50, 50);
                } else if (ent.type === EntityType.AIRDROP_CRATE) {
                    ctx.fillStyle = '#ef4444';
                    ctx.fillRect(ent.pos.x - 40, ent.pos.y - 40, 80, 80);
                } else if (ent.type === EntityType.LOOT_CRATE || ent.type === EntityType.ELITE_TIER_CRATE || ent.type === EntityType.MILITARY_CRATE) {
                    ctx.fillStyle = '#ca8a04';
                    ctx.fillRect(ent.pos.x - 20, ent.pos.y - 20, 40, 40);
                } else if (ent.type.includes('VEHICLE')) {
                    ctx.fillStyle = '#fff';
                    ctx.beginPath(); ctx.arc(ent.pos.x, ent.pos.y, 40, 0, Math.PI*2); ctx.fill();
                } else if (ent.type === EntityType.SLEEPING_BAG && ent.ownerId) {
                    ctx.fillStyle = '#22c55e'; // Green spawn point
                    ctx.beginPath(); ctx.arc(ent.pos.x, ent.pos.y, 30, 0, Math.PI*2); ctx.fill();
                }
            });
        }
    });

    // 3. Draw Teammates
    teammates.forEach(tm => {
        ctx.fillStyle = '#10b981';
        ctx.beginPath();
        ctx.arc(tm.pos.x, tm.pos.y, 60, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#064e3b';
        ctx.lineWidth = 10;
        ctx.stroke();
    });

    // 4. Draw Player
    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.arc(playerPos.x, playerPos.y, 80, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#7f1d1d';
    ctx.lineWidth = 10;
    ctx.stroke();
    
    // Player direction cone
    ctx.fillStyle = 'rgba(239, 68, 68, 0.3)';
    ctx.beginPath();
    ctx.moveTo(playerPos.x, playerPos.y);
    // We don't have player rotation in props readily available for map, assuming NORTH or passed in future
    // Just a simple circle for now is enough as rotation on map can be confusing if map doesn't rotate
    
    ctx.restore();

    // UI Overlay on top of canvas (Coordinate Text)
    // (Handled by React below, but we could draw specific HUD elements here if needed)

  }, [playerPos, teammates, visitedChunks, chunks, mapSize, scale]);

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[5000] p-4 animate-in fade-in zoom-in duration-200" onClick={onClose}>
      <div className="relative bg-stone-900 border-4 border-stone-700 p-2 rounded-lg shadow-2xl" onClick={e => e.stopPropagation()}>
        <h2 className="absolute -top-8 left-0 text-white font-black uppercase tracking-widest text-lg">Tactical Map</h2>
        
        <canvas ref={canvasRef} width={mapSize} height={mapSize} className="bg-[#0f172a] rounded border border-white/10" />
        
        <div className="absolute top-4 right-4 bg-black/60 px-3 py-1 rounded text-[10px] text-white font-mono border border-white/10 backdrop-blur">
            XY: {Math.round(playerPos.x)}, {Math.round(playerPos.y)}
        </div>
        
        {/* Legend */}
        <div className="absolute bottom-4 left-4 bg-black/60 p-2 rounded border border-white/10 backdrop-blur flex flex-col gap-1">
            <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-red-500"></div>
                <span className="text-[8px] text-white font-bold uppercase">You</span>
            </div>
            <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                <span className="text-[8px] text-white font-bold uppercase">Ally</span>
            </div>
            <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-slate-400"></div>
                <span className="text-[8px] text-white font-bold uppercase">Structure</span>
            </div>
        </div>

        <button onClick={onClose} className="absolute -top-8 right-0 text-stone-500 hover:text-white font-bold transition-colors">CLOSE [M]</button>
      </div>
    </div>
  );
};

export default MapOverlay;
