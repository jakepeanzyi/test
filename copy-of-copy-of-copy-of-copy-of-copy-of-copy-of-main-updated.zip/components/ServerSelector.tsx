
import React from 'react';

interface Props {
  onSelect: (serverId: number) => void;
}

const ServerSelector: React.FC<Props> = ({ onSelect }) => {
  const servers = [
    { id: 1, name: 'North America - 1', population: 'Medium', ping: '24ms', region: 'US East' },
    { id: 2, name: 'Europe - Central', population: 'Low', ping: '88ms', region: 'Germany' },
    { id: 3, name: 'Asia Pacific', population: 'High', ping: '210ms', region: 'Japan' }
  ];

  return (
    <div className="fixed inset-0 bg-black/90 flex flex-col items-center justify-center z-[280] p-4 backdrop-blur-2xl">
      <div className="w-full max-w-xl bg-stone-900/60 border border-white/10 p-10 rounded-[2.5rem] shadow-2xl backdrop-blur-md">
        <h2 className="text-white text-3xl font-bold mb-2 text-center">Server List</h2>
        <p className="text-stone-500 text-sm mb-10 text-center uppercase tracking-widest font-bold">Select a Server to Join</p>
        
        <div className="space-y-4">
          {servers.map(s => (
            <button
              key={s.id}
              onClick={() => onSelect(s.id)}
              className="w-full flex justify-between items-center bg-white/5 border border-white/5 p-6 rounded-3xl hover:bg-white/10 hover:border-white/20 transition-all group"
            >
              <div className="text-left">
                <div className="text-white font-bold text-lg group-hover:text-amber-500 transition-colors">{s.name}</div>
                <div className="text-[10px] text-stone-500 font-bold uppercase mt-1 tracking-wider">{s.region}</div>
              </div>
              <div className="text-right flex items-center gap-6">
                 <div className="flex flex-col items-end">
                    <span className="text-[10px] text-stone-500 uppercase font-bold">Players</span>
                    <span className={`text-xs font-black uppercase ${s.population === 'High' ? 'text-red-500' : 'text-emerald-500'}`}>{s.population}</span>
                 </div>
                 <div className="flex flex-col items-end min-w-[50px]">
                    <span className="text-[10px] text-stone-500 uppercase font-bold">Speed</span>
                    <span className="text-xs text-white font-black">{s.ping}</span>
                 </div>
              </div>
            </button>
          ))}
        </div>
        
        <div className="mt-10 pt-6 border-t border-white/5 text-stone-500 text-[9px] uppercase tracking-widest text-center font-bold">
          Your progress will be saved to this specific server
        </div>
      </div>
    </div>
  );
};

export default ServerSelector;
