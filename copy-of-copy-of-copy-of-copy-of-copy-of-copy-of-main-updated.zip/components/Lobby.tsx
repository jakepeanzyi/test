
import React, { useState, useEffect, useRef } from 'react';
import { PlayerCustomization, ChatMessage, FriendRelation } from '../types';
import { 
  subscribeToTrollBox, 
  saveCustomization, getCustomization 
} from '../services/lobbyService';
import { subscribeToSocial as subscribeSocial } from '../services/socialService';
import { drawPlayer } from '../models/Player';
import ServerSelector from './ServerSelector';

interface Props {
  userId: string;
  username: string;
  onPlay: () => void;
  onOpenSettings: () => void;
  onServerSelect: (id: number) => void;
}

type LobbyTab = 'PLAY' | 'CUSTOMIZE' | 'SERVERS';

const SKIN_TONES = ['#d4a373', '#e9c46a', '#451a03', '#f5d0b0', '#8d5524', '#c68642', '#e0ac69', '#f1c27d'];
const CLOAK_COLORS = ['#262626', '#14532d', '#1e3a8a', '#991b1b', '#475569', '#3f6212', '#a16207', '#4c1d95', '#334155', '#713f12'];
const EYE_COLORS = ['#1c1917', '#ef4444', '#3b82f6', '#22c55e', '#eab308', '#ffffff', '#a855f7', '#06b6d4'];

const Lobby: React.FC<Props> = ({ userId, username, onPlay, onOpenSettings, onServerSelect }) => {
  const [activeTab, setActiveTab] = useState<LobbyTab>('PLAY');
  const [customization, setCustomization] = useState<PlayerCustomization>({ skinColor: '#d4a373', cloakColor: '#262626', eyeColor: '#1c1917' });
  const [isSaving, setIsSaving] = useState(false);
  const [selectedServerId, setSelectedServerId] = useState<number>(1);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    getCustomization(userId).then(c => c && setCustomization(c));
  }, [userId]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    const render = (time: number) => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.save();
      
      const cx = canvas.width * 0.65;
      const cy = canvas.height * 0.7;
      
      const scale = 8;
      ctx.translate(cx, cy);
      ctx.scale(scale, scale);
      
      // Floating animation
      const float = Math.sin(time / 1000) * 2;
      ctx.translate(0, float);

      const mockPlayer: any = {
        pos: { x: 0, y: 0 },
        rotation: time / 3000,
        color: customization.skinColor,
        customization,
        isMoving: false, isSwinging: false, hotbar: [], inventory: [], selectedHotbarIndex: 0, hitReaction: 0, isSleeping: false, walkCycle: 0
      };
      drawPlayer(ctx, mockPlayer, { lowPerformance: false } as any, time);
      ctx.restore();
      
      animId = requestAnimationFrame(render);
    };
    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [customization]);

  const saveLook = async () => {
    setIsSaving(true);
    await saveCustomization(userId, customization);
    setIsSaving(false);
  };

  return (
    <div className="fixed inset-0 bg-[#0c0a09] text-white flex font-sans overflow-hidden select-none">
      {/* Background to match Landing */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-40 pointer-events-none"
        style={{ 
            backgroundImage: `url("https://images.unsplash.com/photo-1558611977-7be377227c81?q=80&w=2940&auto=format&fit=crop")`,
            filter: 'brightness(0.6) sepia(0.2) contrast(1.1) blur(4px)' 
        }} 
      />
      <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-transparent to-black/40 pointer-events-none" />

      {/* Left Sidebar */}
      <div className="w-64 flex flex-col pt-12 pl-12 z-50">
        <h1 className="text-5xl font-display text-white tracking-tight mb-12 drop-shadow-xl">
            LOBBY
        </h1>
        
        <div className="flex flex-col items-start gap-2 font-display text-3xl tracking-wide">
            <button 
                onClick={() => setActiveTab('PLAY')}
                className={`transition-all duration-200 uppercase text-left ${activeTab === 'PLAY' ? 'text-[#ce422b] scale-105 pl-2' : 'text-white/60 hover:text-white hover:pl-2'}`}
            >
                Start Game
            </button>
            <button 
                onClick={() => setActiveTab('CUSTOMIZE')}
                className={`transition-all duration-200 uppercase text-left ${activeTab === 'CUSTOMIZE' ? 'text-[#ce422b] scale-105 pl-2' : 'text-white/60 hover:text-white hover:pl-2'}`}
            >
                Character
            </button>
            <button 
                onClick={() => setActiveTab('SERVERS')}
                className={`transition-all duration-200 uppercase text-left ${activeTab === 'SERVERS' ? 'text-[#ce422b] scale-105 pl-2' : 'text-white/60 hover:text-white hover:pl-2'}`}
            >
                Servers
            </button>
            <div className="h-4" />
            <button 
                onClick={onOpenSettings}
                className="text-white/40 hover:text-white hover:pl-2 transition-all duration-200 uppercase text-left text-2xl"
            >
                Settings
            </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 relative">
        {/* 3D Character Canvas */}
        <canvas ref={canvasRef} width={1600} height={1000} className="absolute inset-0 w-full h-full object-cover pointer-events-none" />

        {/* Content Panels */}
        <div className="absolute top-0 left-0 w-full h-full p-12 pt-32 pointer-events-none flex justify-end">
            {activeTab === 'PLAY' && (
                <div className="pointer-events-auto mt-auto mb-12 mr-12 flex flex-col items-end gap-6 animate-in slide-in-from-right duration-500">
                    <div className="bg-black/60 backdrop-blur border-l-4 border-[#ce422b] p-6 max-w-sm text-right">
                        <h3 className="text-white font-display text-2xl tracking-wider mb-2">Ready to Deploy</h3>
                        <p className="text-stone-400 text-sm font-sans font-bold leading-relaxed">
                            Server: <span className="text-white">Official US East {selectedServerId}</span>
                            <br/>
                            Identity: <span className="text-[#ce422b]">{username}</span>
                        </p>
                    </div>
                    <button 
                        onClick={onPlay}
                        className="bg-[#ce422b] hover:bg-[#b91c1c] text-white font-display text-4xl px-12 py-6 uppercase tracking-wide transition-all hover:scale-105 shadow-xl"
                    >
                        ENTER WORLD
                    </button>
                </div>
            )}

            {activeTab === 'CUSTOMIZE' && (
                <div className="pointer-events-auto mr-12 mt-12 w-96 bg-[#1c1917]/90 border border-[#44403c] p-8 animate-in slide-in-from-right duration-300 shadow-2xl">
                    <h2 className="text-2xl font-display text-white mb-6 border-b border-[#44403c] pb-4">Appearance</h2>
                    
                    <div className="space-y-6 overflow-y-auto max-h-[60vh] custom-scrollbar pr-2">
                        <div className="space-y-3">
                            <label className="text-xs font-bold text-stone-500 uppercase tracking-wider">Skin Tone</label>
                            <div className="grid grid-cols-4 gap-2">
                                {SKIN_TONES.map(c => (
                                    <button key={c} onClick={() => setCustomization({...customization, skinColor: c})} className={`h-10 border-2 transition-all ${customization.skinColor === c ? 'border-white scale-110' : 'border-transparent opacity-50 hover:opacity-100'}`} style={{ backgroundColor: c }} />
                                ))}
                            </div>
                        </div>
                        <div className="space-y-3">
                            <label className="text-xs font-bold text-stone-500 uppercase tracking-wider">Eyes</label>
                            <div className="grid grid-cols-4 gap-2">
                                {EYE_COLORS.map(c => (
                                    <button key={c} onClick={() => setCustomization({...customization, eyeColor: c})} className={`h-10 border-2 transition-all ${customization.eyeColor === c ? 'border-white scale-110' : 'border-transparent opacity-50 hover:opacity-100'}`} style={{ backgroundColor: c }} />
                                ))}
                            </div>
                        </div>
                        <div className="space-y-3">
                            <label className="text-xs font-bold text-stone-500 uppercase tracking-wider">Attire</label>
                            <div className="grid grid-cols-5 gap-2">
                                {CLOAK_COLORS.map(c => (
                                    <button key={c} onClick={() => setCustomization({...customization, cloakColor: c})} className={`h-10 border-2 transition-all ${customization.cloakColor === c ? 'border-white scale-110' : 'border-transparent opacity-50 hover:opacity-100'}`} style={{ backgroundColor: c }} />
                                ))}
                            </div>
                        </div>
                    </div>
                    <button onClick={saveLook} disabled={isSaving} className="w-full mt-8 bg-[#ce422b] hover:bg-[#b91c1c] text-white font-display text-xl py-3 uppercase tracking-wide transition-all">
                        {isSaving ? 'SAVING...' : 'SAVE CHANGES'}
                    </button>
                </div>
            )}

            {activeTab === 'SERVERS' && (
                <div className="pointer-events-auto absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm animate-in fade-in">
                    <div className="w-full max-w-4xl h-[70vh] bg-[#1c1917] border border-[#44403c] p-0 shadow-2xl flex flex-col">
                        <div className="bg-[#292524] p-6 border-b border-[#44403c] flex justify-between items-center">
                            <h2 className="text-3xl font-display text-white tracking-wide">Server Browser</h2>
                            <button onClick={() => setActiveTab('PLAY')} className="text-stone-500 hover:text-white font-bold text-xl">✕</button>
                        </div>
                        <div className="flex-1 overflow-y-auto custom-scrollbar p-6">
                            <ServerSelector onSelect={(id) => { setSelectedServerId(id); setActiveTab('PLAY'); }} />
                        </div>
                    </div>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default Lobby;
