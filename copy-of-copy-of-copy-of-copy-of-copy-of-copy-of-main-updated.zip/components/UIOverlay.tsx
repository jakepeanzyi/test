
import React, { useState, useEffect, useRef } from 'react';
import { GameState, ItemType, EntityType, GameSettings, InventoryItem, ItemCategory, Player, Vector2 } from '../types';
import { ITEM_DATA, RECIPES, BUILDING_RECIPES, BASE_INVENTORY_SLOTS, CONTAINER_SLOTS } from '../constants';
import { drawItemModel } from '../models/ItemModels';

interface Props {
  gameState: GameState;
  remotePlayers: Player[];
  serverPop?: number;
  onActionTrigger: () => void;
  onCraftStart: (recipeId: string) => void;
  onCraftStop: () => void;
  onRepair: (itemId: string) => void;
  onUseItem: (itemId: string) => void;
  onDropItem: (index: number) => void;
  onToggleSlot: (itemId: string, slot: number) => void;
  onMoveItem: (fromIndex: number, toIndex: number) => void;
  onSortInventory: () => void;
  onUpdateSettings: (settings: Partial<GameSettings>) => void;
  onInspectItem: (id: string) => void;
  onCloseUI: () => void;
  onOpenUI: () => void;
  onOpenSettings: () => void;
  onSelectBuilding?: (type: EntityType) => void;
  onLeaveServer?: () => void;
  onConsoleCommand?: (cmd: string) => void;
  onRespawn?: (pos?: Vector2) => void;
  onMoveToContainer?: (playerSlot: number, containerSlot: number) => void;
  onTakeFromContainer?: (containerSlot: number, playerSlot: number) => void;
}

// --- HELPER COMPONENTS FOR SETTINGS UI ---

const SettingToggle: React.FC<{ label: string; checked: boolean; onChange: (v: boolean) => void; color?: 'red' | 'amber' }> = ({ label, checked, onChange, color = 'red' }) => (
    <div className="flex justify-between items-center bg-[#292524] p-4 border border-[#44403c] hover:border-stone-500 transition-all cursor-pointer group select-none" onClick={() => onChange(!checked)}>
        <span className="text-stone-400 text-xs font-bold uppercase tracking-wider group-hover:text-white transition-colors">{label}</span>
        <div className={`w-10 h-5 rounded-full relative transition-colors ${checked ? (color === 'amber' ? 'bg-amber-600' : 'bg-[#ce422b]') : 'bg-[#44403c]'}`}>
            <div className={`absolute top-1 left-1 w-3 h-3 bg-white rounded-full transition-transform ${checked ? 'translate-x-5' : 'translate-x-0'}`} />
        </div>
    </div>
);

const SettingSlider: React.FC<{ label: string; value: number; min: number; max: number; format?: (v: number) => string; onChange: (v: number) => void }> = ({ label, value, min, max, format, onChange }) => (
    <div className="bg-[#292524] p-4 border border-[#44403c]">
        <div className="flex justify-between items-end mb-3">
            <label className="text-stone-400 text-xs font-bold uppercase tracking-wider">{label}</label>
            <span className="text-[#ce422b] text-xs font-mono font-bold">{format ? format(value) : value}</span>
        </div>
        <input 
            type="range" 
            min={min} 
            max={max} 
            value={value} 
            onChange={(e) => onChange(Number(e.target.value))} 
            className="w-full h-1.5 bg-[#44403c] rounded-lg appearance-none cursor-pointer accent-[#ce422b] hover:accent-red-500 transition-all"
        />
    </div>
);

// --- END HELPERS ---

const ItemIcon: React.FC<{ item?: InventoryItem | null; type?: ItemType | EntityType; size?: string; hideDurability?: boolean }> = ({ item, type, size = "w-full h-full", hideDurability = false }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const typeToDraw = item?.type || type;
  
  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    if (!typeToDraw) { ctx.clearRect(0,0,canvas.width,canvas.height); return; }
    
    let animId: number;
    const render = (time: number) => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.save(); ctx.translate(canvas.width / 2, canvas.height / 2); ctx.scale(1.8, 1.8); 
      drawItemModel(ctx, typeToDraw as ItemType, time); 
      ctx.restore();
      animId = requestAnimationFrame(render);
    };
    animId = requestAnimationFrame(render); return () => cancelAnimationFrame(animId);
  }, [typeToDraw]);

  if (!typeToDraw) return null;

  return (
    <div className={`relative flex items-center justify-center rounded-lg overflow-hidden pointer-events-none w-full h-full`}>
      <canvas ref={canvasRef} width={64} height={64} className="w-full h-full p-2 opacity-90 object-contain" />
      {item && item.type === ItemType.BLUEPRINT && (
         <div className="absolute top-0 right-0 p-0.5 bg-blue-500 rounded-bl text-[6px] font-black text-white">BP</div>
      )}
      {item && item.durability !== undefined && item.maxDurability !== undefined && !hideDurability && (
        <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-[80%] h-1 bg-black/40 rounded-full overflow-hidden">
            <div className="h-full bg-emerald-500" style={{ width: `${(item.durability/item.maxDurability)*100}%` }} />
        </div>
      )}
    </div>
  );
};

const BuildWheel: React.FC<{ selectedType?: EntityType, onSelect: (type: EntityType) => void; onClose: () => void }> = ({ selectedType, onSelect, onClose }) => {
  const items = Object.entries(BUILDING_RECIPES);
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  return (
    <div className="fixed inset-0 z-[1000] pointer-events-auto flex items-center justify-center bg-black/60 backdrop-blur-[4px]" onClick={onClose}>
      <div className="relative w-[480px] h-[480px] rounded-full flex items-center justify-center" onClick={(e) => e.stopPropagation()}>
         <div className="absolute inset-0 rounded-full border-[70px] border-stone-900/95 shadow-2xl" />
         {items.map(([key, data], i) => {
            const angle = (i / items.length) * Math.PI * 2 - Math.PI / 2;
            const x = Math.cos(angle) * 180, y = Math.sin(angle) * 180;
            const isHovered = hoveredIdx === i, isSelected = selectedType === data.type;
            return (
              <div key={key} onMouseEnter={() => setHoveredIdx(i)} onMouseLeave={() => setHoveredIdx(null)} onClick={() => onSelect(data.type)} className={`absolute w-28 h-28 flex items-center justify-center transition-all cursor-pointer rounded-full z-20 ${isHovered ? 'scale-110' : 'scale-100'}`} style={{ left: '50%', top: '50%', transform: `translate(-50%, -50%) translate(${x}px, ${y}px)` }}>
                 <div className={`w-24 h-24 rounded-2xl border-4 flex flex-col items-center justify-center transition-all duration-200 ${isSelected ? 'bg-sky-600 border-sky-400' : (isHovered ? 'bg-stone-700 border-white/20' : 'bg-stone-800 border-white/5')}`}>
                    <div className="text-white text-[10px] font-black uppercase text-center leading-tight mb-1">{data.name}</div>
                    <div className="text-[7px] text-stone-400 font-bold uppercase">x{data.requirements[0].count} Wood</div>
                 </div>
              </div>
            );
         })}
      </div>
    </div>
  );
};

const UIOverlay: React.FC<Props> = ({ 
  gameState, remotePlayers, onCraftStart, onCraftStop, onMoveItem, onDropItem, onUseItem, serverPop = 1,
  onCloseUI, onOpenUI, onOpenSettings, onSelectBuilding, onLeaveServer, onConsoleCommand, onRespawn,
  onMoveToContainer, onTakeFromContainer, onUpdateSettings
}) => {
  const { player, uiOpen, notifications, screenShake, consoleHistory, craftingQueue, chunks, openedContainerId, team, settings } = gameState;
  const [activeTab, setActiveTab] = useState<'inventory' | 'crafting'>('inventory');
  const [settingsTab, setSettingsTab] = useState<'GRAPHICS' | 'AUDIO' | 'GAMEPLAY'>('GRAPHICS');
  const [consoleInput, setConsoleInput] = useState('');
  const [movingSlotIdx, setMovingSlotIdx] = useState<number | null>(null);
  const [containerMovingIdx, setContainerMovingIdx] = useState<number | null>(null); 
  
  const consoleScrollRef = useRef<HTMLDivElement>(null);
  const inventoryCounts = player.inventory.reduce((acc, it) => { if(it) acc[it.type] = (acc[it.type] || 0) + it.count; return acc; }, {} as Record<ItemType, number>);
  const [now, setNow] = useState(Date.now());

  let containerItems: (InventoryItem | null)[] = [];
  if (uiOpen === 'container' && openedContainerId) {
      Object.keys(chunks).forEach(key => {
          const ent = chunks[key].find(e => e.id === openedContainerId);
          if (ent && ent.containerItems) {
              containerItems = ent.containerItems;
          }
      });
  }

  // Calculate player's sleeping bags for respawn
  const playerSleepingBags: { id: string, pos: Vector2 }[] = [];
  Object.keys(chunks).forEach(key => {
      chunks[key].forEach(ent => {
          if (ent.type === EntityType.SLEEPING_BAG && ent.ownerId === player.playFabId) {
              playerSleepingBags.push({ id: ent.id, pos: ent.pos });
          }
      });
  });

  useEffect(() => { 
      if (consoleScrollRef.current) consoleScrollRef.current.scrollTop = consoleScrollRef.current.scrollHeight; 
  }, [consoleHistory]);

  useEffect(() => {
    const interval = setInterval(() => setNow(Date.now()), 200);
    return () => clearInterval(interval);
  }, []);

  const handleConsoleSubmit = (e: React.FormEvent) => { e.preventDefault(); if (!consoleInput.trim()) return; onConsoleCommand?.(consoleInput); setConsoleInput(''); };
  const isHoldingPlan = player.inventory[player.selectedHotbarIndex]?.type === ItemType.BUILDING_PLAN;
  const actionKeyDisplay = (settings.controls.ACTION || 'KeyE').replace('Key', '');

  const handleSlotClick = (index: number) => {
      if (movingSlotIdx === null) {
          if (player.inventory[index]) setMovingSlotIdx(index);
      } else {
          onMoveItem(movingSlotIdx, index);
          setMovingSlotIdx(null);
      }
  };

  const handleDragStart = (e: React.DragEvent, index: number, fromContainer: boolean = false) => {
      e.dataTransfer.setData("text/plain", JSON.stringify({ index, fromContainer }));
  };

  const handleDrop = (e: React.DragEvent, toIndex: number, toContainer: boolean = false) => {
      e.preventDefault();
      const data = JSON.parse(e.dataTransfer.getData("text/plain"));
      const fromIndex = data.index;
      const fromContainer = data.fromContainer;

      if (fromContainer && !toContainer) {
          onTakeFromContainer && onTakeFromContainer(fromIndex, toIndex);
      } else if (!fromContainer && toContainer) {
          onMoveToContainer && onMoveToContainer(fromIndex, toIndex);
      } else if (!fromContainer && !toContainer) {
          onMoveItem(fromIndex, toIndex);
      }
  };

  const handleDragOver = (e: React.DragEvent) => e.preventDefault();

  const handleSlotRightClick = (e: React.MouseEvent, index: number) => {
      e.preventDefault();
      if (e.shiftKey) {
          onDropItem(index);
      } else {
          const item = player.inventory[index];
          if (item) onUseItem(item.id);
      }
  };

  const handleContainerSlotClick = (containerSlot: number) => {
      if (movingSlotIdx !== null) {
          onMoveToContainer?.(movingSlotIdx, containerSlot);
          setMovingSlotIdx(null);
      } else if (containerMovingIdx !== null) {
          if (containerMovingIdx === containerSlot) setContainerMovingIdx(null);
          else setContainerMovingIdx(containerSlot);
      } else {
          if (containerItems[containerSlot]) setContainerMovingIdx(containerSlot);
      }
  };

  const handleInventoryClickWithContainerItem = (playerSlot: number) => {
      if (containerMovingIdx !== null) {
          onTakeFromContainer?.(containerMovingIdx, playerSlot);
          setContainerMovingIdx(null);
      } else if (movingSlotIdx !== null) {
          onMoveItem(movingSlotIdx, playerSlot);
          setMovingSlotIdx(null);
      } else {
          if (player.inventory[playerSlot]) setMovingSlotIdx(playerSlot);
      }
  };

  const visibleNotifications = notifications.filter(n => now - n.timestamp < 2000);
  const teammates = remotePlayers.filter(rp => team.includes(rp.id));

  const renderSlot = (item: InventoryItem | null, index: number, isContainer: boolean = false) => {
      const isSelected = isContainer ? containerMovingIdx === index : movingSlotIdx === index;
      const onClick = isContainer ? () => handleContainerSlotClick(index) : (e: any) => uiOpen === 'container' ? handleInventoryClickWithContainerItem(index) : (e.shiftKey ? onDropItem(index) : handleSlotClick(index));
      const onContextMenu = !isContainer ? (e: any) => handleSlotRightClick(e, index) : undefined;
      const itemName = item && ITEM_DATA[item.type] ? ITEM_DATA[item.type].name : 'Unknown Item';
      
      return (
        <div 
            key={index}
            onClick={onClick}
            onContextMenu={onContextMenu}
            draggable={!!item}
            onDragStart={(e) => handleDragStart(e, index, isContainer)}
            onDragOver={handleDragOver}
            onDrop={(e) => handleDrop(e, index, isContainer)}
            className={`aspect-square relative rounded-[18px] transition-all duration-100 flex items-center justify-center cursor-pointer group
                ${isSelected 
                    ? 'bg-green-500/10 border-2 border-green-500/50 shadow-[0_0_15px_rgba(34,197,94,0.2)]' 
                    : 'bg-[#27272a] hover:bg-[#3f3f46] border-2 border-transparent hover:border-white/10'
                }
            `}
        >
            <ItemIcon item={item} />
            {item && (
                <>
                    {item.count > 1 && (
                        <div className="absolute top-1 right-2 text-[10px] font-black text-white/90 drop-shadow-md">
                            {item.count}
                        </div>
                    )}
                    <div className="absolute inset-0 bg-black/80 text-white text-[10px] font-bold flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-[16px] z-20 pointer-events-none text-center p-1">
                        {itemName}
                    </div>
                </>
            )}
        </div>
      );
  };

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden select-none touch-none">
      {player.damageFlash && player.damageFlash > 0 && <div className="fixed inset-0 bg-red-600/10 z-[3000]" style={{ opacity: player.damageFlash / 10 }} />}
      {screenShake > 0 && settings.screenShakeEnabled && <style>{`#root { transform: translate(${(Math.random()-0.5)*screenShake}px, ${(Math.random()-0.5)*screenShake}px); }`}</style>}
      
      {/* DEATH SCREEN */}
      {uiOpen === 'respawn' && (
        <div className="fixed inset-0 bg-black/90 flex flex-col items-center justify-center z-[4000] pointer-events-auto backdrop-blur-md animate-in fade-in duration-1000">
           <h1 className="text-[6rem] md:text-[8rem] font-black text-red-600 tracking-tighter mb-4 drop-shadow-2xl select-none" style={{ textShadow: '0 0 40px rgba(220,38,38,0.5)' }}>YOU DIED</h1>
           <p className="text-stone-500 font-bold uppercase tracking-[0.3em] mb-16 text-sm">Deployment unit lost. Recalibrate biomass.</p>
           
           <div className="flex flex-col gap-6 w-full max-w-sm">
               <button 
                 onClick={() => onRespawn?.()} 
                 className="w-full bg-white text-black py-6 rounded-2xl font-black text-xl uppercase tracking-[0.2em] hover:scale-105 active:scale-95 transition-all shadow-[0_0_50px_rgba(255,255,255,0.1)]"
               >
                 Random Respawn
               </button>

               {playerSleepingBags.length > 0 && (
                   <div className="flex flex-col gap-3">
                       <div className="h-px bg-white/10 w-full my-2" />
                       <span className="text-[10px] font-black text-white/40 uppercase tracking-widest text-center">Available Sleeping Bags</span>
                       {playerSleepingBags.map((bag, i) => (
                           <button
                             key={bag.id}
                             onClick={() => onRespawn?.(bag.pos)}
                             className="w-full bg-green-600/20 hover:bg-green-600/40 text-green-500 border border-green-600/30 py-5 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3 transition-all"
                           >
                               <div className="w-4 h-4 bg-green-500/20 rounded flex items-center justify-center">
                                   <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                               </div>
                               Sleeping Bag #{i + 1}
                           </button>
                       ))}
                   </div>
               )}
           </div>
        </div>
      )}

      {/* TEAM HUD (Left Side) */}
      <div className="fixed top-48 left-8 flex flex-col gap-2 z-[700]" style={{ opacity: settings.hudOpacity / 100 }}>
          {teammates.map(tm => (
              <div key={tm.id} className="flex items-center gap-2 bg-black/40 backdrop-blur-sm p-2 rounded-lg border-l-2 border-green-500">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  <div className="flex flex-col">
                      <span className="text-white text-[10px] font-bold">{tm.id}</span>
                      <div className="w-16 h-1 bg-stone-700 rounded-full overflow-hidden">
                          <div className="h-full bg-green-500" style={{ width: `${tm.health}%` }} />
                      </div>
                  </div>
              </div>
          ))}
      </div>

      {uiOpen === 'build_wheel' && onSelectBuilding && <BuildWheel selectedType={player.selectedBuildingType} onSelect={onSelectBuilding} onClose={onCloseUI} />}
      
      {uiOpen === 'console' && (
        <div className="fixed top-0 left-0 w-full max-w-xl h-[400px] bg-black/90 border-r border-b border-white/10 p-6 z-[5000] pointer-events-auto font-mono text-[10px] flex flex-col">
          <div className="flex justify-between border-b border-white/10 pb-4 mb-4 text-stone-500 font-bold uppercase tracking-widest"><span>System Terminal</span><button onClick={onCloseUI}>✕</button></div>
          <div className="flex-1 overflow-y-auto mb-4 custom-scrollbar pr-4 text-stone-400" ref={consoleScrollRef}>{consoleHistory.map((line, i) => (<div key={i} className="mb-1">{line}</div>))}</div>
          <form onSubmit={handleConsoleSubmit} className="flex gap-4 items-center bg-white/5 p-3 rounded-lg"><span className="text-green-500">{'>'}</span><input type="text" value={consoleInput} onChange={(e)=>setConsoleInput(e.target.value)} className="flex-1 bg-transparent outline-none text-white" placeholder="Command..." /></form>
        </div>
      )}

      {/* NEW SETTINGS MENU */}
      {uiOpen === 'settings' && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[5000] pointer-events-auto backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-[800px] h-[600px] bg-[#1c1917] border border-[#44403c] flex shadow-2xl relative overflow-hidden rounded-xl">
              
              {/* Sidebar */}
              <div className="w-64 bg-[#0c0a09] border-r border-[#44403c] flex flex-col p-6">
                  <h2 className="text-4xl font-display text-white mb-8 tracking-tight drop-shadow-md">SETTINGS</h2>
                  
                  <nav className="flex flex-col gap-2">
                      {['GRAPHICS', 'AUDIO', 'GAMEPLAY'].map((tab) => (
                          <button 
                              key={tab}
                              onClick={() => setSettingsTab(tab as any)}
                              className={`text-left p-3 text-sm font-bold uppercase tracking-wider transition-all border-l-2 ${settingsTab === tab ? 'border-[#ce422b] text-white bg-white/5' : 'border-transparent text-[#78716c] hover:text-stone-300 hover:bg-white/5'}`}
                          >
                              {tab}
                          </button>
                      ))}
                  </nav>

                  <div className="mt-auto">
                      <button onClick={onLeaveServer} className="w-full py-3 bg-red-900/10 hover:bg-red-900/30 text-red-500 border border-red-900/30 font-bold uppercase text-xs tracking-widest transition-all">
                          Disconnect
                      </button>
                  </div>
              </div>

              {/* Content */}
              <div className="flex-1 p-8 overflow-y-auto custom-scrollbar bg-[#1c1917]">
                  <div className="flex justify-between items-center mb-8 pb-4 border-b border-[#44403c]">
                      <h3 className="text-2xl font-display text-[#ce422b] tracking-wide">{settingsTab}</h3>
                      <button onClick={onCloseUI} className="text-stone-500 hover:text-white font-bold text-xl hover:scale-110 transition-transform">✕</button>
                  </div>

                  <div className="space-y-6">
                      {/* Render content based on activeTab */}
                      {settingsTab === 'GRAPHICS' && (
                          <>
                              {/* Ultra Mode Banner */}
                              <div className="bg-gradient-to-r from-amber-900/20 to-transparent border border-amber-900/30 p-4 rounded mb-6 flex justify-between items-center">
                                  <div>
                                      <div className="text-amber-500 font-bold uppercase text-xs tracking-widest mb-1">Visual Fidelity</div>
                                      <div className="text-white font-display text-xl">Ultra Graphics Mode</div>
                                  </div>
                                  <SettingToggle 
                                      label="Enable" 
                                      checked={settings.ultraMode} 
                                      onChange={(v) => {
                                          if (v) {
                                              // Preset: Ultra (High Quality)
                                              onUpdateSettings({ 
                                                  ultraMode: true, 
                                                  lowPerformance: false,
                                                  shadowsEnabled: true,
                                                  particles: 'High',
                                                  viewBobbing: true,
                                                  shimmerEnabled: true
                                              });
                                          } else {
                                              onUpdateSettings({ ultraMode: false });
                                          }
                                      }} 
                                      color="amber" 
                                  />
                              </div>

                              {/* Sliders */}
                              <SettingSlider label="Render Distance" value={settings.renderDistance || 2} min={1} max={6} format={(v) => `${v} Chunks`} onChange={(v) => onUpdateSettings({ renderDistance: v })} />
                              <SettingSlider label="Vignette Intensity" value={settings.vignetteStrength} min={0} max={100} format={(v) => `${v}%`} onChange={(v) => onUpdateSettings({ vignetteStrength: v })} />
                              <SettingSlider label="HUD Opacity" value={settings.hudOpacity} min={20} max={100} format={(v) => `${v}%`} onChange={(v) => onUpdateSettings({ hudOpacity: v })} />

                              <div className="h-px bg-[#44403c] my-6" />

                              {/* Toggles Grid */}
                              <div className="grid grid-cols-2 gap-4">
                                  <SettingToggle label="Retro Mode" checked={settings.retroMode} onChange={(v) => onUpdateSettings({ retroMode: v })} />
                                  <SettingToggle label="Scanlines" checked={settings.scanlinesEnabled} onChange={(v) => onUpdateSettings({ scanlinesEnabled: v })} />
                                  <SettingToggle label="Screen Shake" checked={settings.screenShakeEnabled} onChange={(v) => onUpdateSettings({ screenShakeEnabled: v })} />
                                  <SettingToggle label="View Bobbing" checked={settings.viewBobbing} onChange={(v) => onUpdateSettings({ viewBobbing: v })} />
                                  <SettingToggle label="Shadows" checked={settings.shadowsEnabled} onChange={(v) => onUpdateSettings({ shadowsEnabled: v })} />
                                  
                                  <SettingToggle 
                                      label="Low Performance" 
                                      checked={settings.lowPerformance} 
                                      onChange={(v) => {
                                          if (v) {
                                              // Preset: Low Perf (FPS Boost)
                                              onUpdateSettings({ 
                                                  lowPerformance: true, 
                                                  ultraMode: false,
                                                  shadowsEnabled: false,
                                                  particles: 'Low',
                                                  shimmerEnabled: false
                                              });
                                          } else {
                                              onUpdateSettings({ lowPerformance: false });
                                          }
                                      }} 
                                  />
                              </div>
                          </>
                      )}

                      {settingsTab === 'AUDIO' && (
                          <>
                              <div className="space-y-4">
                                <SettingSlider label="Master Volume" value={settings.volume} min={0} max={100} onChange={(v) => onUpdateSettings({ volume: v })} />
                                <SettingSlider label="Music Volume" value={settings.musicVolume} min={0} max={100} onChange={(v) => onUpdateSettings({ musicVolume: v })} />
                                <SettingSlider label="Ambience Volume" value={settings.ambienceVolume} min={0} max={100} onChange={(v) => onUpdateSettings({ ambienceVolume: v })} />
                              </div>
                          </>
                      )}

                      {settingsTab === 'GAMEPLAY' && (
                          <>
                              <div className="mb-6">
                                  <label className="text-xs font-bold text-stone-500 uppercase tracking-wider block mb-2">Crosshair Style</label>
                                  <div className="flex gap-2">
                                      {(['dot', 'cross', 'circle'] as const).map(style => (
                                          <button 
                                              key={style}
                                              onClick={() => onUpdateSettings({ crosshairStyle: style })}
                                              className={`flex-1 py-3 text-xs font-bold uppercase tracking-widest border transition-all ${settings.crosshairStyle === style ? 'bg-stone-200 text-black border-white' : 'bg-transparent text-stone-500 border-[#44403c] hover:border-stone-400 hover:text-stone-300'}`}
                                          >
                                              {style}
                                          </button>
                                      ))}
                                  </div>
                              </div>

                              <div className="grid grid-cols-1 gap-4">
                                  <SettingToggle label="Auto Sprint" checked={settings.autoSprint} onChange={(v) => onUpdateSettings({ autoSprint: v })} />
                                  <SettingToggle label="Streamer Mode" checked={settings.streamerMode} onChange={(v) => onUpdateSettings({ streamerMode: v })} />
                                  <SettingToggle label="Show Names" checked={settings.showNames} onChange={(v) => onUpdateSettings({ showNames: v })} />
                                  <SettingToggle label="Show FPS" checked={settings.showFPS} onChange={(v) => onUpdateSettings({ showFPS: v })} />
                                  <SettingToggle label="Show Coordinates" checked={settings.showCoords} onChange={(v) => onUpdateSettings({ showCoords: v })} />
                              </div>
                          </>
                      )}
                  </div>
              </div>
          </div>
        </div>
      )}

      {/* MAIN HUD */}
      {!uiOpen && (
        <div style={{ opacity: settings.hudOpacity / 100 }}>
            {/* Hotbar */}
            <div className="fixed bottom-6 left-1/2 -translate-x-1/2 flex gap-2 p-2 bg-stone-900/60 backdrop-blur-md rounded-2xl border border-white/5 z-[800]">
                {player.inventory.slice(0, 6).map((item, i) => (
                    <div 
                        key={i}
                        className={`w-14 h-14 rounded-xl border-2 flex items-center justify-center relative transition-all ${player.selectedHotbarIndex === i ? 'border-white bg-white/10 scale-110 shadow-lg' : 'border-stone-700 bg-stone-800/50'}`}
                    >
                        {i === player.selectedHotbarIndex && <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-white rounded-full" />}
                        <ItemIcon item={item} />
                        {item && item.count > 1 && <span className="absolute bottom-1 right-1 text-[10px] font-bold text-white shadow-black drop-shadow-md">{item.count}</span>}
                        <span className="absolute top-1 left-1.5 text-[8px] font-black text-white/30">{i + 1}</span>
                    </div>
                ))}
            </div>

            {/* NEW RUST-LIKE HEALTH STATS */}
            <div className="fixed bottom-6 right-6 flex flex-col gap-2 z-[800] w-72 font-sans select-none pointer-events-none">
                
                {/* Health Segment */}
                <div className="flex items-center gap-3 bg-[#1c1917]/90 p-2 rounded-md border border-white/10 shadow-lg backdrop-blur-md">
                    <div className="flex flex-col items-center justify-center w-10">
                        <span className="text-[#84cc16] text-xl">✚</span>
                    </div>
                    <div className="flex-1 flex flex-col gap-1">
                        <div className="flex justify-between items-end">
                            <span className="text-[10px] font-bold text-stone-400 uppercase tracking-widest">Health</span>
                            <span className="text-lg font-black text-white leading-none">{Math.ceil(player.health)}</span>
                        </div>
                        <div className="w-full h-2.5 bg-black/50 rounded overflow-hidden">
                            <div className="h-full bg-gradient-to-r from-[#65a30d] to-[#84cc16] transition-all duration-300" style={{ width: `${player.health}%` }} />
                        </div>
                    </div>
                </div>

                <div className="flex gap-2">
                    {/* Hunger Segment */}
                    <div className="flex-1 flex items-center gap-2 bg-[#1c1917]/90 p-2 rounded-md border border-white/10 shadow-lg backdrop-blur-md">
                        <span className="text-[#f97316] text-sm">🍖</span>
                        <div className="flex-1 flex flex-col gap-1">
                            <div className="flex justify-between items-end">
                                <span className="text-sm font-bold text-white leading-none">{Math.ceil(player.hunger)}</span>
                            </div>
                            <div className="w-full h-1.5 bg-black/50 rounded overflow-hidden">
                                <div className="h-full bg-[#f97316] transition-all duration-300" style={{ width: `${player.hunger}%` }} />
                            </div>
                        </div>
                    </div>

                    {/* Thirst Segment */}
                    <div className="flex-1 flex items-center gap-2 bg-[#1c1917]/90 p-2 rounded-md border border-white/10 shadow-lg backdrop-blur-md">
                        <span className="text-[#0ea5e9] text-sm">💧</span>
                        <div className="flex-1 flex flex-col gap-1">
                            <div className="flex justify-between items-end">
                                <span className="text-sm font-bold text-white leading-none">{Math.ceil(player.thirst)}</span>
                            </div>
                            <div className="w-full h-1.5 bg-black/50 rounded overflow-hidden">
                                <div className="h-full bg-[#0ea5e9] transition-all duration-300" style={{ width: `${player.thirst}%` }} />
                            </div>
                        </div>
                    </div>
                </div>

                {/* Stamina - Only visible if not full */}
                <div className={`transition-opacity duration-500 ${player.stamina < 98 ? 'opacity-100' : 'opacity-0'}`}>
                     <div className="w-full h-1 bg-black/50 rounded-full overflow-hidden">
                        <div className="h-full bg-[#eab308]" style={{ width: `${player.stamina}%` }} />
                     </div>
                </div>

            </div>

            {isHoldingPlan && (
                <div className="fixed top-24 left-1/2 -translate-x-1/2 bg-black/50 text-white px-4 py-2 rounded-full text-xs font-bold backdrop-blur">
                    [R] ROTATE | [{actionKeyDisplay}] PLACE | [B] MENU
                </div>
            )}
            <div className="fixed top-4 right-4 text-xs font-mono text-white/30 flex flex-col items-end gap-1">
                {!settings.streamerMode && settings.showCoords && <span>{Math.round(player.pos.x)}, {Math.round(player.pos.y)}</span>}
                <button onClick={onOpenUI} className="hover:text-white transition-colors">[TAB] INVENTORY</button>
                <button onClick={onOpenSettings} className="hover:text-white transition-colors">[X] SETTINGS</button>
                {settings.showFPS && <span className="text-green-500">60 FPS</span>}
            </div>
            
            <div className="fixed top-8 left-1/2 -translate-x-1/2 flex flex-col gap-1 items-center pointer-events-none z-[2000]">
                {visibleNotifications.map(n => {
                    const data = ITEM_DATA[n.type];
                    if (!data) return null;
                    
                    return (
                        <div key={n.id} className="bg-black/60 text-white px-4 py-1.5 rounded-full text-xs font-bold backdrop-blur-md border border-white/10 animate-in slide-in-from-top-4 fade-in duration-300 flex items-center gap-2">
                            <span className="text-green-400">+ {n.count}</span>
                            <span className="uppercase tracking-wider">{data.name}</span>
                        </div>
                    );
                })}
            </div>
        </div>
      )}

      {(uiOpen === 'inv' || uiOpen === 'container') && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-[1500] pointer-events-auto backdrop-blur-sm p-4 animate-in fade-in zoom-in-95 duration-200">
             <div className="flex gap-6 items-start h-full max-h-[700px]">
                 
                 <div className="bg-[#0f0f10] border border-white/5 p-6 rounded-[32px] w-[500px] flex flex-col shadow-2xl h-full relative overflow-hidden">
                     <div className="flex justify-between items-center mb-6 px-1">
                         <h2 className="text-xl font-black text-white tracking-widest uppercase opacity-80">Inventory</h2>
                         <div className="flex gap-2">
                             <button onClick={() => setActiveTab('inventory')} className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'inventory' ? 'bg-white text-black' : 'bg-[#27272a] text-stone-500 hover:text-white'}`}>Items</button>
                             <button onClick={() => setActiveTab('crafting')} className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'crafting' ? 'bg-white text-black' : 'bg-[#27272a] text-stone-500 hover:text-white'}`}>Craft</button>
                         </div>
                     </div>

                     {activeTab === 'inventory' ? (
                         <div className="flex-1 overflow-y-auto custom-scrollbar px-1">
                             <div className="mb-4">
                                <div className="text-[9px] font-black text-stone-600 uppercase tracking-widest mb-2 ml-1">Belt</div>
                                <div className="grid grid-cols-6 gap-3">
                                    {player.inventory.slice(0, 6).map((item, i) => renderSlot(item, i))}
                                </div>
                             </div>
                             
                             <div className="h-px bg-white/5 my-4" />

                             <div className="mb-4">
                                <div className="text-[9px] font-black text-stone-600 uppercase tracking-widest mb-2 ml-1">Backpack</div>
                                <div className="grid grid-cols-6 gap-3">
                                    {player.inventory.slice(6).map((item, i) => renderSlot(item, i + 6))}
                                </div>
                             </div>
                             
                             <div className="mt-8 bg-[#18181b] rounded-2xl p-4 flex justify-around">
                                 <div className="text-center">
                                     <div className="text-[9px] text-stone-500 uppercase font-black">Health</div>
                                     <div className="text-green-500 font-bold">{Math.round(player.health)}</div>
                                 </div>
                                 <div className="text-center">
                                     <div className="text-[9px] text-stone-500 uppercase font-black">Food</div>
                                     <div className="text-amber-500 font-bold">{Math.round(player.hunger)}</div>
                                 </div>
                                 <div className="text-center">
                                     <div className="text-[9px] text-stone-500 uppercase font-black">Water</div>
                                     <div className="text-sky-500 font-bold">{Math.round(player.thirst)}</div>
                                 </div>
                             </div>
                         </div>
                     ) : (
                         <div className="flex-1 flex flex-col overflow-hidden px-1">
                             <div className="overflow-y-auto custom-scrollbar pr-2 space-y-2">
                                 {RECIPES.map(recipe => {
                                     const canCraft = recipe.requirements.every(r => (inventoryCounts[r.type] || 0) >= r.count);
                                     const isLocked = recipe.blueprintRequired && !player.unlockedBlueprints.includes(recipe.id);
                                     
                                     return (
                                         <button 
                                            key={recipe.id} 
                                            onClick={() => !isLocked && canCraft && onCraftStart(recipe.id)}
                                            disabled={isLocked || !canCraft}
                                            className={`w-full p-3 rounded-2xl flex items-center gap-4 transition-all border ${isLocked ? 'bg-red-900/10 border-red-900/20 opacity-60 grayscale' : (canCraft ? 'bg-[#27272a] border-[#3f3f46] hover:bg-[#3f3f46]' : 'bg-[#18181b] border-transparent opacity-50')}`}
                                         >
                                             <div className="w-10 h-10 bg-black/20 rounded-xl flex items-center justify-center">
                                                 <ItemIcon type={recipe.output as ItemType} size="w-6 h-6" />
                                             </div>
                                             <div className="flex-1 text-left">
                                                 <div className="text-xs font-bold text-white flex items-center gap-2">
                                                     {recipe.name}
                                                     {isLocked && <span className="text-[8px] bg-red-500 text-black px-1.5 rounded font-black">LOCKED</span>}
                                                 </div>
                                                 <div className="flex gap-2 mt-1 flex-wrap">
                                                     {recipe.requirements.map(req => (
                                                         <span key={req.type} className={`text-[8px] font-bold uppercase ${inventoryCounts[req.type] >= req.count ? 'text-emerald-500' : 'text-red-500'}`}>
                                                             {req.count} {ITEM_DATA[req.type]?.name || 'Unknown'}
                                                         </span>
                                                     ))}
                                                 </div>
                                             </div>
                                             {craftingQueue.some(q => q.recipeId === recipe.id) && (
                                                 <div className="w-4 h-4 rounded-full border-2 border-green-500 border-t-transparent animate-spin" />
                                             )}
                                         </button>
                                     );
                                 })}
                             </div>
                         </div>
                     )}
                 </div>

                 {uiOpen === 'container' && (
                     <div className="bg-[#0f0f10] border border-white/5 p-6 rounded-[32px] w-[500px] flex flex-col shadow-2xl h-full relative">
                         <div className="flex justify-between items-center mb-6 px-1">
                             <h2 className="text-xl font-black text-white tracking-widest uppercase opacity-80">Storage</h2>
                             <button onClick={onCloseUI} className="text-stone-500 hover:text-white transition-colors">✕</button>
                         </div>
                         <div className="flex-1 px-1">
                             <div className="grid grid-cols-6 gap-3">
                                 {containerItems.map((item, i) => renderSlot(item, i, true))}
                                 {Array.from({ length: Math.max(0, 30 - containerItems.length) }).map((_, i) => (
                                     <div key={`placeholder-${i}`} className="aspect-square rounded-[18px] bg-[#18181b] border-2 border-transparent opacity-50" />
                                 ))}
                             </div>
                         </div>
                         <div className="mt-auto pt-6 text-center text-[10px] text-stone-600 font-bold uppercase tracking-widest">
                             Shift-Click to move items quickly
                         </div>
                     </div>
                 )}
                 
                 {uiOpen !== 'container' && (
                    <button onClick={onCloseUI} className="absolute top-10 right-10 w-12 h-12 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center text-white transition-all backdrop-blur">
                        ✕
                    </button>
                 )}
             </div>
        </div>
      )}
    </div>
  );
};

export default UIOverlay;
