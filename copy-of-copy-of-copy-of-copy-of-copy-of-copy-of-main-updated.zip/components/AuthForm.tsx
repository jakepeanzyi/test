
import React, { useState, useEffect } from 'react';
import { playFab, PlayFabUser } from '../services/playfabService';

interface Props {
  onSuccess: (user: PlayFabUser) => void;
  initialMode?: 'login' | 'register';
  onClose?: () => void;
}

const AuthForm: React.FC<Props> = ({ onSuccess, initialMode = 'login', onClose }) => {
  const [isRegistering, setIsRegistering] = useState(initialMode === 'register');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setIsRegistering(initialMode === 'register');
  }, [initialMode]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      let user;
      if (isRegistering) {
        user = await playFab.register(email, password, username);
      } else {
        user = await playFab.login(email, password);
      }
      onSuccess(user);
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-[2000] animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-[#1c1917] border border-[#44403c] shadow-2xl p-0">
        
        {/* Header */}
        <div className="bg-[#292524] p-4 flex justify-between items-center border-b border-[#44403c]">
            <h2 className="text-2xl font-display tracking-wide text-white uppercase">
                {isRegistering ? 'Create Identity' : 'Authenticate'}
            </h2>
            <button onClick={onClose} className="text-[#78716c] hover:text-white font-bold text-xl leading-none">✕</button>
        </div>

        <div className="p-8 space-y-6">
            {error && (
                <div className="bg-red-900/20 border-l-4 border-[#ce422b] p-3 text-red-200 text-sm font-bold">
                    {error}
                </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
                {isRegistering && (
                    <div className="space-y-1">
                        <label className="text-xs text-[#a8a29e] font-bold uppercase tracking-wider block">Username</label>
                        <input 
                            type="text" 
                            required
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            className="w-full bg-[#0c0a09] border border-[#44403c] text-white p-3 text-sm focus:border-[#ce422b] focus:outline-none transition-colors placeholder-[#44403c] font-sans"
                            placeholder="Survivor Name"
                        />
                    </div>
                )}

                <div className="space-y-1">
                    <label className="text-xs text-[#a8a29e] font-bold uppercase tracking-wider block">Email Address</label>
                    <input 
                        type="text" 
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-[#0c0a09] border border-[#44403c] text-white p-3 text-sm focus:border-[#ce422b] focus:outline-none transition-colors placeholder-[#44403c] font-sans"
                        placeholder="user@rust.net"
                    />
                </div>

                <div className="space-y-1">
                    <label className="text-xs text-[#a8a29e] font-bold uppercase tracking-wider block">Password</label>
                    <input 
                        type="password" 
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full bg-[#0c0a09] border border-[#44403c] text-white p-3 text-sm focus:border-[#ce422b] focus:outline-none transition-colors placeholder-[#44403c] font-sans"
                        placeholder="••••••••"
                    />
                </div>

                <div className="pt-4 flex flex-col gap-3">
                    <button 
                        type="submit" 
                        disabled={loading}
                        className="w-full bg-[#ce422b] hover:bg-[#b91c1c] text-white font-display text-xl tracking-wide py-3 uppercase transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
                    >
                        {loading ? 'CONNECTING...' : (isRegistering ? 'REGISTER' : 'LOGIN')}
                    </button>
                    
                    <button 
                        type="button"
                        onClick={() => { setIsRegistering(!isRegistering); setError(null); }}
                        className="text-xs text-[#78716c] hover:text-white uppercase tracking-widest font-bold transition-colors text-center py-2"
                    >
                        {isRegistering ? 'Already have an account?' : 'Create a new account'}
                    </button>
                </div>
            </form>
        </div>
      </div>
    </div>
  );
};

export default AuthForm;
