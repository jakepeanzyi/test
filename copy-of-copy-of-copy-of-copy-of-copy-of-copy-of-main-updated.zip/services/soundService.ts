
import { Vector2 } from "../types";

class SoundService {
  private ctx: AudioContext | null = null;
  private weatherSource: AudioWorkletNode | OscillatorNode | AudioBufferSourceNode | null = null;
  private weatherGain: GainNode | null = null;
  private weatherFilter: BiquadFilterNode | null = null;
  private currentWeather: string = 'CLEAR';

  private ambienceSource: OscillatorNode | AudioBufferSourceNode | null = null;
  private ambienceGain: GainNode | null = null;
  private currentAmbience: string = '';

  private init() {
    if (this.ctx) return;
    this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    this.weatherGain = this.ctx.createGain();
    this.weatherFilter = this.ctx.createBiquadFilter();
    this.weatherGain.gain.value = 0;
    this.weatherGain.connect(this.ctx.destination);
    this.weatherFilter.connect(this.weatherGain);

    this.ambienceGain = this.ctx.createGain();
    this.ambienceGain.gain.value = 0;
    this.ambienceGain.connect(this.ctx.destination);
  }

  private createNoiseBuffer() {
    if (!this.ctx) return null;
    const bufferSize = this.ctx.sampleRate * 2;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    return buffer;
  }

  // Spatial Audio Helper
  private applySpatial(sourceNode: AudioNode, sourcePos: Vector2, listenerPos: Vector2) {
    if (!this.ctx) return;
    const panner = this.ctx.createStereoPanner();
    const gain = this.ctx.createGain();

    const dx = sourcePos.x - listenerPos.x;
    const dy = sourcePos.y - listenerPos.y;
    const dist = Math.sqrt(dx*dx + dy*dy);
    
    // Simple 2D Panning based on screen width approx (1000px)
    const pan = Math.max(-1, Math.min(1, dx / 800));
    panner.pan.value = pan;

    // Distance attenuation
    const maxDist = 1200;
    const vol = Math.max(0, 1 - dist / maxDist);
    gain.gain.value = vol * vol; // Square falloff for better feel

    sourceNode.connect(panner);
    panner.connect(gain);
    gain.connect(this.ctx.destination);
    
    return { panner, gain };
  }

  public playHarvest(type: 'WOOD' | 'STONE' | 'FIBER', sourcePos?: Vector2, listenerPos?: Vector2) {
    this.init();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    
    // If spatial data provided, create separate chain, otherwise use main destination
    let dest: AudioNode = this.ctx.destination;
    let spatialGain: GainNode | null = null;
    
    // Create base gain for envelope
    const envGain = this.ctx.createGain();

    if (sourcePos && listenerPos) {
        const spatial = this.applySpatial(envGain, sourcePos, listenerPos);
        if (spatial) {
             const panner = this.ctx.createStereoPanner();
             const distGain = this.ctx.createGain();
             
             const dx = sourcePos.x - listenerPos.x;
             const dy = sourcePos.y - listenerPos.y;
             const dist = Math.sqrt(dx*dx + dy*dy);
             
             panner.pan.value = Math.max(-1, Math.min(1, dx / 800));
             const vol = Math.max(0, 1 - dist / 1200);
             distGain.gain.value = vol * vol;

             envGain.connect(panner);
             panner.connect(distGain);
             distGain.connect(this.ctx.destination);
        } else {
             envGain.connect(this.ctx.destination);
        }
    } else {
        envGain.connect(this.ctx.destination);
    }

    if (type === 'WOOD') {
      const osc = this.ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(120, now);
      osc.frequency.exponentialRampToValueAtTime(40, now + 0.1);
      envGain.gain.setValueAtTime(0.15, now);
      envGain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      osc.connect(envGain);
      osc.start(now);
      osc.stop(now + 0.15);
    } else if (type === 'STONE') {
      const osc = this.ctx.createOscillator();
      osc.type = 'square';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(400, now + 0.05);
      envGain.gain.setValueAtTime(0.08, now);
      envGain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
      osc.connect(envGain);
      osc.start(now);
      osc.stop(now + 0.08);
    } else if (type === 'FIBER') {
      const buffer = this.createNoiseBuffer();
      if (buffer) {
        const source = this.ctx.createBufferSource();
        source.buffer = buffer;
        const filter = this.ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.value = 1500;
        source.connect(filter);
        filter.connect(envGain);
        envGain.gain.setValueAtTime(0.05, now);
        envGain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
        source.start(now);
        source.stop(now + 0.1);
      }
    }
  }

  public updateAmbience(biome: string, time: number, volume: number = 0.5) {
    this.init();
    if (!this.ctx || !this.ambienceGain) return;

    const now = this.ctx.currentTime;
    const dayCycle = time / 24000;
    const isNight = dayCycle < 0.2 || dayCycle > 0.8;
    const ambienceKey = `${biome}_${isNight ? 'NIGHT' : 'DAY'}`;

    if (this.currentAmbience === ambienceKey) {
        // Just update volume
        const targetGain = volume * 0.15;
        this.ambienceGain.gain.setTargetAtTime(targetGain, now, 1);
        return;
    }
    this.currentAmbience = ambienceKey;

    if (this.ambienceSource) {
      try { (this.ambienceSource as any).stop(); } catch (e) {}
      this.ambienceSource = null;
    }

    const targetGain = volume * 0.15;
    this.ambienceGain.gain.setTargetAtTime(targetGain, now, 3);

    // Use gentle noise for all biomes instead of harsh oscillators
    const buffer = this.createNoiseBuffer();
    if (!buffer) return;

    const source = this.ctx.createBufferSource();
    source.buffer = buffer;
    source.loop = true;
    const filter = this.ctx.createBiquadFilter();
    
    // Configure filter based on biome to shape the wind/ambience noise
    if (biome === 'FOREST') {
        filter.type = 'lowpass';
        // Lower frequency for wind through trees, slightly higher at night for "air" feel
        filter.frequency.value = isNight ? 600 : 800; 
        
        // Add subtle LFO for wind swelling
        const lfo = this.ctx.createOscillator();
        const lfoGain = this.ctx.createGain();
        lfo.frequency.value = 0.1; // Slow wind
        lfoGain.gain.value = 200;
        lfo.connect(lfoGain);
        lfoGain.connect(filter.frequency);
        lfo.start();
    } else if (biome === 'DESERT' || biome === 'SNOW') {
        filter.type = 'lowpass';
        // Reduced frequency to remove harsh hiss, added resonance for howling wind
        filter.frequency.value = biome === 'SNOW' ? 300 : 250; 
        filter.Q.value = 2; // Resonance for wind howl
        
        const lfo = this.ctx.createOscillator();
        const lfoGain = this.ctx.createGain();
        lfo.frequency.value = 0.05;
        lfoGain.gain.value = 100;
        lfo.connect(lfoGain);
        lfoGain.connect(filter.frequency);
        lfo.start();
    } else {
        // GRASSLANDS
        filter.type = 'lowpass';
        filter.frequency.value = 700;
    }

    source.connect(filter);
    filter.connect(this.ambienceGain);
    source.start(now);
    this.ambienceSource = source;
  }

  public updateWeather(type: string, volume: number = 0.5) {
    this.init();
    if (!this.ctx || !this.weatherGain || !this.weatherFilter) return;

    if (this.currentWeather === type) {
        // Just update volume
        const targetGain = type === 'CLEAR' ? 0 : volume * 0.2;
        this.weatherGain.gain.setTargetAtTime(targetGain, this.ctx.currentTime, 1);
        return;
    }
    this.currentWeather = type;

    if (this.weatherSource) {
      try { (this.weatherSource as any).stop(); } catch(e) {}
      this.weatherSource = null;
    }

    const targetGain = type === 'CLEAR' ? 0 : volume * 0.2;
    this.weatherGain.gain.setTargetAtTime(targetGain, this.ctx.currentTime, 2);

    if (type === 'RAIN') {
      const buffer = this.createNoiseBuffer();
      if (!buffer) return;
      const source = this.ctx.createBufferSource();
      source.buffer = buffer;
      source.loop = true;
      this.weatherFilter.type = 'lowpass';
      this.weatherFilter.frequency.value = 800; // Lowered from 2000 for softer rain
      source.connect(this.weatherFilter);
      source.start();
      this.weatherSource = source;
    } else if (type === 'FOG') {
      const source = this.ctx.createOscillator();
      source.type = 'sine';
      source.frequency.value = 60; 
      const lfo = this.ctx.createOscillator();
      const lfoGain = this.ctx.createGain();
      lfo.frequency.value = 0.5;
      lfoGain.gain.value = 10;
      lfo.connect(lfoGain);
      lfoGain.connect(source.frequency);
      lfo.start();
      this.weatherFilter.type = 'lowpass';
      this.weatherFilter.frequency.value = 400;
      source.connect(this.weatherFilter);
      source.start();
      this.weatherSource = source;
    }
  }

  public playFootstep(biome: string, speed: number, sourcePos?: Vector2, listenerPos?: Vector2) {
    this.init();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const envGain = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();

    // SPATIAL ROUTING
    if (sourcePos && listenerPos) {
         const panner = this.ctx.createStereoPanner();
         const distGain = this.ctx.createGain();
         
         const dx = sourcePos.x - listenerPos.x;
         const dy = sourcePos.y - listenerPos.y;
         const dist = Math.sqrt(dx*dx + dy*dy);
         
         panner.pan.value = Math.max(-1, Math.min(1, dx / 800));
         const vol = Math.max(0, 1 - dist / 800);
         distGain.gain.value = vol * vol;

         envGain.connect(panner);
         panner.connect(distGain);
         distGain.connect(this.ctx.destination);
    } else {
        envGain.connect(this.ctx.destination);
    }
    
    filter.connect(envGain);

    const now = this.ctx.currentTime;
    envGain.gain.setValueAtTime(0.05, now);
    envGain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);

    if (biome === 'SNOW') {
      filter.type = 'highpass';
      filter.frequency.value = 3000;
      const noise = this.ctx.createBufferSource();
      noise.buffer = this.createNoiseBuffer();
      noise.connect(filter);
      noise.start(now);
      noise.stop(now + 0.1);
    } else if (biome === 'DESERT') {
      filter.type = 'lowpass';
      filter.frequency.value = 800;
      osc.type = 'sine';
      osc.frequency.setValueAtTime(100, now);
      osc.frequency.exponentialRampToValueAtTime(40, now + 0.1);
      osc.connect(filter);
      osc.start(now);
      osc.stop(now + 0.1);
    } else {
      filter.type = 'bandpass';
      filter.frequency.value = 1200;
      const noise = this.ctx.createBufferSource();
      noise.buffer = this.createNoiseBuffer();
      noise.connect(filter);
      noise.start(now);
      noise.stop(now + 0.1);
    }
  }
}

export const soundService = new SoundService();