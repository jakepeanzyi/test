
import { PlayerCustomization, ChatMessage } from "../types";
import { moderateChat } from "./geminiService";
import { db } from "../firebase";
import { ref, push, update, onValue, query, limitToLast, get } from "firebase/database";

export const saveCustomization = async (userId: string, customization: PlayerCustomization) => {
  try {
    const playerRef = ref(db, `players/${userId}/public`);
    await update(playerRef, {
      customization,
      lastUpdate: Date.now()
    });
    // Also save to storage for persistence
    await update(ref(db, `players/${userId}/storage`), {
        customization: JSON.stringify(customization)
    });
  } catch (error) {
    console.error("Failed to save customization:", error);
  }
};

export const getCustomization = async (userId: string): Promise<PlayerCustomization | null> => {
  try {
    const snapshot = await get(ref(db, `players/${userId}/public/customization`));
    return snapshot.val();
  } catch (error) {
    return null;
  }
};

export const sendTrollBoxMessage = async (userId: string, username: string, text: string) => {
  const modResult = await moderateChat(text);
  if (modResult.isToxic) {
    return { error: "Message blocked." };
  }

  try {
    const chatRef = ref(db, 'trollbox');
    await push(chatRef, {
      userId,
      username,
      text,
      timestamp: Date.now()
    });
  } catch (error) {
    console.error("Firebase Chat Error:", error);
    return { error: "Radio signal failed." };
  }
};

export const subscribeToTrollBox = (callback: (messages: ChatMessage[]) => void) => {
  const chatQuery = query(ref(db, 'trollbox'), limitToLast(50));
  
  const unsubscribe = onValue(chatQuery, (snapshot) => {
    const messages: ChatMessage[] = [];
    snapshot.forEach((child) => {
      const data = child.val();
      messages.push({
        id: child.key as string,
        userId: data.userId,
        username: data.username,
        text: data.text,
        timestamp: data.timestamp
      });
    });
    callback(messages);
  });

  return unsubscribe;
};
