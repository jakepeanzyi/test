
import { db } from "../firebase";
import { ref, update, get, onValue } from "firebase/database";
import { FriendRelation } from "../types";

// We store relations at players/{userId}/relations/{targetId} = { ... }

export const addFriend = async (userId: string, targetId: string, targetUsername: string) => {
  const relRef = ref(db, `players/${userId}/relations/${targetId}`);
  await update(relRef, {
      userId: targetId,
      username: targetUsername,
      status: 'friend'
  });
};

export const blockUser = async (userId: string, targetId: string, targetUsername: string) => {
  const relRef = ref(db, `players/${userId}/relations/${targetId}`);
  await update(relRef, {
      userId: targetId,
      username: targetUsername,
      status: 'blocked'
  });
};

export const removeRelation = async (userId: string, relation: FriendRelation) => {
    const updates: any = {};
    updates[`players/${userId}/relations/${relation.userId}`] = null;
    await update(ref(db), updates);
};

export const subscribeToSocial = (userId: string, callback: (relations: FriendRelation[]) => void) => {
  const relRef = ref(db, `players/${userId}/relations`);
  
  const unsubscribe = onValue(relRef, (snapshot) => {
      const relations: FriendRelation[] = [];
      snapshot.forEach(child => {
          relations.push(child.val());
      });
      callback(relations);
  });
  
  return unsubscribe;
};
