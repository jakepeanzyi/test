
import { db } from "../firebase";
import { ref, get, set, child, update } from "firebase/database";

export interface PlayFabUser {
  sessionTicket: string;
  playFabId: string;
  displayName?: string;
}

class PlayFabService {
  private currentUserId: string | null = null;

  constructor() {
    const saved = localStorage.getItem('wilderness_auth');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        this.currentUserId = parsed.playFabId;
      } catch (e) {
        localStorage.removeItem('wilderness_auth');
      }
    }
  }

  private sanitizePath(path: string): string {
    // Firebase paths cannot contain ., #, $, [, or ]
    return path.replace(/[.#$/[\]]/g, '_');
  }

  async updateUserData(data: Record<string, string>) {
    if (!this.currentUserId) throw new Error("Not logged in");
    const updates: Record<string, any> = {};
    for (const [key, value] of Object.entries(data)) {
        updates[`storage/${key}`] = value;
    }
    const userRef = ref(db, `players/${this.currentUserId}`);
    await update(userRef, updates);
  }

  async getUserData(keys?: string[]): Promise<Record<string, string>> {
    if (!this.currentUserId) throw new Error("Not logged in");
    const snapshot = await get(child(ref(db), `players/${this.currentUserId}/storage`));
    const data = snapshot.val() || {};
    if (keys && keys.length > 0) {
        const result: Record<string, string> = {};
        keys.forEach(k => {
            if (data[k]) result[k] = data[k];
        });
        return result;
    }
    return data;
  }

  async register(email: string, password: string, username: string): Promise<PlayFabUser> {
    if (!email.includes('@')) throw new Error("Invalid email address");
    if (password.length < 6) throw new Error("Password must be at least 6 characters");
    
    const cleanName = username.trim().replace(/[^a-zA-Z0-9_-]/g, '');
    if (!cleanName || cleanName.length < 3) throw new Error("Username must be at least 3 alphanumeric characters");

    const safeUsername = this.sanitizePath(cleanName);
    const accountRef = child(ref(db), `accounts/${safeUsername}`);
    const snapshot = await get(accountRef);
    if (snapshot.exists()) {
        throw new Error("Username already taken");
    }

    const newId = `user-${Date.now()}-${Math.floor(Math.random() * 10000)}`;

    await set(ref(db, `accounts/${safeUsername}`), {
        password,
        id: newId,
        email: email.toLowerCase()
    });

    await set(ref(db, `players/${newId}`), {
        public: {
          username: cleanName,
          lastUpdate: Date.now()
        },
        storage: {}
    });

    this.currentUserId = newId;
    const user = {
        sessionTicket: "mock-ticket-" + Math.random(),
        playFabId: newId,
        displayName: cleanName
    };
    localStorage.setItem('wilderness_auth', JSON.stringify(user));
    return user;
  }

  async login(idOrEmail: string, password: string): Promise<PlayFabUser> {
    if (!idOrEmail || !password) throw new Error("Please fill in all fields");

    // Ensure we never use an email as a direct child key to avoid invalid path errors
    const isEmailInput = idOrEmail.includes('@');
    let accountSnap: any = null;

    if (isEmailInput) {
      const accountsRef = ref(db, 'accounts');
      const snapshot = await get(accountsRef);
      const emailToFind = idOrEmail.toLowerCase();
      snapshot.forEach((child) => {
          const val = child.val();
          if (val && val.email && val.email.toLowerCase() === emailToFind) {
              accountSnap = child;
          }
      });
    } else {
      const safeUsername = this.sanitizePath(idOrEmail);
      accountSnap = await get(child(ref(db), `accounts/${safeUsername}`));
    }

    if (!accountSnap || !accountSnap.exists()) {
        throw new Error("User not found");
    }

    const data = accountSnap.val();
    if (data.password !== password) {
        throw new Error("Incorrect password");
    }

    this.currentUserId = data.id;
    const user = {
        sessionTicket: "mock-ticket-" + Math.random(),
        playFabId: data.id,
        displayName: accountSnap.key || "Survivor"
    };
    localStorage.setItem('wilderness_auth', JSON.stringify(user));
    return user;
  }

  logout() {
    this.currentUserId = null;
    localStorage.removeItem('wilderness_auth');
  }

  getPersistedUser(): PlayFabUser | null {
    const saved = localStorage.getItem('wilderness_auth');
    if (!saved) return null;
    try {
      return JSON.parse(saved);
    } catch (e) {
      return null;
    }
  }
}

export const playFab = new PlayFabService();
