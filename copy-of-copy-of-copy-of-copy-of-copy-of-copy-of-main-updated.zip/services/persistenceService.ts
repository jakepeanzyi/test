
import { db } from "../firebase";
import { ref, set, get, onValue, update, remove, runTransaction } from "firebase/database";
import { Player, Entity, PlayerCustomization, WeatherType, ItemType, InventoryItem, EntityType, Vector2 } from "../types";

export interface SavedPlayerState {
  pos: { x: number; y: number };
  health: number;
  hunger: number;
  thirst: number;
  stamina: number;
  inventory: InventoryItem[];
  hotbar: (string | null)[];
  lastServer: number;
  customization?: PlayerCustomization;
  unlockedBlueprints: string[];
  visitedChunks: string[];
}

export interface WorldStateData {
  dayTime: number;
  weather: WeatherType;
  lastUpdate: number;
}

const sanitizePayload = (data: any): any => {
  if (data === undefined) return null;
  if (data === null) return null;
  if (Array.isArray(data)) {
    return data.map(item => sanitizePayload(item));
  }
  if (typeof data === 'object') {
    const clean: any = {};
    Object.keys(data).forEach(key => {
      const val = sanitizePayload(data[key]);
      if (val !== undefined && val !== null) {
        clean[key] = val;
      }
    });
    return clean;
  }
  return data;
};

const roundPos = (n: number) => Math.round(n * 10) / 10;
const roundRot = (n: number) => Math.round(n * 100) / 100;

export const updatePlayerState = async (
  userId: string, 
  player: Player,
  serverId: number,
  preview?: { pos: Vector2, rotation: number, type: EntityType } | null
) => {
  try {
    const heldItem = player.inventory[player.selectedHotbarIndex]; 
    const rawInventory = Array.isArray(player.inventory) ? player.inventory : [];
    const inventoryToSave = rawInventory.map(i => sanitizePayload(i));
    const hotbarToSave = inventoryToSave.slice(0, 6).map(i => i ? i.id : null);

    const updates: any = {};
    
    // PUBLIC - Visible to others on this server
    const publicPath = `servers/server-${serverId}/players/${userId}`;
    updates[`${publicPath}/pos`] = { x: roundPos(player.pos.x), y: roundPos(player.pos.y) };
    updates[`${publicPath}/rotation`] = roundRot(player.rotation);
    updates[`${publicPath}/health`] = Math.ceil(player.health);
    updates[`${publicPath}/damageFlash`] = player.damageFlash || 0;
    updates[`${publicPath}/equippedItemType`] = heldItem?.type || null;
    updates[`${publicPath}/lastUpdate`] = Date.now();
    updates[`${publicPath}/username`] = player.id;
    updates[`${publicPath}/customization`] = sanitizePayload(player.customization);
    
    // Sync Building Preview for Multiplayer
    if (preview) {
        updates[`${publicPath}/preview`] = {
            pos: { x: roundPos(preview.pos.x), y: roundPos(preview.pos.y) },
            rotation: roundRot(preview.rotation),
            type: preview.type
        };
    } else {
        updates[`${publicPath}/preview`] = null;
    }

    // PRIVATE - Saved per server for the user
    const dataPath = `players/${userId}/servers/${serverId}`;
    updates[`${dataPath}/health`] = Math.ceil(player.health);
    updates[`${dataPath}/hunger`] = Math.ceil(player.hunger);
    updates[`${dataPath}/thirst`] = Math.ceil(player.thirst);
    updates[`${dataPath}/stamina`] = Math.ceil(player.stamina);
    updates[`${dataPath}/inventory`] = inventoryToSave;
    updates[`${dataPath}/hotbar`] = hotbarToSave;
    updates[`${dataPath}/pos`] = { x: roundPos(player.pos.x), y: roundPos(player.pos.y) };
    updates[`${dataPath}/unlockedBlueprints`] = player.unlockedBlueprints || [];
    updates[`${dataPath}/visitedChunks`] = player.visitedChunks || [];

    // Global customization save (persists across servers)
    updates[`players/${userId}/global/customization`] = sanitizePayload(player.customization);

    await update(ref(db), updates);
  } catch (e) {
    if ((e as any)?.code !== 'CLIENT_DISCONNECTED') {
        console.warn("Save failed:", e);
    }
  }
};

export const loadPlayerProfile = async (userId: string, serverId: number): Promise<SavedPlayerState | null> => {
  try {
      const snapshot = await get(ref(db, `players/${userId}/servers/${serverId}`));
      const globalSnapshot = await get(ref(db, `players/${userId}/global/customization`));
      
      if (!snapshot.exists()) return null;
      
      const val = snapshot.val();
      const globalCustomization = globalSnapshot.exists() ? globalSnapshot.val() : undefined;
      
      let loadedInventory = val.inventory || [];
      if (!Array.isArray(loadedInventory) && typeof loadedInventory === 'object') {
          loadedInventory = Object.values(loadedInventory);
      }

      let loadedHotbar = val.hotbar || [null, null, null, null, null, null];
      if (!Array.isArray(loadedHotbar) && typeof loadedHotbar === 'object') {
          const arr = [null, null, null, null, null, null];
          Object.keys(loadedHotbar).forEach(k => {
              arr[parseInt(k)] = loadedHotbar[k];
          });
          loadedHotbar = arr;
      }

      return {
          pos: val.pos || { x: 0, y: 0 },
          health: val.health !== undefined ? val.health : 100,
          hunger: val.hunger !== undefined ? val.hunger : 100,
          thirst: val.thirst !== undefined ? val.thirst : 100,
          stamina: val.stamina !== undefined ? val.stamina : 100,
          lastServer: serverId,
          customization: globalCustomization,
          inventory: loadedInventory,
          hotbar: loadedHotbar,
          unlockedBlueprints: val.unlockedBlueprints || [],
          visitedChunks: val.visitedChunks || []
      };
  } catch (e) {
      console.error("Critical Load Error:", e);
      return null;
  }
};

export const subscribeToPlayers = (currentUserId: string, currentServerId: number, callback: (players: Player[]) => void) => {
    const playersRef = ref(db, `servers/server-${currentServerId}/players`);
    return onValue(playersRef, (snapshot) => {
        const players: Player[] = [];
        const now = Date.now();
        snapshot.forEach((child) => {
            if (child.key === currentUserId) return;
            const pub = child.val();
            
            if (pub && pub.pos) {
                const isOffline = (now - (pub.lastUpdate || 0) > 3000);
                if (!isOffline) {
                    const p: any = {
                        id: pub.username || 'Survivor',
                        playFabId: child.key as string,
                        type: 'PLAYER',
                        pos: pub.pos,
                        rotation: pub.rotation || 0,
                        size: 16,
                        health: pub.health ?? 100,
                        maxHealth: 100,
                        velocity: {x:0, y:0},
                        color: pub.customization?.skinColor || '#d4a373',
                        customization: pub.customization,
                        isMoving: false,
                        isSleeping: false,
                        inventory: [],
                        hotbar: [],
                        selectedHotbarIndex: 0,
                        equipped: pub.equippedItemType || null,
                        damageFlash: pub.damageFlash || 0,
                        isOffline: false,
                        unlockedBlueprints: [],
                        visitedChunks: []
                    };
                    
                    if (pub.preview) {
                        p.buildingPreview = pub.preview;
                    }
                    
                    players.push(p);
                }
            }
        });
        callback(players);
    });
};

export const damagePlayer = async (targetUserId: string, serverId: number, amount: number) => {
  const healthRef = ref(db, `servers/server-${serverId}/players/${targetUserId}/health`);
  const flashRef = ref(db, `servers/server-${serverId}/players/${targetUserId}/damageFlash`);
  const privateHealthRef = ref(db, `players/${targetUserId}/servers/${serverId}/health`);
  
  await runTransaction(healthRef, (curr) => (curr === null ? 100 : Math.max(0, curr - amount)));
  await runTransaction(privateHealthRef, (curr) => (curr === null ? 100 : Math.max(0, curr - amount)));
  await set(flashRef, 10);
};

export const saveBuildingToServer = async (serverId: number, building: Entity) => {
  try {
      const safeId = building.id.replace(/[.#$/[\]]/g, '_');
      const cleanBuilding = sanitizePayload(building);
      await set(ref(db, `servers/server-${serverId}/buildings/${safeId}`), { ...cleanBuilding, timestamp: Date.now() });
  } catch (error) {
      console.error("Failed to save building:", error);
  }
};

export const removeBuildingFromServer = async (serverId: number, buildingId: string) => {
    const safeId = buildingId.replace(/[.#$/[\]]/g, '_');
    await remove(ref(db, `servers/server-${serverId}/buildings/${safeId}`));
}

export const fetchWorldBuildingsOnce = async (serverId: number): Promise<Entity[]> => {
    const snapshot = await get(ref(db, `servers/server-${serverId}/buildings`));
    const b: Entity[] = [];
    snapshot.forEach(c => { b.push(c.val() as Entity); });
    return b;
};

export const subscribeToWorldBuildings = (serverId: number, callback: (buildings: Entity[]) => void) => {
  return onValue(ref(db, `servers/server-${serverId}/buildings`), (snapshot) => {
    const b: Entity[] = [];
    snapshot.forEach(c => { b.push(c.val() as Entity); });
    callback(b);
  });
};

export const subscribeToWorldState = (serverId: number, callback: (world: WorldStateData) => void) => {
  return onValue(ref(db, `servers/server-${serverId}/world`), (snapshot) => {
    if (snapshot.exists()) callback(snapshot.val() as WorldStateData);
    else {
        const initial = { dayTime: 6000, weather: WeatherType.CLEAR, lastUpdate: Date.now() };
        set(ref(db, `servers/server-${serverId}/world`), initial);
        callback(initial as WorldStateData);
    }
  });
};

export const updateWorldState = async (serverId: number, world: Partial<WorldStateData>) => {
  await update(ref(db, `servers/server-${serverId}/world`), { ...world, lastUpdate: Date.now() });
};

export const markEntityDestroyed = async (serverId: number, entityId: string) => {
    await set(ref(db, `servers/server-${serverId}/world_changes/destroyed/${entityId}`), true);
};

export const subscribeToDestroyedEntities = (serverId: number, callback: (ids: Set<string>) => void) => {
    return onValue(ref(db, `servers/server-${serverId}/world_changes/destroyed`), (snapshot) => {
        const ids = new Set<string>();
        if (snapshot.exists()) {
            Object.keys(snapshot.val()).forEach(k => ids.add(k));
        }
        callback(ids);
    });
};
