
import { GoogleGenAI } from "@google/genai";
import { ItemType } from "../types";

// Guideline: Always use const ai = new GoogleGenAI({apiKey: process.env.API_KEY});

export const getWastelandLore = async (): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: 'Generate a short, gritty, survival log entry (2 sentences). It should feel like it was found in a scavenged wilderness diary.',
      config: {
        systemInstruction: 'You are a survivor in a dying world. Your tone is cynical and desperate.',
        temperature: 0.9,
      }
    });
    return response.text || "Found a few branches today. The air still smells of dry earth.";
  } catch (error) {
    console.error("Gemini Narrative Error:", error);
    return "The silence out here is louder than the storms used to be.";
  }
};

export const moderateChat = async (text: string): Promise<{ isToxic: boolean }> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Is this message hateful or inappropriate? Message: "${text}"`,
      config: {
        systemInstruction: 'Respond with exactly "BAD" or "GOOD". Nothing else.',
        temperature: 0.1,
      }
    });
    const result = response.text?.trim().toUpperCase();
    return { isToxic: result === "BAD" };
  } catch (error) {
    console.warn("AI Moderation offline, allowing message for safety:", error);
    return { isToxic: false };
  }
};

export const generateRadioQuest = async (): Promise<{ title: string; description: string; requestItem: ItemType; rewardItem: ItemType } | null> => {
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Generate a dynamic radio distress quest. A survivor needs resources. Return JSON.`,
            config: {
                systemInstruction: `You are a quest generator for a survival game. Return a JSON object with: 
                - title: A short gritty urgency title (e.g. "Medical Emergency", "Starving Outpost")
                - description: A 1-sentence radio message asking for help.
                - requestItem: One of [MEDKIT, BANDAGE, COOKED_MEAT, SCRAP_METAL, ROPE].
                - rewardItem: One of [GRENADE, BLUEPRINT, STEEL_BAR, IRON_AXE].`,
                responseMimeType: "application/json"
            }
        });
        
        const text = response.text;
        if (!text) return null;
        return JSON.parse(text);
    } catch (e) {
        console.error("Failed to generate quest", e);
        return null;
    }
}
